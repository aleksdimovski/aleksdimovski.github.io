

time verifyta -u train-gate1.xml train-gate1.q