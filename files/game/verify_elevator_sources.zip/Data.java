

import java.util.*;
import java.io.*;

class Data {
	
	public String label;
	public boolean landingButpressed1;
	public boolean landingButpressed2;
	public boolean landingButpressed3;
	public boolean landingButpressed4;
	public boolean liftButpressed1;
	public boolean liftButpressed2;
	public boolean liftButpressed3;
	public boolean liftButpressed4;
	public int liftfloor;
	public boolean liftdoor;
	public boolean liftdirection;
	public boolean overload;
	public String feat_expr;
	
	
	public Data(boolean lb1, boolean lb2, boolean lb3, boolean lb4, boolean tb1, boolean tb2, boolean tb3, boolean tb4, int lfloor, boolean ldoor, boolean ldir, String feat, boolean over) { // constructor
		landingButpressed1 = lb1;
		landingButpressed2 = lb2;
		landingButpressed3 = lb3;
		landingButpressed4 = lb4;
		liftButpressed1 = tb1;
		liftButpressed2 = tb2;	
		liftButpressed3 = tb3;
		liftButpressed4 = tb4;
		liftfloor = lfloor;
		liftdoor = ldoor;
		liftdirection = ldir;
		feat_expr = feat;
		overload = over; 
		
		if (landingButpressed1) label="1"; else label="0";
		if (landingButpressed2) label+="1"; else label+="0";
		if (landingButpressed3) label+="1"; else label+="0";
		if (landingButpressed4) label+="1"; else label+="0";
		if (liftButpressed1) label+="1"; else label+="0";
		if (liftButpressed2) label+="1"; else label+="0";
		if (liftButpressed3) label+="1"; else label+="0";
		if (liftButpressed4) label+="1"; else label+="0";
		
		switch (liftfloor) {
			case 1: label+="00"; break;
			case 2: label+="01"; break;
			case 3: label+="10"; break;
			case 4: label+="11"; break;
		}
		if (liftdoor) label+="1"; else label+="0";
		if (liftdirection) label+="1"; else label+="0";			
	}
	
	public boolean no_call() {
		return (!landingButpressed1 && !landingButpressed2 && !landingButpressed3 && !landingButpressed4);
	}

	public boolean idle() {
		return (this.no_call() && !liftButpressed1 && !liftButpressed2 && !liftButpressed3 && !liftButpressed4);
	}	
	
	public boolean landingButreset1() {
		return (liftfloor==1 && liftdoor);
	}

	public boolean landingButreset2() {
		return (liftfloor==2 && liftdoor);
	}		

	public boolean landingButreset3() {
		return (liftfloor==3 && liftdoor);
	}	

	public boolean landingButreset4() {
		return (liftfloor==4 && liftdoor);
	}	
	
	public boolean liftButreset1() {
		return (liftfloor==1 && liftdoor);
	}

	public boolean liftButreset2() {
		return (liftfloor==2 && liftdoor);
	}	

	public boolean liftButreset3() {
		return (liftfloor==3 && liftdoor);
	}

	public boolean liftButreset4() {
		return (liftfloor==4 && liftdoor);
	}
	
	public int lift_call() {
		if (liftdirection) {
			if (liftButpressed1 && liftfloor<2) return 1;
			if (liftButpressed2 && liftfloor<3) return 2;
			if (liftButpressed3 && liftfloor<4) return 3;
			if (liftButpressed4) return 4;
			return 0;
		}
		else {
			if (liftButpressed4 && liftfloor>3) return 4;
			if (liftButpressed3 && liftfloor>2) return 3;
			if (liftButpressed2 && liftfloor>1) return 2;
			if (liftButpressed1) return 1;
			return 0;			
		}
	}
	
	public int landing_call() {
		if (liftdirection) {
			if (landingButpressed1 && liftfloor<2) return 1;
			if (landingButpressed2 && liftfloor<3) return 2;
			if (landingButpressed3 && liftfloor<4) return 3;
			if (landingButpressed4) return 4;
			return 0;
		}
		else {
			if (landingButpressed4 && liftfloor>3) return 4;
			if (landingButpressed3 && liftfloor>2) return 3;
			if (landingButpressed2 && liftfloor>1) return 2;
			if (landingButpressed1) return 1;
			return 0;			
		}
	}
	
	public void displayData() {
		System.out.print(" ("+label);
		System.out.print(") ");
	}
} // end class Vertex