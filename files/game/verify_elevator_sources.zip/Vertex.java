
import java.util.*;
import java.io.*;

class Vertex {
	
	public int index; // label (e.g. 'A')
	public boolean wasVisited;
	public Data data;
	public int state;
	public String formula;
	public String type_formula;
	
	public Vertex(int lab, Data d) { // constructor
		index = lab;
		data = d;
		wasVisited = false;
	}
	
	public Vertex(int lab, Data d, int s, String f, String t) { // constructor
		index = lab;
		data = d;
		wasVisited = false;
		state=s;
		formula=f;
		type_formula=t;
	}
	
	public void displayVertex(int n) {
		System.out.print("("+n+" "+index+" "); data.displayData();
		if (type_formula!=null) System.out.print(type_formula+" ");
		System.out.print(" formula: "+formula+") ");
	}
} // end class Vertex