import java.lang.*;
import java.io.*;
import java.util.*;
import java.text.*;

class App {

	public static void main(String[] args) {
		
		long start = System.currentTimeMillis();
	
		String atom="", type="";
		switch (args[0]) {
			case "P1": type = "EU"; atom = "!liftdoor,liftfloor=1,idle"; break;
			case "P2": type = "AU"; atom = "!liftdoor,liftfloor=1,idle"; break;
			case "P3": type = "EU"; atom = "liftfloor=2,!liftButpressed2,liftdirection,!liftdoor"; break;
			case "P4": type = "EU"; atom = "liftdoor"; break;
		}
		
		
		Graph theGraph = new Graph();
		//create_BA(theGraph,n);
		create_Elevator3(theGraph);
		
		//System.out.println();
		//theGraph.displayAutomaton();
		
		//System.out.print("Visits DFS: ");
		//theGraph.dfs(); // depth-first search
		//System.out.println();
		//System.out.print("Visits BFS: ");
		//theGraph.bfs(); // breadth-first search
		//System.out.println();	
		//System.out.print("Topological order: ");
		//theGraph.topo(); // do the sort


		 
		
		Graph g=theGraph.create_GG(type, "true", atom);
		//System.out.println();
		//g.displayAutomaton();
		
		
		try {
			LinkedList<Graph> theQueue1=new LinkedList();
			LinkedList<String> theQueue2=new LinkedList();
			theQueue1.add(g);
			theQueue2.add("true");
			
			//while (theQueue1.size()!=0 ) {
				Graph gc=theQueue1.remove();
				String cc=theQueue2.remove();
				
				String res=null;
				res=gc.colorgraph();
				System.out.println();
				System.out.println("Graph with constraint= "+cc+" : the initial node is colored "+res);
				if (res.equals("sat")) System.out.println("The property is true"); 
				else if (res.equals("unsat")) System.out.println("The property is false"); 
			/*	if (res.startsWith("?")) {
					int k=Integer.parseInt(res.substring(1));
					System.out.println(); System.out.println("Refinement using "+k);
					Graph[] gr = new Graph[2];
					for (int i=0; i<gc.nEdges.get(k); i++) {
						gr[i] = gc.refine(k,i);
						theQueue1.add(gr[i]);
						String rc=null;
						if (cc.equals("true")) rc=gc.adjMat[k][i].cond;
						else rc=cc+" and "+gc.adjMat[k][i].cond;
						theQueue2.add(rc);
						//System.out.println(); 
						//System.out.println("Refined Automaton "+i+" on cond "+rc);
						//gr[i].displayAutomaton();
					}
					//System.out.println("Refinement with "+k+" cond "+g.adjMat[k][0].cond);
					//current.displayVertex(k);
				} */
			//}
		} catch(Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		
		
		long end = System.currentTimeMillis();
		NumberFormat formatter = new DecimalFormat("#0.00000");
		System.out.print("Execution time is " + formatter.format((end - start - 600) / 1000d) + " seconds");
	} // end main()



	public static void create_Elevator3(Graph theGraph) {
		int letter=0;
		LinkedList<Vertex> theQueue=new LinkedList();
		HashSet<String> allData = new HashSet<String>();
		HashMap<String,Integer> vertices = new HashMap<String,Integer>();
		HashSet<String> edges = new HashSet<String>();
				
		Data initial = new Data(false,false,false,false,false,false,false,false,1,false,false,"true",false);
		//initial.displayData();
		Vertex v0 = new Vertex(letter++,initial);
		theGraph.addVertex(v0);
		theQueue.add(v0); // insert at tail
		allData.add(initial.label);
		vertices.put(initial.label,0);
		boolean saturation = false;
		int count_true=0;
		int count_ntrue=0;
		int count_trans=0;

		while( theQueue.size()>0 ) { // until queue empty,
			Vertex v1 = theQueue.remove();
			int ind1 = v1.index;
			Data data1 = v1.data;
			
			edges = new HashSet<String>();
			HashSet<Data> dataset = generateNext(data1);
			count_trans=0;
			
			for (Data data2 : dataset) {
			  //System.out.println("Data "+data2.label+" "+data2.feat_expr);
			  if (!allData.contains(data2.label)) {
				Vertex v2 = new Vertex(letter++,data2);
				theGraph.addVertex(v2);
				theQueue.add(v2);
				allData.add(data2.label);
				int ind2 = v2.index; 
				vertices.put(data2.label,ind2);
				String edge=ind2+data2.feat_expr;
				if (!edges.contains(edge)) {
					edges.add(edge);
					if ((data2.feat_expr).equals("true")) {
						count_true++; count_trans++;
						theGraph.addEdge(ind1, ind2, "must", data2.feat_expr);
					}
					else { 
						count_ntrue++; count_trans++;
						theGraph.addEdge(ind1, ind2, "may", data2.feat_expr);
					}
				}
				//System.out.println("New state "+data2.label+" feat "+data2.feat_expr);
			  }
			  else if (vertices.containsKey(data2.label)){
				int ind2 = (int)vertices.get(data2.label);
				String edge=ind2+data2.feat_expr;		
				if (!edges.contains(edge)) {
					edges.add(edge);
					if ((data2.feat_expr).equals("true")) {
						count_true++; count_trans++;
						theGraph.addEdge(ind1, ind2, "must", data2.feat_expr);
					}
					else { 
						count_ntrue++; count_trans++;
						theGraph.addEdge(ind1, ind2, "may", data2.feat_expr);
					}
				//System.out.println("New state "+data2.label+" feat "+data2.feat_expr);
				}
			  }
			}
			//System.out.println("Transitions out of state "+ind1+" is "+count_trans);
		}
		
		//System.out.println("Number of generated states: "+allData.size());
		//System.out.println("Number of true-feature cond transitions: "+count_true);
		//System.out.println("Number of not true-feature cond transitions: "+count_ntrue);
		/*
		while( theQueue.size()!=0 ) { 
			Vertex v1 = theQueue.remove();
			int ind1 = (int)v1.label-(int)'a';
			int data1 = v1.data;
			theGraph.addEdge(ind1, ind1, "must", "true"); // AD
		}
		*/
	}	
	
	public static HashSet<Data> generateNext(Data data1) {
		
		HashSet<Boolean> landingButpressed1=new HashSet(); // these buttons should be implemented as sets that take into account all options, we don't need random()
		HashSet<Boolean> landingButpressed2=new HashSet();
		HashSet<Boolean> landingButpressed3=new HashSet();
		HashSet<Boolean> landingButpressed4=new HashSet();
		HashSet<Boolean> liftButpressed1=new HashSet();
		HashSet<Boolean> liftButpressed2=new HashSet();
		HashSet<Boolean> liftButpressed3=new HashSet();
		HashSet<Boolean> liftButpressed4=new HashSet();
		HashSet<String> liftfloor=new HashSet();
		HashSet<String> liftdoor=new HashSet();
		HashSet<String> liftdirection=new HashSet();	
		HashSet<Boolean> overl=new HashSet();
		
		if (data1.landingButreset1()) landingButpressed1.add(Boolean.FALSE);
		else if (data1.landingButpressed1) landingButpressed1.add(Boolean.TRUE);
		else {landingButpressed1.add(Boolean.FALSE); 
			  landingButpressed1.add(Boolean.TRUE);}
			
		if (data1.landingButreset2()) landingButpressed2.add(Boolean.FALSE);
		else if (data1.landingButpressed2) landingButpressed2.add(Boolean.TRUE);
		else {landingButpressed2.add(Boolean.FALSE); 
			  landingButpressed2.add(Boolean.TRUE);}
		
		if (data1.landingButreset3()) landingButpressed3.add(Boolean.FALSE);
		else if (data1.landingButpressed3) landingButpressed3.add(Boolean.TRUE);
		else {landingButpressed3.add(Boolean.FALSE); 
			  landingButpressed3.add(Boolean.TRUE);}		

		if (data1.landingButreset4()) landingButpressed4.add(Boolean.FALSE);
		else if (data1.landingButpressed4) landingButpressed4.add(Boolean.TRUE);
		else {landingButpressed4.add(Boolean.FALSE); 
			  landingButpressed4.add(Boolean.TRUE);}	
			  
		if (data1.liftButreset1()) liftButpressed1.add(Boolean.FALSE);
		else if (data1.liftButpressed1) liftButpressed1.add(Boolean.TRUE);
		else {  liftButpressed1.add(Boolean.FALSE);
				liftButpressed1.add(Boolean.TRUE);	
				}
			
		if (data1.liftButreset2()) liftButpressed2.add(Boolean.FALSE);
		else if (data1.liftButpressed2) liftButpressed2.add(Boolean.TRUE);
		else {  liftButpressed2.add(Boolean.FALSE);
				liftButpressed2.add(Boolean.TRUE);	
				}		

		if (data1.liftButreset3()) liftButpressed3.add(Boolean.FALSE);
		else if (data1.liftButpressed3) liftButpressed3.add(Boolean.TRUE);
		else {  liftButpressed3.add(Boolean.FALSE);
				liftButpressed3.add(Boolean.TRUE);	
				}

		if (data1.liftButreset4()) liftButpressed4.add(Boolean.FALSE);
		else if (data1.liftButpressed4) liftButpressed4.add(Boolean.TRUE);
		else {  liftButpressed4.add(Boolean.FALSE);
				liftButpressed4.add(Boolean.TRUE);	
				}
				
		if (data1.liftdoor) liftdoor.add("false-Quickclose");
		if (data1.overload) liftdoor.add("true-Overloaded");
		if (data1.idle()) liftdoor.add("true-OpenIfIdle");				
				
		if (data1.liftfloor==data1.lift_call()) liftdoor.add("true-true");
		else if (data1.liftfloor==data1.landing_call()) liftdoor.add("true-true");
			else liftdoor.add("false-true");
		
		//System.out.println("liftdoor");
		//for (String ldoor : liftdoor) { System.out.print(ldoor+" "); }
		//System.out.println();
		
		int n=0;
		//if (data1.liftdoor || data1.idle()) liftfloor.add(data1.liftfloor+"-Shuttle");
		//else if (data1.liftdirection && data1.liftfloor<2) { n=data1.liftfloor+1; liftfloor.add(n+"-Shuttle"); }		
		//	else if (!data1.liftdirection && data1.liftfloor>1) { n=data1.liftfloor-1; liftfloor.add(n+"-Shuttle"); }
					
		if (data1.liftdoor) liftfloor.add(data1.liftfloor+"-true");
		else if (data1.lift_call()==0 && data1.landing_call()==0) liftfloor.add(data1.liftfloor+"-true");
			else if (data1.liftdirection && data1.liftfloor<4) { n=data1.liftfloor+1; liftfloor.add(n+"-true"); }	
				else if (!data1.liftdirection && data1.liftfloor>1) { n=data1.liftfloor-1; liftfloor.add(n+"-true"); }
					else liftfloor.add(data1.liftfloor+"-true");
		
		
		//if (data1.liftfloor==2) liftdirection.add("false-Shuttle");
		//	else if (data1.liftfloor==1) liftdirection.add("true-Shuttle");
		//		 else liftdirection.add(data1.liftdirection+"-Shuttle");	
				 
		if (data1.idle()) liftdirection.add(data1.liftdirection+"-true");
		else if (data1.liftfloor==4) liftdirection.add("false-true");
			else if (data1.liftfloor==1) liftdirection.add("true-true");
				else if (data1.lift_call()==0 && data1.landing_call()==0 && !data1.liftdirection) liftdirection.add("true-true");
					else if (data1.lift_call()==0 && data1.landing_call()==0 && data1.liftdirection) liftdirection.add("false-true");
						else liftdirection.add(data1.liftdirection+"-true");
		
		if (!data1.liftdoor) overl.add(data1.overload);
		else {  overl.add(Boolean.TRUE); 
				overl.add(Boolean.FALSE); 
		}
		
		int count_true=0;
		HashSet<Data> result = new HashSet<Data>();
		
		for (Boolean bl1 : landingButpressed1) 
			for (Boolean bl2 : landingButpressed2) 
			  for (Boolean bl3 : landingButpressed3)
			   for (Boolean bl4 : landingButpressed4)
				for (Boolean bt1 : liftButpressed1)
					for (Boolean bt2 : liftButpressed2)
					  for (Boolean bt3 : liftButpressed3)
					   for (Boolean bt4 : liftButpressed4)
						for (String ld : liftdirection) {
							//System.out.print("Liftdirection "+ld+" ");
							int index1 = ld.indexOf("-");
							boolean direction = Boolean.valueOf(ld.substring(0,index1));
							String feat1 = ld.substring(index1+1);
							String feat="";
							for (String ldoor : liftdoor) {
								//System.out.print("Liftdoor "+ldoor+" ");
								int index2 = ldoor.indexOf("-");
								boolean door = Boolean.valueOf(ldoor.substring(0,index2));
								String feat2 = ldoor.substring(index2+1);
								//System.out.print(" feat2 "+feat2+" ");
								if ((!feat1.equals("true")) && (!feat2.equals("true")) && (!feat2.equals(feat1))) feat2 = feat1 + "," + feat2;
								else if (!feat1.equals("true")) feat2=feat1;
								//System.out.print("Middle2 feat "+feat2);
								for (String lf : liftfloor) {
										//System.out.print("Liftfloor "+lf+" ");
										int index3 = lf.indexOf("-");
										int floor = Integer.valueOf(lf.substring(0,index3));
										String feat3 = lf.substring(index3+1);
										if (feat2.equals("true")) feat = feat3;
										else if ((!feat3.equals("true")) && (!feat3.equals(feat1)) && (!feat3.equals(feat2))) feat = feat2 + "," + feat3;
										else feat=feat2;
										//System.out.println(" Final feat "+feat);
										if (feat.equals("true")) count_true++;
										for (Boolean over : overl)
											result.add(new Data(bl1.booleanValue(),bl2.booleanValue(),bl3.booleanValue(),bl4.booleanValue(),bt1.booleanValue(),bt2.booleanValue(),bt3.booleanValue(),bt4.booleanValue(),floor,door,direction,feat,over.booleanValue()));
								}
							}
						}
		//System.out.println("Number of true feature condition transitions: "+count_true);
		return result;		
	}
	
} // end class DFSApp