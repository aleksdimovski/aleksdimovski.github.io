import java.io.*;

public class Edge {

		int src;
		int des;
		String type;
		String cond;
		
		public Edge(int s, int d, String t, String c) {
			src=s; des=d;
			type=t; cond=c;
		} 

		public int getSrc() {
			return src;
		}		
		
		public int getDest() {
			return des;
		}
		
		public void displayEdge() {
			System.out.print("|"+src+" [");
			if (!cond.equals("true")) System.out.print(cond+"; ");
			System.out.print(type+"> "+des+"| ");
		}
				
}