import java.util.*;
import java.io.*;


class Graph {
	private final int MAX_VERTS = 200000;
	List<Vertex> vertexList; // array of vertices
	Edge adjMat[][]; // adjacency matrix
	int nVerts; // current number of vertices
	List<Integer> nEdges = new ArrayList<Integer>();

	public Graph() {// constructor
		vertexList = new ArrayList<Vertex>();
		adjMat = new Edge[MAX_VERTS][2];
		nVerts = 0;
		nEdges = new ArrayList<Integer>();
	} // end constructor

	public void addVertex(Vertex v) { // argument is label
		nEdges.add(nVerts,0);
		vertexList.add(nVerts++,v);
	}
	public void addVertex(char lab, int d) { // argument is label
		nEdges.add(nVerts,0);
		vertexList.add(nVerts++,new Vertex(lab,d));
	}

	public void addVertex(char lab, int d, char s, String f, String t) { // argument is label
		nEdges.add(nVerts,0);
		vertexList.add(nVerts++,new Vertex(lab,d,s,f,t));
	}
	public void addEdge(int start, int end, String typ, String cnd) {
		Edge e = new Edge(start,end,typ,cnd);
		adjMat[start][nEdges.get(start)] = e;
		nEdges.set(start,nEdges.get(start)+1);
		//adjMat[start][end] = 1;
		//adjMat[end][start] = 1;
	}

	public void displayVertex(int v) {
		System.out.print(vertexList.get(v).label+" ");
		if (vertexList.get(v).type_formula!=null) System.out.print(vertexList.get(v).type_formula+" ");
	}

	public void displayAutomaton() {
		System.out.print("States: ");
		for (int i=0; i<nVerts; i++)
			vertexList.get(i).displayVertex(i);
		System.out.println();
		System.out.println("Transitions: ");
		for (int i=0; i<nVerts; i++) {
			for (int j=0; j<nEdges.get(i); j++)
				adjMat[i][j].displayEdge();
			if (nEdges.get(i)!=0) System.out.println();
		}
		System.out.println();
	}
	
	public void dfs() { // depth-first search
		Stack<Integer> theStack=new Stack();
		vertexList.get(0).wasVisited = true; // mark it
		displayVertex(0); // display it
		System.out.print(" ");
		theStack.push(0); // push it
		while( !theStack.empty() ) {// until stack empty, get an unvisited vertex adjacent to stack top
			int v = getAdjUnvisitedVertex( theStack.peek() );
			if (v == -1) // if no such vertex,
				theStack.pop();
			else { // if it exists,
				vertexList.get(v).wasVisited = true; // mark it
				displayVertex(v); // display it
				System.out.print(" ");
				theStack.push(v); // push it
			}
		} // end while
		// stack is empty, so we're done
		for(int j=0; j<nVerts; j++) // reset flags
			vertexList.get(j).wasVisited = false;
	} // end dfs

	public void bfs() {// breadth-first search
		LinkedList<Integer> theQueue=new LinkedList();
		vertexList.get(0).wasVisited = true; // mark it
		displayVertex(0); // display it
		theQueue.add(0); // insert at tail
		int v2;
		while( theQueue.size()!=0 ) { // until queue empty,
			int v1 = theQueue.remove(); // remove vertex at head
			// until it has no unvisited neighbors
			while( (v2=getAdjUnvisitedVertex(v1)) != -1 ) {
				vertexList.get(v2).wasVisited = true; // mark it
				displayVertex(v2); // display it
				theQueue.add(v2); // insert it
			} // end while
		} // end while(queue not empty)
		// queue is empty, so we're done
		for(int j=0; j<nVerts; j++) // reset flags
			vertexList.get(j).wasVisited = false;
	} // end bfs()
		
	// returns an unvisited vertex adj to v
	public int getAdjUnvisitedVertex(int v) {
		for(int j=0; j<nEdges.get(v); j++) {
			int dest = adjMat[v][j].des;
			if (vertexList.get(dest).wasVisited==false)
				return dest;
		}
		return -1;
	} // end getAdjUnvisitedVert()	

	public int getAdjUnvisitedVertexIndex(int v) {
		for(int j=0; j<nEdges.get(v); j++) {
			int dest = adjMat[v][j].des;
			if (vertexList.get(dest).wasVisited==false)
				return j;
		}
		return -1;
	} // end getAdjUnvisitedVert()		
	public void topo() { // toplogical sort
		char[] sortedArray = new char[nVerts];
		int n = nVerts; // remember how many verts
		while(n > 0) { // while vertices remain,
			// get a vertex with no successors, or -1
			int currentVertex = noSuccessors();
			//System.out.println(currentVertex+" "+n);
			if(currentVertex == -1) { // must be a cycle
				System.out.println("ERROR: Graph has cycles");
				return;
			}
			// insert vertex label in sorted array (start at end)
			sortedArray[n-1] = vertexList.get(currentVertex).label;
			n--; // delete vertex
		} // end while
		// vertices all gone; display sortedArray
		//System.out.print("Topologically sorted order: ");
		for(int j=0; j<nVerts; j++)
			System.out.print( sortedArray[j]+" " );
		System.out.println("");
		
		for(int j=0; j<nVerts; j++) // reset flags
		vertexList.get(j).wasVisited = false;
	} // end topo
	
	public int noSuccessors() { // returns vert with no successors (or -1 if no such verts)
		boolean hasEdge; // edge from row to column in adjMat
		for(int v=0; v<nVerts; v++) { // for each vertex,
			hasEdge = false; // check edges
			//System.out.println("here 0 "+vertexList[v].wasVisited);
			if (vertexList.get(v).wasVisited==true) continue;
			for(int col=0; col<nEdges.get(v); col++) {	
				//System.out.println("here 0.5 "+adjMat[v][col].des);
				if (( adjMat[v][col].des != v ) && (vertexList.get(adjMat[v][col].des).wasVisited==true)) { // if edge to another
					hasEdge = true;
					break; // this vertex
				} // has a successor
			} // try another
			if( !hasEdge ) {// if no edges,
				vertexList.get(v).wasVisited=true;
				//System.out.println("here 1 "+v);
				return v; // has no successors
			}
		}
		return -1; // no such vertex
	} // end noSuccessors()
	
	
	public Graph create_GG(String type, String op1, String op2) {
		Graph g = new Graph();
		char letter='A';
		int index=0;
		
		
		LinkedList<Integer> theQueue=new LinkedList();
		LinkedList<Integer> rootQueue=new LinkedList();
		
		vertexList.get(0).wasVisited = true; // mark it
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,op1+type+op2,"AU");
		g.vertexList.get(0).displayVertex(0);
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,op2+" OR ("+op1+" AND AX("+op1+type+op2+"))","OR");
		g.addEdge(index-2, index-1, "must", "true"); //
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,op2,"TERMINAL");
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,"("+op1+" AND AX("+op1+type+op2+"))","AND");
		g.addEdge(index-3, index-2, "must", "true"); //
		g.addEdge(index-3, index-1, "must", "true"); //
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,op1,"TERMINAL");
		g.addVertex((char)(letter+index++),vertexList.get(0).data,vertexList.get(0).label,"AX("+op1+type+op2+")","AX");
		g.addEdge(index-3, index-2, "must", "true"); //
		g.addEdge(index-3, index-1, "must", "true"); //
		theQueue.add(0); // insert at tail
		rootQueue.add(index-1);
		int v;
		while( theQueue.size()!=0 ) { // until queue empty,
			int v1 = theQueue.remove(); // remove vertex at head
			int root = rootQueue.remove();
			// until it has no unvisited neighbors
			while( (v=getAdjUnvisitedVertexIndex(v1)) != -1 ) {
				int v2 = adjMat[v1][v].des;
				String t2 = adjMat[v1][v].type;
				String c2 = adjMat[v1][v].cond;
				vertexList.get(v2).wasVisited = true; // mark it
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,op1+type+op2,"AU");
				g.addEdge(root, index-1, t2, c2); //
				int nov_root=index-1;
				
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,op2+" OR ("+op1+" AND AX("+op1+type+op2+"))","OR");
				g.addEdge(index-2, index-1, "must", "true"); //
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,op2,"TERMINAL");
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,"("+op1+" AND AX("+op1+type+op2+"))","AND");
				g.addEdge(index-3, index-2, "must", "true"); //
				g.addEdge(index-3, index-1, "must", "true"); //
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,op1,"TERMINAL");
				g.addVertex((char)(letter+index++),vertexList.get(v2).data,vertexList.get(v2).label,"AX("+op1+type+op2+")","AX");
				g.addEdge(index-3, index-2, "must", "true"); //
				g.addEdge(index-3, index-1, "must", "true"); //
			
				theQueue.add(v2); // insert at tail
				rootQueue.add(index-1);
				if ( getAdjUnvisitedVertexIndex(v2) == -1 ) {
					g.addEdge(index-1, nov_root, "must", "true"); //
				}
			//	displayVertex(v2); // display it
			//	theQueue.add(v2); // insert it
			} // end while
		} // end while(queue not empty)
		// queue is empty, so we're done
		
		
		for(int j=0; j<nVerts; j++) // reset flags
			vertexList.get(j).wasVisited = false;
		
		return g;
	
	}
	
	public String colorgraph() throws java.io.IOException {
		String res=null;
		
		Vertex current = vertexList.get(0);
		res = colorvertex(current,0);
		
		for(int j=0; j<nVerts; j++) // reset flags
			vertexList.get(j).wasVisited = false;
			
		return res;
	}
	
	public String colorvertex(Vertex v, int k) throws java.io.IOException {
		String res=null, res1=null, res2=null;
		Vertex current = v;
		if (current.wasVisited) return "visited";
		else current.wasVisited=true;
		//System.out.println(current.type_formula);
		//current.displayVertex(k);
		switch (current.type_formula) {
			case "TERMINAL": res=check(current.data,current.formula); break;
			case "AU":  res=colorvertex(vertexList.get(adjMat[k][0].des), adjMat[k][0].des); break;
			case "OR":  res1=colorvertex(vertexList.get(adjMat[k][0].des), adjMat[k][0].des); 
						if (res1.equals("sat")) { res="sat"; break; }
						else {
							res2=colorvertex(vertexList.get(adjMat[k][1].des), adjMat[k][1].des); 
							res=res2; }
						break; 	
			case "AND":  res1=colorvertex(vertexList.get(adjMat[k][0].des), adjMat[k][0].des); 
						if (res1.equals("unsat")) { res="unsat"; break; }
						else {
							res2=colorvertex(vertexList.get(adjMat[k][1].des), adjMat[k][1].des); 
							res=res2; }
						break; 	
			case "AX":  //System.out.println(adjMat[k][0].type);
						//System.out.println("number of edges: "+nEdges[k]);
						boolean may=true, must=true;
						
						for (int j=0; j<nEdges.get(k); j++) {
							//adjMat[k][j].displayEdge();
							res1=colorvertex(vertexList.get(adjMat[k][j].des), adjMat[k][j].des); 
							if ((adjMat[k][j].type).equals("must")) {
								//System.out.println("res1 "+res1);
								if (res1.equals("unsat") || res1.equals("visited")) { res="unsat"; break; }
								if (res1.startsWith("?") && nEdges.get(k)==1) { res=res1; break; }
								//else must=true;
							}
							if ((adjMat[k][j].type).equals("may")) {
								if (res1.equals("sat")) may=true;
								else may=false;								
							}
						}
						if (res==null) if (may) res="sat"; else res="?";
						break;
		}
		if (res.equals("?")) {res=res+k; System.out.println("Failure node is "); current.displayVertex(k); }
		return res;
	}	
	
	public String check(int data, String f) throws java.io.IOException {
		String result=null, line=null;
		//try {
			//System.out.println("in check: "+data+" "+f);
			
			PrintWriter out2 = new PrintWriter(new BufferedWriter(new FileWriter("Temp.ys")));	
			out2.println(";(set-evidence! true)");
			out2.println("(define x::int)");
			if (f.equals("true") || f.equals("false")) out2.println("(assert "+f+")");
			else out2.println("(assert ("+f+"))");
			out2.println("(assert (= x "+data+"))");
			out2.println("(check)");
			//out2.println("(show-model)");
			out2.flush();
			
			Runtime rt = Runtime.getRuntime();
			//Process pr = rt.exec("cmd /c yices < Temp.ys");
			Process pr = rt.exec("yices Temp.ys");
			
			BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
 			
			//result=input.readLine();
			while((line=input.readLine()) != null) {
					//System.out.println(line);
					result=line;
			}	
			//System.out.println("yices result "+result);
		//} catch(Exception e) {
		//	System.out.println(e.toString());
		//	e.printStackTrace();
		//}
		return result;
	}
	
	
	public Graph refine(int k, int m) {
		Graph g1=new Graph();
		
		for (int i=0; i<nVerts; i++) {
			Vertex current=vertexList.get(i);
			if (i!=k) {
				g1.addVertex(current.label, current.data, current.state, current.formula, current.type_formula);
				for (int j=0; j<nEdges.get(i); j++) 
					g1.addEdge(adjMat[i][j].src, adjMat[i][j].des, adjMat[i][j].type, adjMat[i][j].cond);
			}
			else {
				//System.out.println("Here "); current.displayVertex(k);
				g1.addVertex(current.label, current.data, current.state, current.formula, current.type_formula);
				g1.addEdge(adjMat[i][m].src, adjMat[i][m].des, "must", "true");				
			}
		}
		
		return g1;
	
	}
	
} // end class Graph