import java.lang.*;
import java.io.*;
import java.util.*;
import java.text.*;

class App {

	public static void main(String[] args) {
		
		long start = System.currentTimeMillis();

		int m = Integer.parseInt(args[0]);
		int n = Integer.parseInt(args[1]);
		int generalized=0; // whether to generate basic MTS or generalized MTS
		if (args.length>2) generalized=1;	
		
		String atom="";
		if ((m==0) || (m==2)) atom=">= x 0";
		else if (m==3) atom="< x 0";
		else atom=">= x 1";
		
		String type="AU";
		if (m==2) type="EXEU";
		
		
		Graph theGraph = new Graph();
		
		//theGraph.addVertex('a',0); // 0 (start for dfs)
		//theGraph.addVertex('b',1); // 1
		//theGraph.addVertex('c',0); // 2
		//theGraph.addEdge(0, 1, "may", "A1"); // AB
		//theGraph.addEdge(0, 2, "may", "A1'"); // BC
		//theGraph.addEdge(1, 1, "must", "true"); // AD
		//theGraph.addEdge(2, 2, "must", "true"); // DE
		create_BA(theGraph,n,generalized);
		
		//System.out.print("Visits DFS: ");
		//theGraph.dfs(); // depth-first search
		//System.out.println();
		//System.out.print("Visits BFS: ");
		//theGraph.bfs(); // breadth-first search
		System.out.println();	
		//System.out.print("Topological order: ");
		//theGraph.topo(); // do the sort
		//System.out.println();
		theGraph.displayAutomaton();
		
		
		Graph g=theGraph.create_GG(type, "true", atom);
		System.out.println();
		g.displayAutomaton();
		
		///*
		try {
			LinkedList<Graph> theQueue1=new LinkedList();
			LinkedList<String> theQueue2=new LinkedList();
			int iterations = 0;
			theQueue1.add(g);
			theQueue2.add(iterations+"true");
			
			while (theQueue1.size()!=0 ) {
				Graph gc=theQueue1.remove();
				String cc=theQueue2.remove();
				char iter = cc.charAt(0);
				cc = cc.substring(1);
				iterations=Character.getNumericValue(iter)+1;
				
				String res=null;
				res=gc.colorgraph();
				System.out.println();
				System.out.println("Iteration "+iter+": Graph with condition= "+cc+" : the initial node is colored "+res);
				if (res.startsWith("?")) {
					int k=Integer.parseInt(res.substring(1));
					System.out.println(); System.out.println("Refinement using "+k);
					Graph[] gr = new Graph[2];
					for (int i=0; i<gc.nEdges.get(k); i++) {
						gr[i] = gc.refine(k,i);
						theQueue1.add(gr[i]);
						String rc=null;
						if (cc.equals("true")) rc=gc.adjMat[k][i].cond;
						else rc=cc+" and "+gc.adjMat[k][i].cond;
						theQueue2.add(iterations+rc);
						//System.out.println(); 
						//System.out.println("Refined Automaton "+i+" on cond "+rc);
						//gr[i].displayAutomaton();
					}
					//System.out.println("Refinement with "+k+" cond "+g.adjMat[k][0].cond);
					//current.displayVertex(k);
				}
			}
		} catch(Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		//*/
		
		long end = System.currentTimeMillis();
		NumberFormat formatter = new DecimalFormat("#0.00000");
		System.out.print("Execution time is " + formatter.format((end - start) / 1000d) + " seconds");
	} // end main()
	
	public static void create_BA(Graph theGraph, int n, int generalized) {
		int letter=0;
		LinkedList<Vertex> theQueue=new LinkedList();
		Vertex v0 = new Vertex(letter++,0);
		theGraph.addVertex(v0);
		theQueue.add(v0); // insert at tail
		int k=0; int j=0, level=0;
		int count=(int)Math.pow(2,n)-1;
		while( k<count ) { // until queue empty,
			Vertex v1 = theQueue.remove();
			int ind1 = v1.label;
			int data1 = v1.data;
			
			int data2 = data1+(int)Math.pow(2,level);
			System.out.println("ind1="+ind1+" data1="+data1+" data2="+data2);
			
			Vertex v2 = new Vertex(letter++,data2);
			Vertex v3 = new Vertex(letter++,data1);
			theGraph.addVertex(v2);
			theGraph.addVertex(v3);
			
			theQueue.add(v2);
			theQueue.add(v3);
			int ind2 = letter; 
			
			if (generalized==0) {
				theGraph.addEdge(ind1, ind2-2, "may", "A"+level);
				theGraph.addEdge(ind1, ind2-1, "may", "A"+level+"'");
			} else {
				theGraph.addEdge(ind1, ind2-2, "hyper", "A"+level);
				theGraph.addEdge(ind1, ind2-1, "hyper", "A"+level+"'");				
			}
			
			k++;j++;
			if (j>=(int)Math.pow(2,level)) {
				level++; j=0;
			}

		}
		
		while( theQueue.size()!=0 ) { 
			Vertex v1 = theQueue.remove();
			v1.displayVertex(0);
			int ind1 = v1.label;
			System.out.println("ind1 = "+ind1);
			int data1 = v1.data;
			theGraph.addEdge(ind1, ind1, "must", "true"); // AD
		}
	}
} // end class DFSApp