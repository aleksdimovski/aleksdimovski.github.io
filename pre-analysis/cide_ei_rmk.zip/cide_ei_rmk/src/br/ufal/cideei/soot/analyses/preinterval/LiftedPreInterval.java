package br.ufal.cideei.soot.analyses.preinterval;

import java.util.*;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;

import soot.*;
import soot.util.*;
import soot.jimple.*;
import soot.Unit;
import soot.Value;
import soot.jimple.AssignStmt;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.*;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.analyses.MapLiftedFlowSet;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.IFeatureRep;

/**
 * This implementation of the Reaching Definitions analysis uses a LiftedFlowSet
 * as a lattice element. The only major change is how its KILL method is
 * implemented. Everything else is quite similar to a 'regular' FlowSet-based
 * analysis.
 */
public class LiftedPreInterval extends ForwardFlowAnalysis<Unit, MapLifted<String>> {

	private UnitGraph g;
	private Collection<IConfigRep> configurations;
    private final static String TOP = "top";
    //private final static String BOTTOM = "bottom";
    private final static String STAR = "star";	

	// #ifdef METRICS
	private long flowThroughTimeAccumulator = 0;

	public long getFlowThroughTime() {
		return this.flowThroughTimeAccumulator;
	}

	protected static long flowThroughCounter = 0;

	public static long getFlowThroughCounter() {
		return flowThroughCounter;
	}

	private long L1flowThroughCounter = 0;

	public long getL1flowThroughCounter() {
		return L1flowThroughCounter;
	}

	public static void reset() {
		flowThroughCounter = 0;
	}

	// #endif

	/**
	 * Instantiates a new TestReachingDefinitions.
	 * 
	 * @param graph
	 *            the graph
	 */
	public LiftedPreInterval(DirectedGraph<Unit> graph, Collection<IConfigRep> configurations) {
		super(graph);
		this.configurations = configurations;
		this.g=(UnitGraph)graph;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#copy(java.lang.Object,
	 * java.lang.Object)
	 */
	@Override
	protected void copy(MapLifted<String> source, MapLifted<String> dest) {
		MapLifted<String> destLifted = (MapLifted<String>) dest;
		dest.clear();
		Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet = source.getMapping().entrySet();
		for (Entry<IConfigRep, HashMap<Value,String>> entry : entrySet) {
			IConfigRep key = entry.getKey();
			HashMap<Value,String> valueIn = (HashMap<Value,String>)entry.getValue();
			HashMap<Value,String> valueOut = new HashMap<Value,String>();
	        valueOut.putAll(valueIn);
			destLifted.set(key, valueOut);
		}
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#merge(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void merge(MapLifted<String> source1, MapLifted<String> source2, MapLifted<String> dest) {
		 MapLifted<String> otherLifted = (MapLifted<String>) source2;
		 MapLifted<String> destLifted = (MapLifted<String>) dest;
		
		 Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet = source1.getMapping().entrySet();
		 for (Entry<IConfigRep, HashMap<Value,String>> entry : entrySet) {
		 // key
			IConfigRep config = entry.getKey();
		 // val
			HashMap inMap1 = (HashMap) entry.getValue();
		
			HashMap inMap2 = (HashMap) otherLifted.getLattice(config);
			 
			HashMap<Value, String> outMap = (HashMap<Value, String>) destLifted.getLattice(config);

			Set keys = inMap1.keySet();
			Iterator it = keys.iterator();
			while (it.hasNext()) {
				Value var1 = (Value)it.next();
			        //System.out.println(var1);
				String inVal1 = (String)inMap1.get(var1);
			        //System.out.println(inVal1);
				String inVal2 = (String)inMap2.get(var1);
			        //System.out.println(inVal2);
			       // System.out.println("before out "+outMap.get(var1));

			     if (inVal2 == null) {outMap.put(var1, inVal1);}
				 else if ((inVal1.equals(STAR)) && (inVal2.equals(STAR))) {
						outMap.put(var1, STAR);
				 } else {
						outMap.put(var1, TOP);
				 }
				}
			 
			destLifted.set(config, outMap);
		 }
		 
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#entryInitialFlow()
	 */
	@Override
	protected MapLifted<String> entryInitialFlow() {
		return newInitialFlow();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#newInitialFlow()
	 */
	@Override
	protected MapLifted<String> newInitialFlow() {
		
		HashMap<IConfigRep,HashMap<Value, String>> map = new HashMap<IConfigRep, HashMap<Value, String>>();
		for (IConfigRep config : configurations) {
			
			HashMap<Value, String> initMap = new HashMap<Value, String>();
		
			Chain locals = g.getBody().getLocals();
			Iterator it = locals.iterator();
			while (it.hasNext()) {
				Local next = (Local)it.next();
            //System.out.println("next local: "+next);
				if ((next.getType() instanceof IntegerType) || (next.getType() instanceof LongType)){
					initMap.put(next, STAR);
				}
			}
    
			//Iterator boxIt = g.getBody().getUseAndDefBoxes().iterator();
			//while (boxIt.hasNext()){
			//	Value val = ((ValueBox)boxIt.next()).getValue();
			//	if (val instanceof ArithmeticConstant) {
			//		initMap.put(val, getProperty(initMap, val));
			//	}
			//}

  
        //return initMap;
			map.put(config, initMap);
		}
		
		return new MapLifted<String>(map);
	}

	
    private String getProperty(HashMap<Value, String> in, Value val) {
        //System.out.println("get Parity in: "+in);
        if  (val instanceof SubExpr) {
        	String resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        String resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.equals(TOP) | resVal2.equals(TOP)) {
                return TOP;
	        }  
	        else {
	            return TOP;
	        }
        }
        else if ((val instanceof AddExpr) | (val instanceof MulExpr)) {
	        String resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        String resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.equals(TOP) | resVal2.equals(TOP)) {
	            return TOP;
	        }
	        else if (resVal1.equals(STAR) && resVal2.equals(STAR)) {
	            return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (val instanceof IntConstant) {
	        int value = ((IntConstant)val).value;
	        if (value >= 0) {
                return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (val instanceof LongConstant) {
	        long value = ((LongConstant)val).value;
	        if (value >= 0) {
	            return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (in.containsKey(val)) {
      	    return in.get(val);
        }
        else {
            return TOP;
        }
     
    }	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.FlowAnalysis#flowThrough(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void flowThrough(MapLifted<String> source, Unit unit, MapLifted<String> dest) {
		//#ifdef CACHEPURGE
//@		br.Main.waste();
		//#endif

		// #ifdef METRICS
		flowThroughCounter++;
		long timeSpentOnFlowThrough = System.nanoTime();
		// #endif

		FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
		IFeatureRep featureRep = tag.getFeatureRep();

		Collection<IConfigRep> configs = source.getConfigurations();	
		for (IConfigRep config : configs) {
			HashMap<Value, String> in = source.getLattice(config);
			HashMap<Value, String> out = dest.getLattice(config);
	        Stmt s = (Stmt) unit;

		    
			if (config.belongsToConfiguration(featureRep)) {
				L1flowThroughCounter++;
			    out.putAll(in);
				
		        // for each stmt where leftOp is defintionStmt find the parity
			    // of rightOp and update parity to EVEN, ODD or TOP

		        //boolean useS = false;
		        
			    if (s instanceof DefinitionStmt) {
			        Value left = ((DefinitionStmt)s).getLeftOp();
			        if (left instanceof Local) {
		                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
		                    //useS = true;
			  	            Value right = ((DefinitionStmt)s).getRightOp();
				            out.put(left, getProperty(out, right));
		                }
			        }
			    }

			} else {
				// copy in to out 
			    out.putAll(in);
			}
			dest.set(config,out);
		}
		
	
		// #ifdef METRICS
		timeSpentOnFlowThrough = System.nanoTime() - timeSpentOnFlowThrough;
		this.flowThroughTimeAccumulator += timeSpentOnFlowThrough;
		// #endif
	}

	/**
	 * Creates a KILL set for the given unit and remove the elements that are in
	 * KILL from the destination FlowSet.
	 * 
	 * @param source
	 * @param unit
	 * @param dest
	 * @param configuration
	 */


	/**
	 * Creates a GEN set for a given Unit and add it to the FlowSet dest. In
	 * this case, our GEN set are all the definitions present in the unit.
	 * 
	 * @param dest
	 *            the dest
	 * @param unit
	 *            the unit
	 * @param configuration
	 */



	public void execute() {
		this.doAnalysis();
	}

}
