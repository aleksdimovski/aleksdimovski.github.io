/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

//#ifdef LAZY
package br.ufal.cideei.soot.analyses.wholeline;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;

import profiling.ProfilingTag;
import soot.Body;
import soot.BodyTransformer;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.initvars.LazyLiftedInitializedVariablesAnalysis;
import br.ufal.cideei.soot.analyses.uninitvars.LazyLiftedUninitializedVariableAnalysis;
import br.ufal.cideei.soot.analyses.uninitvars.SimpleUninitializedVariableAnalysis;
import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitConfigRep;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//TODO: can this class structure could be replaced by an abstract factory?
public class WholeLineLazyProjectUninitializedVariables extends BodyTransformer {

	private static WholeLineLazyProjectUninitializedVariables instance = new WholeLineLazyProjectUninitializedVariables();

	private WholeLineLazyProjectUninitializedVariables() {
	}

	public static WholeLineLazyProjectUninitializedVariables v() {
		return instance;
	}

	// #ifdef METRICS
	private static final String UV_LAZY_FLOWTHROUGH_COUNTER = "UV LAZY flowthrough";
	private static final String UV_LAZY_SHARING_DEGREE = "UV LAZY sharing drg";
	private static final String UV_LAZY_MEM = "UV LAZY mem";
	private static final String UV_LAZY_FLOWTHROUGH_TIME = "UV LAZY flowthrough time";
	private AbstractMetricsSink sink;

	public WholeLineLazyProjectUninitializedVariables setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		UnitGraph bodyGraph = new ExceptionalUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);
		int size = configTag.getConfigReps().iterator().next().size();

		LazyLiftedUninitializedVariableAnalysis lazyUninitializedVariables = null;
		boolean wentHybrid = false;

		// #ifdef METRICS
		long startAnalysis = System.nanoTime();
		// #endif

		
		Collection<IConfigRep> configs = configTag.getConfigReps();
		Collection<IConfigRep> project_configs = new HashSet<IConfigRep>(); //write this by looking in BitConfigRep.java
		int size_configs=configs.size();
		int project_size=size_configs/2;
		if (project_size==0) project_size++;
		
		//System.out.println("Pre Body "+body.getMethod().getDeclaringClass().getName()+"Orig. conf size "+size_configs+" new size "+project_size);
	
		
		if (configs.size()<=project_size) {
			project_configs=configs;
		}
		else {
			
			Random t = new Random();
			int[] project=new int[project_size];
			int[] pick=new int[project_size];
			
			for (int k=0;k<project_size;k++) {
				project[k]=t.nextInt(size_configs-project_size+k+1);
				size_configs=size_configs-project[k]-1;
			}
			
			pick[0]=project[0];
			for (int k=1;k<project_size;k++) {
				pick[k]=pick[k-1]+project[k]+1;
			}
			int i=0, j=0;
		    for (IConfigRep config : configs) {
			  if (i==pick[j]) {
				project_configs.add(config);
				j++;
				//BitConfigRep bitRep = (BitConfigRep) config;
				//System.out.println("Chosen Project Config is: "+bitRep.toString());
				if (j==project_size) break;
				//else j++;
				//random_config = t.nextInt(size_configs-random_config);
				// print info about the chosen random config
				//BitConfigRep bitRep = (BitConfigRep) config;
				//bitConfigId = bitRep.getId();
				
			  }
			 i++;
			}
		}
		System.out.println("UV Body "+body.getMethod().getDeclaringClass().getName()+"Orig. conf size "+configs.size()+" new size "+project_configs.size());
		
		
		
		// #ifdef HYBRID
//@		if (size == 1) {
//@			SimpleUninitializedVariableAnalysis uninitializedVariables = new SimpleUninitializedVariableAnalysis(bodyGraph);
//@			wentHybrid = true;
//@		} else {
			// #endif
			lazyUninitializedVariables = new LazyLiftedUninitializedVariableAnalysis(bodyGraph, (ILazyConfigRep) project_configs.iterator().next());
			// #ifdef HYBRID
//@		}
		// #endif

		// #ifdef METRICS
		long endAnalysis = System.nanoTime();

		if (!wentHybrid) {
			//this.sink.flow(body, UV_LAZY_FLOWTHROUGH_TIME, lazyUninitializedVariables.getFlowThroughTime());
//			this.sink.flow(body, UV_LAZY_MEM, FlowSetUtils.lazyMemoryUnits(body, lazyUninitializedVariables, true, 1, size));
			//this.sink.flow(body, UV_LAZY_SHARING_DEGREE, FlowSetUtils.averageSharingDegree(body, lazyUninitializedVariables));
			//this.sink.flow(body, UV_LAZY_FLOWTHROUGH_COUNTER, LazyLiftedUninitializedVariableAnalysis.getFlowThroughCounter());
			LazyLiftedUninitializedVariableAnalysis.reset();
		} 		

		this.sink.flow(body, "UV_LAZY_D-N/2", endAnalysis - startAnalysis);
		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		profilingTag.setUvAnalysisTime2(endAnalysis - startAnalysis);
		// #endif
	}
}

// #endif
