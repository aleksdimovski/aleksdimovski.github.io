package br.ufal.cideei.soot.analyses.interval;

import java.util.*;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;

import soot.*;
import soot.util.*;
import soot.jimple.*;
import soot.Unit;
import soot.Value;
import soot.jimple.AssignStmt;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.*;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.IFeatureRep;
import br.ufal.cideei.soot.analyses.interval.Interval;

/**
 * This implementation of the Reaching Definitions analysis uses a LiftedFlowSet
 * as a lattice element. The only major change is how its KILL method is
 * implemented. Everything else is quite similar to a 'regular' FlowSet-based
 * analysis.
 */
public class LiftedJoinInterval extends ForwardFlowAnalysis<Unit, HashMap<Value,Interval>> {

	private UnitGraph g;
	private Collection<IConfigRep> configurations;
    private final static String TOP = "top";
    //private final static String BOTTOM = "bottom";
    //private final static String STAR = "star";	

	private Integer[] B_arr;
	private int B_size;
	
	private int THRESHOLD=3;
	private HashMap<Stmt,Integer> visited=new HashMap<Stmt,Integer>();
	
	// #ifdef METRICS
	private long flowThroughTimeAccumulator = 0;

	public long getFlowThroughTime() {
		return this.flowThroughTimeAccumulator;
	}

	protected static long flowThroughCounter = 0;

	public static long getFlowThroughCounter() {
		return flowThroughCounter;
	}

	private long L1flowThroughCounter = 0;

	public long getL1flowThroughCounter() {
		return L1flowThroughCounter;
	}

	public static void reset() {
		flowThroughCounter = 0;
	}

	// #endif

	/**
	 * Instantiates a new TestReachingDefinitions.
	 * 
	 * @param graph
	 *            the graph
	 */
	public LiftedJoinInterval(DirectedGraph<Unit> graph, Collection<IConfigRep> configurations) {
		super(graph);
		this.configurations = configurations;
		this.g=(UnitGraph)graph;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#copy(java.lang.Object,
	 * java.lang.Object)
	 */
	@Override
	protected void copy(HashMap<Value,Interval> source, HashMap<Value,Interval> dest) {
        HashMap<Value,Interval> sourceIn = source;
        HashMap<Value,Interval> destOut = dest;
        //dest = new HashMap();
        //HashMap destOut = new HashMap();
        destOut.putAll(sourceIn);
        dest = destOut;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#merge(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void merge(HashMap<Value,Interval> source1, HashMap<Value,Interval>source2, HashMap<Value,Interval> dest) {
		HashMap<Value,Interval> inMap1 = source1;
		HashMap<Value,Interval> inMap2 = source2;
		HashMap<Value, Interval> outMap = dest;

		Set<Value> keys = inMap1.keySet();
		Iterator<Value> it = keys.iterator();
		while (it.hasNext()) {
		 	Value var1 = it.next();
			Interval inVal1 = (Interval)inMap1.get(var1);
			Interval inVal2 = (Interval)inMap2.get(var1);

	        if (inVal2 == null){
	            outMap.put(var1, inVal1);
	        }
			else if ((inVal1.isTop) || (inVal2.isTop)) {
				outMap.put(var1, new Interval(TOP));
			}
			else {
				Interval res=inVal1.join(inVal2);
				outMap.put(var1,res);
			}
		}
		 
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#entryInitialFlow()
	 */
	@Override
	protected HashMap<Value,Interval> entryInitialFlow() {

		HashSet<Integer> set=new HashSet<Integer>();
		set.add(new Integer(0));
		Iterator boxIt = g.getBody().getUseAndDefBoxes().iterator();
        while (boxIt.hasNext()){
            Value val = ((ValueBox)boxIt.next()).getValue();
            if (val instanceof IntConstant) {
				int value = ((IntConstant)val).value;
				set.add(new Integer(value));
            }
        }
        B_size=set.size();
        B_arr=new Integer[B_size];
        B_arr=set.toArray(B_arr);
		java.util.Arrays.sort(B_arr,0,B_size);		
		
		return newInitialFlow();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#newInitialFlow()
	 */
	@Override
	protected HashMap<Value,Interval> newInitialFlow() {
		
	    HashMap<Value, Interval> initMap = new HashMap<Value, Interval>();
		
	    Chain locals = g.getBody().getLocals();
	    Iterator it = locals.iterator();
	    while (it.hasNext()) {
            Local next = (Local)it.next();
            //System.out.println("next local: "+next);
            if ((next.getType() instanceof IntegerType) || (next.getType() instanceof LongType)){
	            initMap.put(next, new Interval(0,0));
            }
	    }
    
  
        return initMap;
	}

	
    private Interval getProperty(HashMap<Value, Interval> in, Value val) {
        //System.out.println("get Parity in: "+in);
        if  (val instanceof SubExpr) {
        	Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
                return new Interval(TOP);
	        }  
	        else {
	            return resVal1.sub(resVal2);
	        }
        }
        else if (val instanceof AddExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.add(resVal2);
	        }
        }
        else if (val instanceof MulExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.mul(resVal2);
	        }
        }		
        else if (val instanceof IntConstant) {
	        int value = ((IntConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
	            return new Interval(value,value);
	        }
        }
        else if (val instanceof LongConstant) {
	        long value = ((LongConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
				int v=(int)value;
	            return new Interval(v,v);
	        }
        }
        else if (in.containsKey(val)) {
      	    return in.get(val);
        }
        else {
            return new Interval(TOP);
        }
     
    }
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.FlowAnalysis#flowThrough(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void flowThrough(HashMap<Value,Interval> source, Unit unit, HashMap<Value,Interval> dest) {
		//#ifdef CACHEPURGE
		//@		br.Main.waste();
				//#endif

				// #ifdef METRICS
				flowThroughCounter++;
				long timeSpentOnFlowThrough = System.nanoTime();
				// #endif
				
		        /*System.out.println("source:");
		        for (Map.Entry<Value,Interval> entryVal : source.entrySet()) {
					System.out.println(entryVal.getKey()+" "+entryVal.getValue());
		        }*/
		        
		        HashMap<Value, Interval> in  = source;
		        HashMap<Value, Interval> out = dest;
		        //dest.clear();
				Stmt s = (Stmt) unit;
				
				int val_int=0;		
				if (visited.containsKey(s)) {
					Integer val = visited.get(s);
					val_int = val.intValue()+1;
					visited.put(s,new Integer(val_int));
				}
				else {
					visited.put(s,new Integer(1));
					val_int=1;
				}

				FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
				IFeatureRep featureRep = tag.getFeatureRep();

				
				int join=-1; // - 1=unknown; 0=all false; 1=all true; 2=some true, some false
				for (IConfigRep config : this.configurations) {
					if (config.belongsToConfiguration(featureRep)) {
						if (join==-1) join=1;
						if (join==0) {join=2;break;}
					} else {
						if (join==-1) join=0;
						if (join==1) {join=2;break;}
					}
				}

				//if (join==2) System.out.println("join "+join);
				
				if (join==0) {
					out.putAll(in);
			        //dest = out;
				} 
				else if ((join==1) || (join==2)) {
					L1flowThroughCounter++;
					out.putAll(in);
				    if (s instanceof DefinitionStmt) {
				        Value left = ((DefinitionStmt)s).getLeftOp();
				        if (left instanceof Local) {
			                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
			                    //useS = true;
				  	            Value right = ((DefinitionStmt)s).getRightOp();
								Interval newVal = getProperty(out, right);
								Interval oldVal = source.get(left); 
								//System.out.println(" var: "+left+" join="+join+" oldVal "+oldVal.toString()+" newVal: "+newVal.toString());
								if (join==2) { newVal = newVal.join(oldVal);
												//System.out.println(" newVal of "+left+" = "+right+" written: "+newVal.toString());
								}
								//System.out.println("WIDEN");
								//WIDEN here
								if (val_int>=THRESHOLD) {
									//System.out.println("WIDEN");
									
									Interval widenVal = oldVal.widen(newVal);
									out.put(left,widenVal);
									//System.out.println("Visited: "+s+" var: "+left+" old: "+oldVal.toString()+" new: "+newVal.toString()+" widen: "+widenVal.toString());
								}
					            else out.put(left,newVal);
			                }
				        }
				    } 
				    //dest=out;
				} 
				

		        //print dest
		        /*System.out.println("dest:");
		        for (Map.Entry<Value,Interval> entryVal : dest.entrySet()) {
					System.out.println(entryVal.getKey()+" "+entryVal.getValue());
		        }*/
				
				// #ifdef METRICS
				timeSpentOnFlowThrough = System.nanoTime() - timeSpentOnFlowThrough;
				this.flowThroughTimeAccumulator += timeSpentOnFlowThrough;
				// #endif
			}

	/**
	 * Creates a KILL set for the given unit and remove the elements that are in
	 * KILL from the destination FlowSet.
	 * 
	 * @param source
	 * @param unit
	 * @param dest
	 * @param configuration
	 */


	/**
	 * Creates a GEN set for a given Unit and add it to the FlowSet dest. In
	 * this case, our GEN set are all the definitions present in the unit.
	 * 
	 * @param dest
	 *            the dest
	 * @param unit
	 *            the unit
	 * @param configuration
	 */



	public void execute() {
		this.doAnalysis();
	}

}
