package br.ufal.cideei.soot.analyses.wholeline;

import java.io.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import profiling.ProfilingTag;
import soot.Body;
import soot.BodyTransformer;
import soot.Local;
import soot.Unit;
import soot.Value;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.handlers.DoAnalysisOnClassPath;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.analyses.preinterval.LazyLiftedPreInterval;
import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.util.count.AbstractMetricsSink;
import br.ufal.cideei.soot.analyses.*;

//XXX: can this class structure could be replaced by an abstract factory?
public class WholeLineLazyLiftedPreInterval extends BodyTransformer {

	private static WholeLineLazyLiftedPreInterval instance = new WholeLineLazyLiftedPreInterval();

	private WholeLineLazyLiftedPreInterval() {
	}

	public static WholeLineLazyLiftedPreInterval v() {
		return instance;
	}

	// #ifdef METRICS
	private static final String Pre_LAZY_FLOWTHROUGH_COUNTER = "Pre LAZY flowthrough";
	private static final String Pre_LAZY_SHARING_DEGREE = "Pre LAZY sharing drg";
	private static final String Pre_LAZY_MEM = "Pre LAZY mem";
	private static final String Pre_LAZY_FLOWTHROUGH_TIME = "Pre LAZY flowthrough time";
	private AbstractMetricsSink sink;

	public WholeLineLazyLiftedPreInterval setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		//if (body.getMethod().getName().equals("addWeight")) {
		UnitGraph bodyGraph = new ExceptionalUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);
		int size = configTag.getConfigReps().iterator().next().size();
		boolean wentHybrid = false;

		LazyLiftedPreInterval lazyPreInterval = null;
		
		//Collection<IConfigRep> configs = configTag.getConfigReps();
		//System.out.println("Size is "+size+"  "+configs.size());
		// #ifdef METRICS
		long startAnalysis = System.nanoTime();
		// #endif

		// #ifdef HYBRID
//@		if (size == 1) {
//@			wentHybrid = true;
//@			 SimpleReachingDefinitions simpleReachingDefinitions = new SimpleReachingDefinitions(bodyGraph);
//@		} else {
			// #endif
		
			lazyPreInterval = new LazyLiftedPreInterval(bodyGraph, (ILazyConfigRep) configTag.getConfigReps().iterator().next());
			lazyPreInterval.execute();
			// #ifdef HYBRID
//@		}
		// #endif

		// #ifdef METRICS

			int configs_total=0;
			boolean excludeTemp=true;
			
			int configs_star=0, configs_top=0;
			HashSet<Local> locals_star=new HashSet<Local>();
			HashSet<Local> locals_top=new HashSet<Local>();
			HashSet<Local> locals_total=new HashSet<Local>();			
			
		// #ifdef PRINT
//@
//@			try {
//@				
//@				FileWriter file = new FileWriter("C:\\AbsInterval\\Results\\output2.txt",true);
//@				PrintWriter pr_file = new PrintWriter(file);
//@				//pr_file.close();
//@				
//@				pr_file.println();
//@				pr_file.println(body.getMethod().getName());
//@				//pr_file.println(body.getTag(ConfigTag.CONFIG_TAG_NAME));		
//@				pr_file.println();
		// #endif				
				
			 	//for (Unit unit : body.getUnits()) {
					Unit unit = body.getUnits().getLast();
			 	//DoAnalysisOnClassPath.totalNodes++;
					
		// #ifdef PRINT			
//@			 		pr_file.println(unit + " [[" + unit.getTag(FeatureTag.FEAT_TAG_NAME) + "]]");
//@			 		pr_file.println(lazyPreInterval.getFlowAfter(unit));
		// #endif
			 		
			 		MapLifted<String> map = lazyPreInterval.getFlowAfter(unit);
			 		Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet = map.getMapping().entrySet();

					for (Entry<IConfigRep, HashMap<Value,String>> entry : entrySet) {
						IConfigRep key = entry.getKey();
						HashMap<Value,String> value = (HashMap<Value,String>)entry.getValue();
						//pr_file.println("Config "+key.toString());
						//pr_file.print("Pre-Property out: {");
						for (Map.Entry<Value,String> entryVal : value.entrySet()) {
							Value keyVal = entryVal.getKey();
							String thing = entryVal.getValue();
							if (keyVal instanceof Local) {
								Local l = (Local)keyVal;
								String name = l.getName();
								
								if (excludeTemp) {
									if (name != "this" && name.indexOf("$") == -1) {
										configs_total+=key.size();
										locals_total.add(l);
									}
								} else {
									configs_total+=key.size();
									locals_total.add(l);
								}
								
								if (!thing.equals("top")) {
									if (excludeTemp) {
										if (name != "this" && name.indexOf("$") == -1) {
											// #ifdef PRINT
//@											   pr_file.println("Var: "+name+" Type: "+l.getType()+" key size "+key.size());
											// #endif
											configs_star+=key.size();
											locals_star.add(l);
										}
									} else {
										configs_star+=key.size();
										locals_star.add(l);
									}
								} else if (thing.equals("top")) {
									if (excludeTemp) {
										if (name != "this" && name.indexOf("$") == -1) {
											configs_top+=key.size();
											locals_top.add(l);
										}
									} else {
										configs_top+=key.size();
										locals_top.add(l);
									}
								}								//Local l = (Local)keyVal;
								//pr_file.print(l.getType()+" "+l.getName()+" "+thing);
							}				
						}				
						//pr_file.println("}");		
						//pr_file.println("---------------------------------------");
						
					//}
					//if (isti) 
			 		//	{pr_file.println("Ista vrednost "+value); DoAnalysisOnClassPath.istiNodes++;units_same++;}
					//else { pr_file.println("Razlicna vrednost"); join=false;}
			 		//pr_file.println(lazyReachingDefinitions.getFlowAfter(unit).size());
					//}
				}
			 	//if (join) br.ufal.cideei.handlers.DoAnalysisOnClassPath.numberIsti++;
				this.sink.flow(body, "Con Lazy Pre *", configs_star);
				this.sink.flow(body, "Loc Lazy Pre *", locals_star.size());
				this.sink.flow(body, "Con Lazy Pre T", configs_top);
				this.sink.flow(body, "Loc Lazy Pre T", locals_top.size());
				this.sink.flow(body, "Con Lazy Pre All", configs_total);
				this.sink.flow(body, "Loc Lazy Pre All", locals_total.size());
		// #ifdef PRINT
//@				pr_file.close();
//@			} catch (IOException e) {
//@				System.out.println("Pecatenjeto e stopirano!");
//@			}/*//@		 if (body.getMethod().getSignature().contains("main(")) {
//@		 FlowSetUtils.pbm(body, lazyReachingDefinitions, System.getProperty("user.home") + File.separator +
//@		 "lazy-pix.pbm");
//@									
//@		 System.out.println(body.getTag(ConfigTag.CONFIG_TAG_NAME));
//@		 for (Unit unit : body.getUnits()) {
//@		 System.out.println(unit + " [[" + unit.getTag(FeatureTag.FEAT_TAG_NAME) + "]]");
//@		 System.out.println(lazyReachingDefinitions.getFlowAfter(unit));
//@		 }
//@		 }*/
		// #endif

		long endAnalysis = System.nanoTime();

		if (!wentHybrid) {
			//this.sink.flow(body, RD_LAZY_FLOWTHROUGH_TIME, lazyReachingDefinitions.getFlowThroughTime());
//			this.sink.flow(body, RD_LAZY_MEM, FlowSetUtils.lazyMemoryUnits(body, lazyReachingDefinitions, true, 1, configTag.getConfigReps().iterator().next().size()));
			//this.sink.flow(body, RD_LAZY_SHARING_DEGREE, FlowSetUtils.averageSharingDegree(body, lazyReachingDefinitions));
			//this.sink.flow(body, RD_LAZY_FLOWTHROUGH_COUNTER, LazyLiftedReachingDefinitions.getFlowThroughCounter());
			LazyLiftedPreInterval.reset();
		}

		if (configs_total==0) this.sink.flow(body, "pre_interval_LAZY", 0);
		else this.sink.flow(body, "pre_interval_LAZY", endAnalysis - startAnalysis);
		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		profilingTag.setRdAnalysisTime2(endAnalysis - startAnalysis);  //}
		// #endif
	}
}
