package br.ufal.cideei.soot.analyses.wholeline;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;


//#ifdef METRICS

//#ifdef OVERSEER
//@import ch.usi.overseer.OverHpc;
//@
//#endif
import profiling.ProfilingTag;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//#endif

import soot.Body;
import soot.BodyTransformer;
import soot.Unit;
import soot.Value;
import soot.Local;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.handlers.DoAnalysisOnClassPath;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.analyses.interval.LiftedJoinInterval;

import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.analyses.interval.Interval;

//TODO: can this class structure could be replaced by an abstract factory? 
public class WholeLineLiftedJoinInterval extends BodyTransformer {

	public WholeLineLiftedJoinInterval() {
	}

	// #ifdef METRICS
	
	//#ifdef OVERSEER
//@	private static final String RD_LIFTED_CACHE_MISSES = "RD A3 cache misses";
//@	static OverHpc ohpc=OverHpc.getInstance();
//@	
	//#endif
	
	private AbstractMetricsSink sink;

	public WholeLineLiftedJoinInterval setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		UnitGraph bodyGraph = new BriefUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);

		boolean wentHybrid = false;
		LiftedJoinInterval liftedInterval = null;
		
		long startAnalysis = System.nanoTime();


			liftedInterval = new LiftedJoinInterval(bodyGraph, configTag.getConfigReps());
			liftedInterval.execute();

			int configurations_total = configTag.getConfigReps().size();
			
			int configs_total=0;
			
			
			int configs_star=0, configs_top=0;
			HashSet<Local> locals_star=new HashSet<Local>();
			HashSet<Local> locals_top=new HashSet<Local>();
			HashSet<Local> locals_total=new HashSet<Local>();
			boolean excludeTemp=true;
			
			boolean join=true;
		 	for (Unit unit : body.getUnits()) {

		 		
		 		HashMap<Value,Interval> map = liftedInterval.getFlowAfter(unit);
		 		
				//Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet = map.getMapping().entrySet();

				//for (Entry<IConfigRep, HashMap<Value,Interval>> entry : entrySet) {
				//	IConfigRep key = entry.getKey();
				//	HashMap<Value,Interval> value = (HashMap<Value,Interval>)entry.getValue();
					for (Map.Entry<Value,Interval> entryVal : map.entrySet()) {
						Value keyVal = entryVal.getKey();
						Interval thing = entryVal.getValue();
						if (keyVal instanceof Local) {
							Local l = (Local)keyVal;
							String name = l.getName();
							if (excludeTemp) {
								if (name != "this" && name.indexOf("$") == -1) {
									//var_file.println("Var: "+name+" Type: "+l.getType());
									configs_total++;
									locals_total.add(l);
								}
							} else {
								configs_total++;
								locals_total.add(l);
							}
							
							if (!thing.isTop) {
								if (excludeTemp) {
									if (name != "this" && name.indexOf("$") == -1) {
										if ((thing.LB==-Interval.MAX) ||(thing.UB==Interval.MAX)) {
											configs_top++;
											locals_top.add(l);
										} else {
										configs_star++;
										locals_star.add(l);
										}
									}
								} else {
									configs_star++;
									locals_star.add(l);
								}
							} else if (thing.isTop) {
								if (excludeTemp) {
									if (name != "this" && name.indexOf("$") == -1) {
										configs_top++;
										locals_top.add(l);
									}
								} else {
									configs_top++;
									locals_top.add(l);
								}
							}

						}				
					}				

				}
		 	//}

			this.sink.flow(body, "Confs Join *", configs_star*configurations_total);
			this.sink.flow(body, "Locals Join *", locals_star.size());
			this.sink.flow(body, "Confs Join T", configs_top*configurations_total);
			this.sink.flow(body, "Locls Join T", locals_top.size());
			this.sink.flow(body, "Confs Join All", configs_total*configurations_total);
			//this.sink.flow(body, "Conf Join total", configurations_total);

			
		// #ifdef METRICS
		long endAnalysis = System.nanoTime();
		
		//#ifdef OVERSEER
//@		long cacheMissesFromThread = ohpc.getEventFromThread(threadId, 0);
//@		ohpc.stop();
//@		
		//#endif
		
		if (!wentHybrid) {
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_TIME, liftedReachingDefinitions.getFlowThroughTime());
			//this.sink.flow(body, RD_LIFTED_FLOWSET_MEM, FlowSetUtils.liftedMemoryUnits(body, liftedReachingDefinitions, false, 1));
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_COUNTER, LiftedReachingDefinitions.getFlowThroughCounter());
			//this.sink.flow(body, RD_LIFTED_L1_FLOWTHROUGH_COUNTER, liftedReachingDefinitions.getL1flowThroughCounter());
			//#ifdef OVERSEER
//@			this.sink.flow(body, RD_LIFTED_CACHE_MISSES, cacheMissesFromThread);
//@			
			//#endif
			
			LiftedJoinInterval.reset();
		}
		
		if (configs_total==0) this.sink.flow(body, "Inter_A-Join", 0);
		else this.sink.flow(body, "Inter_A-Join", endAnalysis - startAnalysis);
		
		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		profilingTag.setRdAnalysisTime2(endAnalysis - startAnalysis);
		// #endif
	}
}


