package br.ufal.cideei.soot.analyses.preinterval;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import soot.IntegerType;
import soot.Local;
import soot.LongType;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.ArithmeticConstant;
import soot.jimple.AssignStmt;
import soot.jimple.BinopExpr;
import soot.jimple.DefinitionStmt;
import soot.jimple.IntConstant;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import soot.util.Chain;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.analyses.interval.Interval;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.IFeatureRep;
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.util.Pair;

/**
 * This implementation of the Reaching Definitions analysis uses a LiftedFlowSet as a lattice element. The only major
 * change is how its KILL method is implemented. Everything else is quite similar to a 'regular' FlowSet-based analysis.
 */
public class LazyLiftedPreInterval extends ForwardFlowAnalysis<Unit, MapLifted<String>> {

	private UnitGraph g;
	private ILazyConfigRep configurations;
    private final static String TOP = "top";
    //private final static String BOTTOM = "bottom";
    private final static String STAR = "star";	

	// #ifdef METRICS
	private long flowThroughTimeAccumulator = 0;

	public long getFlowThroughTime() {
		return this.flowThroughTimeAccumulator;
	}

	protected static long flowThroughCounter = 0;

	public static long getFlowThroughCounter() {
		return flowThroughCounter;
	}

	public static void reset() {
		flowThroughCounter = 0;
	}

	// #endif

	/**
	 * Instantiates a new TestReachingDefinitions.
	 * 
	 * @param graph
	 *            the graph
	 */
	public LazyLiftedPreInterval(DirectedGraph<Unit> graph, ILazyConfigRep configs) {
		super(graph);
		this.configurations = configs;
		this.g=(UnitGraph)graph;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#copy(java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void copy(MapLifted<String> source, MapLifted<String> dest) {
		MapLifted<String> destLifted = (MapLifted<String>) dest;
		destLifted.clear();
		Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet = source.getMapping().entrySet();
		for (Entry<IConfigRep, HashMap<Value,String>> entry : entrySet) {
			IConfigRep key = entry.getKey();
			HashMap<Value,String> valueIn = (HashMap<Value,String>)entry.getValue();
			HashMap<Value,String> valueOut = new HashMap<Value,String>();
	        valueOut.putAll(valueIn);
			destLifted.set(key, valueOut);
		}
		//dest=destLifted;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#merge(java.lang.Object, java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void merge(MapLifted<String> source1, MapLifted<String> source2, MapLifted<String> dest) {
		 MapLifted<String> otherLifted = (MapLifted<String>) source2;
		 MapLifted<String> destLifted = (MapLifted<String>) dest;
		 destLifted.clear();
		
		 Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet = source1.getMapping().entrySet();
		 for (Entry<IConfigRep, HashMap<Value,String>> entry : entrySet) {
		 // key
			IConfigRep config = entry.getKey();
		 // val
			HashMap<Value, String> inMap1 = (HashMap<Value, String>) entry.getValue();	
			
			HashMap<Value, String> inMap2 = new HashMap<Value, String>();		 
			HashMap<Value, String> outMap = new HashMap<Value, String>();

			if (otherLifted.getLattice(config)!=null) {
				inMap2 =otherLifted.getLattice(config);	
				Set keys = inMap1.keySet();
				Iterator it = keys.iterator();
				while (it.hasNext()) {
					Value var1 = (Value)it.next();
			        //System.out.println(var1);
					String inVal1 = inMap1.get(var1);
			        //System.out.println(inVal1);
					//System.out.println("inMap2 "+inMap2+" var1 "+var1);
					String inVal2 = inMap2.get(var1);
			        //
			       // System.out.println("before out "+outMap.get(var1));

					if (inVal2 == null) {outMap.put(var1, inVal1);}
					else if ((inVal1.equals(STAR)) && (inVal2.equals(STAR))) {
					    //System.out.println("outMap "+outMap+" var1 "+var1);
						outMap.put(var1, STAR);
					} else {
						outMap.put(var1, TOP);
					}
				}
			 
				destLifted.set(config, new HashMap<Value, String>(outMap));
			}
			else { 
				String configS= config.toString();
				configS=configS.substring(1,configS.length()-1);
				
				Set<Entry<IConfigRep, HashMap<Value,String>>> entrySet2 = otherLifted.getMapping().entrySet();
				for (Entry<IConfigRep, HashMap<Value,String>> entry2 : entrySet2) {
					ILazyConfigRep config2 = (ILazyConfigRep)entry2.getKey();
					inMap2 = (HashMap<Value,String>) entry2.getValue();
					String config2S= config2.toString();
					config2S=config2S.substring(1,config2S.length()-1);
					//System.out.println("source2 config: "+config2S);
					//Set<IConfigRep> confs2= config2.getConfigs();
					if (subset(configS,config2S)) {
						//System.out.println("source1 is subset");
						Set keys = inMap1.keySet();
						Iterator it = keys.iterator();
						while (it.hasNext()) {
							Value var1 = (Value)it.next();
					        //System.out.println(var1);
							String inVal1 = inMap1.get(var1);
							String inVal2 = inMap2.get(var1);

							if (inVal2 == null) {outMap.put(var1, inVal1);}
							else if ((inVal1.equals(STAR)) && (inVal2.equals(STAR))) {
							    //System.out.println("outMap "+outMap+" var1 "+var1);
								outMap.put(var1, STAR);
							} else {
								outMap.put(var1, TOP);
							}
						}
						destLifted.set(config, new HashMap<Value,String>(outMap));
					} else if (subset(config2S,configS)) {
						//System.out.println("source2 is subset");
						Set keys = inMap1.keySet();
						Iterator it = keys.iterator();
						while (it.hasNext()) {
							Value var1 = (Value)it.next();
					        //System.out.println(var1);
							String inVal1 = inMap1.get(var1);
							String inVal2 = inMap2.get(var1);

							if (inVal2 == null) {outMap.put(var1, inVal1);}
							else if ((inVal1.equals(STAR)) && (inVal2.equals(STAR))) {
							    //System.out.println("outMap "+outMap+" var1 "+var1);
								outMap.put(var1, STAR);
							} else {
								outMap.put(var1, TOP);
							}
						}
						//System.out.println("config "+config2+" "+outMap);
						destLifted.set(config2, new HashMap<Value,String>(outMap));
					}
				}
			}
			
			
		 } // end for
	}

	public boolean subset(String s2, String s) {
		while (s2.contains(",")) {
			String found=s2.substring(0,s2.indexOf(","));
			s2=s2.substring(s2.indexOf(",")+2);
			if ((s.startsWith(found+", ")) || (s.endsWith(" "+found)) || (s.contains(" "+found+","))) continue;
			else return false;
		}
		if (!(s.startsWith(s2+", ")) && !(s.endsWith(" "+s2)) && !(s.contains(" "+s2+","))) return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#entryInitialFlow()
	 */
	@Override
	protected MapLifted<String> entryInitialFlow() {
		return newInitialFlow();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#newInitialFlow()
	 */
	@Override
	protected MapLifted<String> newInitialFlow() {
		
		HashMap<IConfigRep,HashMap<Value, String>> map = new HashMap<IConfigRep, HashMap<Value, String>>();
		//for (ILazyConfigRep config : configurations) {
		//ILazyConfigRep config = configurations;
		
			HashMap<Value, String> initMap = new HashMap<Value, String>();
		
			Chain locals = g.getBody().getLocals();
			Iterator it = locals.iterator();
			while (it.hasNext()) {
				Local next = (Local)it.next();
                //System.out.println("next local: "+next+" type: "+next.getType());
				if ((next.getType() instanceof IntegerType) || (next.getType() instanceof LongType)){
					initMap.put(next, STAR);
				}
			}
    
  
        //return initMap;
			map.put(configurations, initMap);
		//}
			//System.out.println("Initial "+map);
		
		return new MapLifted<String>(map);
	}


    private String getProperty(HashMap<Value, String> in, Value val) {
        //System.out.println("get Parity in: "+in);
        if  (val instanceof SubExpr) {
        	String resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        String resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.equals(TOP) | resVal2.equals(TOP)) {
                return TOP;
	        }  
	        else {
	            return TOP;
	        }
        }
        else if ((val instanceof AddExpr) | (val instanceof MulExpr)) {
	        String resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        String resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.equals(TOP) | resVal2.equals(TOP)) {
	            return TOP;
	        }
	        else if (resVal1.equals(STAR) && resVal2.equals(STAR)) {
	            return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (val instanceof IntConstant) {
	        int value = ((IntConstant)val).value;
	        if (value >= 0) {
                return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (val instanceof LongConstant) {
	        long value = ((LongConstant)val).value;
	        if (value >= 0) {
	            return STAR;
	        }
	        else {
	            return TOP;
	        }
        }
        else if (in.containsKey(val)) {
      	    return in.get(val);
        }
        else {
            return TOP;
        }
     
    }	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.FlowAnalysis#flowThrough(java.lang.Object, java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void flowThrough(MapLifted<String> source, Unit unit, MapLifted<String> dest) {
		// #ifdef METRICS
		flowThroughCounter++;
		long timeSpentOnFlowThrough = System.nanoTime();
		// #endif

		// pre-copy the information from source to dest
		//source.copy(dest);

		// get feature instrumentation for this unit
		Stmt s = (Stmt) unit;

		// get feature instrumentation for this unit
		FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
		IFeatureRep featureRep = tag.getFeatureRep();

		HashMap<IConfigRep, HashMap<Value, String>> destMapping = dest.getMapping();
		destMapping.clear();
		// iterate over all entries of the lazy flowset (source)
		HashMap<IConfigRep, HashMap<Value, String>> sourceMapping = source.getMapping();
		
	    if (!(s instanceof DefinitionStmt)) {
	    	//if (configurations.size()==106) System.out.println("stmt "+s);
	    	destMapping.putAll(sourceMapping); return; }
	    else {
	        Value left = ((DefinitionStmt)s).getLeftOp();
	        //System.out.println(left+" "+left.getType());
	        if ((!(left instanceof Local)) || (!(left.getType() instanceof IntegerType) && !(left.getType() instanceof LongType)))
	    	{ //System.out.println("here"); 
	    		destMapping.putAll(sourceMapping); return; }
		}		
		
		Iterator<Entry<IConfigRep, HashMap<Value, String>>> iterator = sourceMapping.entrySet().iterator();

		while (iterator.hasNext()) {
			Entry<IConfigRep, HashMap<Value, String>> entry = iterator.next();
			ILazyConfigRep lazyConfig = (ILazyConfigRep) entry.getKey();

			HashMap<Value, String> sourceFlowSet = entry.getValue();
			
			HashMap<Value, String> destFlowSet = new HashMap<Value, String>(); 
			//if	(dest.getLattice(lazyConfig)!=null) destFlowSet =dest.getLattice(lazyConfig);
			destFlowSet.putAll(sourceFlowSet);

			/*
			 * gets the set of configurations whose lattices should be passed to the transfer function.
			 * 
			 * applyToConfigurations = 0 => copy the lattice to dest
			 * 
			 * applyToConfigurations != 0 && applyToConfigurations == lazyConfig => apply the transfer function
			 * 
			 * applyToConfigurations != 0 && applyToConfigurations != lazyConfig => split and apply the transfer
			 * function (on who?)
			 * 
			 * the 1st case has already been addressed with the pre-copy
			 */
			Pair<ILazyConfigRep, ILazyConfigRep> split = lazyConfig.split(featureRep);
			ILazyConfigRep first = split.getFirst();
			
			if (first.size() != 0) {
				if (first.size() == lazyConfig.size()) {
					//destFlowSet.putAll(sourceFlowSet);
				    if (s instanceof DefinitionStmt) {
				        Value left = ((DefinitionStmt)s).getLeftOp();
				        if (left instanceof Local) {
			                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
			                    //useS = true;
				  	            Value right = ((DefinitionStmt)s).getRightOp();
					            
				  	          String newVal = getProperty(destFlowSet, right);
				  	          destFlowSet.put(left,newVal);				            
				  	           
				  	          destMapping.put(lazyConfig, new HashMap<Value,String>(destFlowSet)); // check this again?				            
			                }
				        }
				    }

				} else {
					//destFlowSet.putAll(sourceFlowSet);
					ILazyConfigRep second = split.getSecond();
					/*
					 * in this case, this lattice doesn't have a copy from the sourceFlowSet
					 */
					HashMap<Value, String> destToBeAppliedLattice = new HashMap<Value, String>();

					// apply point-wise transfer function
					destToBeAppliedLattice.putAll(sourceFlowSet);
				    if (s instanceof DefinitionStmt) {
				        Value left = ((DefinitionStmt)s).getLeftOp();
				        if (left instanceof Local) {
			                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
			                    //useS = true;
				  	            Value right = ((DefinitionStmt)s).getRightOp();				            
				  	          String newVal = getProperty(destToBeAppliedLattice, right);
				  	          destToBeAppliedLattice.put(left,newVal);
				  	          
				  	          destMapping.put(second, new HashMap<Value,String>(destFlowSet));
				  	          destMapping.put(first, new HashMap<Value,String>(destToBeAppliedLattice));
			                }
				        }
				    }

					/*
					 * make sure an empty config rep doesnt get into the lattice, or it will propagate garbage
					 */

				}
			} else {
				destMapping.put(lazyConfig, new HashMap<Value,String>(destFlowSet)); // check this again?
	            //System.out.println("lazyConfig copy: "+destFlowSet);
			}
		}
		// #ifdef METRICS
		timeSpentOnFlowThrough = System.nanoTime() - timeSpentOnFlowThrough;
		this.flowThroughTimeAccumulator += timeSpentOnFlowThrough;
		// #endif
	}


	public void execute() {
		this.doAnalysis();
	}

}
