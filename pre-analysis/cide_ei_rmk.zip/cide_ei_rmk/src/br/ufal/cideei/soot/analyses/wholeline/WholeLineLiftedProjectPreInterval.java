package br.ufal.cideei.soot.analyses.wholeline;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.*;

//#ifdef METRICS

//#ifdef OVERSEER
//@import ch.usi.overseer.OverHpc;
//@
//#endif
import profiling.ProfilingTag;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//#endif

import soot.Body;
import soot.BodyTransformer;
import soot.Unit;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.handlers.DoAnalysisOnClassPath;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.MapLiftedFlowSet;
import br.ufal.cideei.soot.analyses.reachingdefs.LiftedReachingDefinitions;
import br.ufal.cideei.soot.analyses.reachingdefs.SimpleReachingDefinitions;
import br.ufal.cideei.soot.analyses.preinterval.LiftedPreInterval;

import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitFeatureRep;
import br.ufal.cideei.soot.instrument.bitrep.BitConfigRep;

//TODO: can this class structure could be replaced by an abstract factory? 
public class WholeLineLiftedProjectPreInterval extends BodyTransformer {

	public WholeLineLiftedProjectPreInterval() {
	}

	// #ifdef METRICS
	
	//#ifdef OVERSEER
//@	private static final String RD_LIFTED_CACHE_MISSES = "RD A3 cache misses";
//@	static OverHpc ohpc=OverHpc.getInstance();
//@	
	//#endif
	
	private AbstractMetricsSink sink;

	public WholeLineLiftedProjectPreInterval setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		UnitGraph bodyGraph = new BriefUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);

		boolean wentHybrid = false;
		LiftedPreInterval liftedPreInterval = null;

		// #ifdef METRICS
		
		//#ifdef OVERSEER
//@		ohpc.initEvents("PERF_COUNT_HW_CACHE_MISSES");
//@		int threadId = ohpc.getThreadId();
//@		ohpc.bindEventsToThread(threadId);
//@		ohpc.stop();
//@		ohpc.start();
//@		
		//#endif
		
		long startAnalysis = System.nanoTime();

		// #endif

		//generate (extract) configurations we want to analyse (project on) 
		
		Collection<IConfigRep> configs = configTag.getConfigReps();
		Collection<IConfigRep> project_configs = new HashSet<IConfigRep>(); //write this by looking in BitConfigRep.java
		
		int size_configs=configs.size();
		int project_size=2;
		if (project_size==0) project_size++;
		
		//System.out.println("Pre Body "+body.getMethod().getDeclaringClass().getName()+"Orig. conf size "+size_configs+" new size "+project_size);
	
		
		if (configs.size()<=project_size) {
			project_configs=configs;
		}
		else {
			
			Random t = new Random();
			int[] project=new int[project_size];
			int[] pick=new int[project_size];
			
			for (int k=0;k<project_size;k++) {
				project[k]=t.nextInt(size_configs-project_size+k+1);
				size_configs=size_configs-project[k]-1;
			}
			
			pick[0]=project[0];
			for (int k=1;k<project_size;k++) {
				pick[k]=pick[k-1]+project[k]+1;
			}
			int i=0, j=0;
		    for (IConfigRep config : configs) {
			  if (i==pick[j]) {
				project_configs.add(config);
				j++;
				//BitConfigRep bitRep = (BitConfigRep) config;
				//System.out.println("Chosen Project Config is: "+bitRep.toString());
				if (j==project_size) break;
				//else j++;
				//random_config = t.nextInt(size_configs-random_config);
				// print info about the chosen random config
				//BitConfigRep bitRep = (BitConfigRep) config;
				//bitConfigId = bitRep.getId();
				
			  }
			 i++;
			}
		}
		//System.out.println("D_N/2 Body "+body.getMethod().getDeclaringClass().getName()+"Orig. conf size "+configs.size()+" new size "+project_configs.size());
		// #ifdef HYBRID
//@		if (configTag.size() == 1) {
//@			wentHybrid = true;
//@			simpleReachingDefinitions = new SimpleReachingDefinitions(bodyGraph);
//@		} else {
			// #endif
		liftedPreInterval = new LiftedPreInterval(bodyGraph, project_configs);
		liftedPreInterval.execute();
			// #ifdef HYBRID
//@		}
//@
		// #endif

			
		// #ifdef PRINT
//@
//@			
//@			/*//@		 if (body.getMethod().getSignature().contains("main(")) {
//@			 FlowSetUtils.pbm(body, lazyReachingDefinitions, System.getProperty("user.home") + File.separator +
//@			 "lazy-pix.pbm");
//@										
//@			 System.out.println(body.getTag(ConfigTag.CONFIG_TAG_NAME));
//@			 for (Unit unit : body.getUnits()) {
//@			 System.out.println(unit + " [[" + unit.getTag(FeatureTag.FEAT_TAG_NAME) + "]]");
//@			 System.out.println(lazyReachingDefinitions.getFlowAfter(unit));
//@			 }
//@			 }*/
			// #endif
			
			//int map_size=0;
		 	//for (Unit unit : body.getUnits()) {
		 	//	MapLiftedFlowSet map = liftedReachingDefinitions.getFlowAfter(unit);
		 	//	map_size = map.size();
		 	//}
			
			
		// #ifdef METRICS
		long endAnalysis = System.nanoTime();
		
		//#ifdef OVERSEER
//@		long cacheMissesFromThread = ohpc.getEventFromThread(threadId, 0);
//@		ohpc.stop();
//@		
		//#endif
		
		if (!wentHybrid) {
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_TIME, liftedReachingDefinitions.getFlowThroughTime());
			//this.sink.flow(body, RD_LIFTED_FLOWSET_MEM, FlowSetUtils.liftedMemoryUnits(body, liftedReachingDefinitions, false, 1));
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_COUNTER, LiftedReachingDefinitions.getFlowThroughCounter());
			//this.sink.flow(body, RD_LIFTED_L1_FLOWTHROUGH_COUNTER, liftedReachingDefinitions.getL1flowThroughCounter());
			//#ifdef OVERSEER
//@			this.sink.flow(body, RD_LIFTED_CACHE_MISSES, cacheMissesFromThread);
//@			
			//#endif
			
			LiftedPreInterval.reset();
		}

		
		this.sink.flow(body, "Pre_D-2", endAnalysis - startAnalysis);
		//this.sink.flow(body, "map size",map_size);
		//ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		//profilingTag.
		//profilingTag.setRdAnalysisTime2(endAnalysis - startAnalysis);
		// #endif
	}
}
