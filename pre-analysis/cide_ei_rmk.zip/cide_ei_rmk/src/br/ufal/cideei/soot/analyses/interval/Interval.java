package br.ufal.cideei.soot.analyses.interval;

public class Interval {

    public final static int MAX = 1000;

    public int LB;
	public int UB;
	public boolean isTop;


    public Interval(int l, int u){
		if (l <= u) {
			if (l<=-MAX) l=-MAX;
			if (u>=MAX) u=MAX;
			if (l==-MAX && u==MAX) {
				LB=l;
				UB=u;
				isTop=true;
			}
			else {
				LB=l;
				UB=u;
				isTop=false;
			}
		}
		else System.out.println("Not well-formed interval");
    }
	
	public Interval(String s){
        if (s.equals("top")) { LB=-MAX; UB=MAX; isTop=true; }
		else { LB=0; UB=0; isTop=false; }
    }
	
	public Interval join(Interval i2) {
		int lower;
		int upper;
		if (isTop || i2.isTop) return new Interval("top");
		else {
			if (LB<=i2.LB) lower=LB; else lower=i2.LB;
			if (UB>=i2.UB) upper=UB; else upper=i2.UB;
			if (lower==-MAX && upper==MAX) return new Interval("top");
			else return new Interval(lower,upper);
		}
	}

	public Interval add(Interval i2) {
		int lower;
		int upper;
		if (isTop || i2.isTop) return new Interval("top");
		else {
			lower=LB+i2.LB;
			upper=UB+i2.UB;
			if (lower<=-MAX) lower=-MAX; if (lower>=MAX) lower=MAX;
			if (upper>=MAX) upper=MAX; if (upper<=-MAX) upper=-MAX;
			if (lower==-MAX && upper==MAX) return new Interval("top");
			else return new Interval(lower,upper);
		}
	}

	public Interval sub(Interval i2) {
		int lower;
		int upper;
		if (isTop || i2.isTop) return new Interval("top");
		else {
			lower=LB-i2.UB;
			upper=UB-i2.LB;
			if (lower<=-MAX) lower=-MAX; if (lower>=MAX) lower=MAX;
			if (upper>=MAX) upper=MAX; if (upper<=-MAX) upper=-MAX;
			if (lower==-MAX && upper==MAX) return new Interval("top");
			else return new Interval(lower,upper);
		}
	}

	public Interval mul(Interval i2) {
		int lower;
		int upper;
		if (isTop || i2.isTop) return new Interval("top");
		else {
			int k1=LB*i2.LB;
			int k2=LB*i2.UB;
			int k3=UB*i2.LB;
			int k4=UB*i2.UB;
			
			if (k1<=k2 && k1<=k3 && k1<=k4) lower=k1;
			else if (k2<=k3 && k2<=k4) lower=k2;
			else if (k3<=k4) lower=k3; else lower=k4;
			
			if (k1>=k2 && k1>=k3 && k1>=k4) upper=k1;
			else if (k2>=k3 && k2>=k4) upper=k2;
			else if (k3>=k4) upper=k3; else upper=k4;		
			
			if (lower<=-MAX) lower=-MAX; if (lower>=MAX) lower=MAX;
			if (upper>=MAX) upper=MAX; if (upper<=-MAX) upper=-MAX;
			if (lower==-MAX && upper==MAX) return new Interval("top");
			else return new Interval(lower,upper);
		}
	}

	public Interval widen(Interval out) {
		int lower=0;
		int upper=0;
		//for (int j=0;j<B_size;j++) System.out.print(j+": "+B_arr[j]+" ");
		//System.out.println();
		if (out.LB<LB) { 
			if (out.LB<0) lower=-MAX;
			else lower=0;
		} else lower=LB;
		if (out.UB>UB) upper=MAX;			 
		else upper=UB;
		//System.out.println("IN WIDEN "+LB+" "+UB+" "+out.LB+" "+" "+out.UB+" "+lower+" "+" "+upper);
		if (lower==-MAX && upper==MAX) return new Interval("top");
		else return new Interval(lower,upper);
	}
	
	public Interval widen2(Interval out, Integer[] B_arr, int B_size) {
		int lower=0;
		int upper=0;
		//for (int j=0;j<B_size;j++) System.out.print(j+": "+B_arr[j]+" ");
		//System.out.println();
		if (out.LB<LB) { 
			boolean found=false;
			int i=B_size-1;
			//System.out.println("LB: "+LB+"out.LB: "+out.LB+" i: "+i);
			while ((!found) && (i>=0) ){
				if (B_arr[i]<=out.LB) {lower=B_arr[i]; found=true;}
				i--;
			}
			if (!found) lower=-MAX;
		} else lower=LB;
		if (out.UB>UB) {
			boolean found=false;
			int i=0;
			while ((!found) && (i<B_size) ){
				if (out.UB<=B_arr[i]) {upper=B_arr[i]; found=true;}
				i++;
			}
			if (!found) upper=MAX;			 
		} else upper=UB;
		//System.out.println("IN WIDEN "+LB+" "+UB+" "+out.LB+" "+" "+out.UB+" "+lower+" "+" "+upper);
		if (lower==-MAX && upper==MAX) return new Interval("top");
		else return new Interval(lower,upper);
	}
	
	public void print() {
		if (isTop) System.out.print(" TOP"); else System.out.print("LB: "+LB+" UB: "+UB);
		System.out.println();
	}
	
	public String toString() {
		String res="";
		if (isTop) res+=" TOP"; else res="LB: "+LB+" UB: "+UB;
		return res;
	}
	
	public boolean equals(Object obj) {
		//System.out.println("in equals ");
		if(obj instanceof Interval) {
			Interval i2 = (Interval)obj;
			if ((LB==i2.LB) && (UB==i2.UB)) return true;
			return false;
		}
		return false;
	}

}
