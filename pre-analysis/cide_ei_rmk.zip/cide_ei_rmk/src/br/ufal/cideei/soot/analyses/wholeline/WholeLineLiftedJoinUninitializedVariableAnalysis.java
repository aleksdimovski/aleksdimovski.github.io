/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;

//#ifdef METRICS
import profiling.ProfilingTag;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//#endif

import soot.Body;
import soot.BodyTransformer;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.uninitvars.LiftedUninitializedVariableAnalysis;
import br.ufal.cideei.soot.analyses.uninitvars.SimpleUninitializedVariableAnalysis;
import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.IConfigRep;

public class WholeLineLiftedJoinUninitializedVariableAnalysis extends BodyTransformer {

	// #ifdef METRICS
	private static final String UV_LIFTED_FLOWTHROUGH_COUNTER = "UV A3 flowthrough";
	private static final String UV_LIFTED_FLOWSET_MEM = "UV A3 mem";
	private static final String UV_LIFTED_FLOWTHROUGH_TIME = "UV A3 flowthrough time";
	private static final String UV_LIFTED_L1_FLOWTHROUGH_COUNTER = "UV A3 L1 flowthrough counter";
	private AbstractMetricsSink sink;

	public WholeLineLiftedJoinUninitializedVariableAnalysis setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		UnitGraph bodyGraph = new BriefUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);
		boolean wentHybrid = false;
		LiftedUninitializedVariableAnalysis liftedUninitializedVariableAnalysis = null;

		// #ifdef METRICS
		long startAnalysis = System.nanoTime();
		// #endif

		int project_size=1;
		Collection<IConfigRep> configs = configTag.getConfigReps();
		Collection<IConfigRep> project_configs = new HashSet<IConfigRep>(); //write this by looking in BitConfigRep.java
		int size_configs=configs.size();
		
		
		if (configs.size()<=project_size) {
			project_configs=configs;
		}
		else {
			
			Random t = new Random();
			int project=t.nextInt(size_configs);
			
			int i=0, j=0;
		    for (IConfigRep config : configs) {
			  if (i==project) {
				project_configs.add(config);
				j++;
				//BitConfigRep bitRep = (BitConfigRep) config;
				//System.out.println("Chosen Project Config is: "+bitRep.toString());
				if (j==project_size) break;
				//else j++;
				//random_config = t.nextInt(size_configs-random_config);
				// print info about the chosen random config
				//BitConfigRep bitRep = (BitConfigRep) config;
				//bitConfigId = bitRep.getId();
				
			  }
			 i++;
			}
		}
		// #ifdef HYBRID
//@		if (configTag.size() == 1) {
//@			wentHybrid = true;
//@			SimpleUninitializedVariableAnalysis simpleUninitializedVariables = new SimpleUninitializedVariableAnalysis(bodyGraph);
//@		} else {
			// #endif
			liftedUninitializedVariableAnalysis = new LiftedUninitializedVariableAnalysis(bodyGraph, project_configs);
			// #ifdef HYBRID
//@		}
		// #endif

		// #ifdef METRICS
		long endAnalysis = System.nanoTime();

		if (!wentHybrid) {
			//this.sink.flow(body, UV_LIFTED_FLOWTHROUGH_TIME, liftedUninitializedVariableAnalysis.getFlowThroughTime());
			//this.sink.flow(body, UV_LIFTED_FLOWSET_MEM, FlowSetUtils.liftedMemoryUnits(body, liftedUninitializedVariableAnalysis, false, 1));
			//this.sink.flow(body, UV_LIFTED_FLOWTHROUGH_COUNTER, LiftedUninitializedVariableAnalysis.getFlowThroughCounter());
			//this.sink.flow(body, UV_LIFTED_L1_FLOWTHROUGH_COUNTER, liftedUninitializedVariableAnalysis.getL1flowThroughCounter());
			LiftedUninitializedVariableAnalysis.reset();
		}

		this.sink.flow(body, "UV_D-1", endAnalysis - startAnalysis);
		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		profilingTag.setUvAnalysisTime(endAnalysis - startAnalysis);
		// #endif
	}

}
