package br.ufal.cideei.soot.analyses;


import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import soot.Value;
import soot.toolkits.scalar.AbstractFlowSet;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitVectorConfigRep;

public class MapLifted<T>  {
	protected HashMap<IConfigRep, HashMap<Value,T>> map;

	public HashMap<IConfigRep, HashMap<Value,T>> getMapping() {
		return map;
	}

	public MapLifted(Map<IConfigRep, HashMap<Value,T>> map) {
		this.map = new HashMap<IConfigRep, HashMap<Value,T>>(map);
	}

	public MapLifted(Collection<IConfigRep> configs) {
		map = new HashMap<IConfigRep, HashMap<Value,T>>();
		for (IConfigRep config : configs) {
			map.put(config, new HashMap<Value,T>());
		}
	}

	public MapLifted(IConfigRep seed) {
		map = new HashMap<IConfigRep, HashMap<Value,T>>();
		map.put(seed, new HashMap<Value,T>());
	}

	public HashMap<Value,T> getLattice(IConfigRep config) {
		return this.map.get(config);
	}

	public void set(IConfigRep config, HashMap<Value,T> o) {
		this.map.put(config,o);
	}
	
	/*@Override
	public MapLifted clone() {
		Set<Entry<IConfigRep, Object>> entrySet = map.entrySet();
		Map<IConfigRep, Object> newMap = new HashMap<IConfigRep, Object>();
		for (Entry<IConfigRep, Object> entry : entrySet) {
			newMap.put(entry.getKey(), (entry.getValue()).clone());
		}
		return new MapLifted(newMap);
	}*/

/*	//Override
	public void copy(Object dest) {
		MapLifted destLifted = (MapLifted) dest;
		//dest.clear();
		Set<Entry<IConfigRep, Object>> entrySet = map.entrySet();
		for (Entry<IConfigRep, Object> entry : entrySet) {
			IConfigRep key = entry.getKey();
			Object value = entry.getValue();
			destLifted.map.put(key, value);
		}
	}*/

	public Set<IConfigRep> getConfigurations() {
		return map.keySet();
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (this == o)
			return true;
		if (!(o instanceof MapLifted))
			return false;
		MapLifted<T> that = (MapLifted<T>) o;
		return new EqualsBuilder().append(this.map, that.map).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(this.map).toHashCode();
	}

	//Override
	public void clear() {
		map.clear();
	}

	//Override
/*	public void union(MapLifted aOther, MapLifted aDest) {
		// #ifdef LAZY
		MapLiftedFlowSet other = (MapLiftedFlowSet) aOther;
		MapLiftedFlowSet dest = (MapLiftedFlowSet) aDest;

		Set<Entry<IConfigRep, FlowSet>> entrySet = this.map.entrySet();
		Set<Entry<IConfigRep, FlowSet>> otherEntrySet = other.map.entrySet();

		HashMap<IConfigRep, FlowSet> destMap = new HashMap<IConfigRep, FlowSet>();

		for (Entry<IConfigRep, FlowSet> entry : entrySet) {
			for (Entry<IConfigRep, FlowSet> otherEntry : otherEntrySet) {
				ILazyConfigRep key = (ILazyConfigRep) entry.getKey();
				ILazyConfigRep otherKey = (ILazyConfigRep) otherEntry.getKey();

				ILazyConfigRep intersection = key.intersection(otherKey);
				if (intersection.size() != 0) {
					FlowSet otherFlowSet = otherEntry.getValue();
					ArraySparseSet destFlowSet = new ArraySparseSet();
					entry.getValue().union(otherFlowSet, destFlowSet);
					destMap.put(intersection, destFlowSet);
					
					if (intersection.equals(key)) {
						break;
					}
				}
			}
		}

		dest.map.clear();
		dest.map.putAll(destMap);
		// XXX replacing the two lines above with dest.map = destMap; could be much faster

		// #else
//@		 MapLifted otherLifted = (MapLifted) aOther;
//@		 MapLifted destLifted = (MapLifted) aDest;
//@		
//@		 Set<Entry<IConfigRep, Object>> entrySet = map.entrySet();
//@		 for (Entry<IConfigRep, Object> entry : entrySet) {
//@		 // key
//@		 IConfigRep config = entry.getKey();
//@		 // val
//@		 Object thisNormal = entry.getValue();
//@		
//@		 Object otherNormal = otherLifted.map.get(config);
//@		 if (otherNormal == null) {
//@		 otherNormal = new Object();
//@		 }
//@		
//@		 Object destNewFlowSet = new Object();
//@		 destLifted.map.put(config, destNewFlowSet);
//@		 thisNormal.union(otherNormal, destNewFlowSet);
//@		 }
		// #endif
	}*/

/*	@Override
	public void intersection(FlowSet aOther, FlowSet aDest) {
		// #ifdef LAZY
		MapLiftedFlowSet other = (MapLiftedFlowSet) aOther;
		MapLiftedFlowSet dest = (MapLiftedFlowSet) aDest;

		Set<Entry<IConfigRep, FlowSet>> entrySet = this.map.entrySet();
		Set<Entry<IConfigRep, FlowSet>> otherEntrySet = other.map.entrySet();

		HashMap<IConfigRep, FlowSet> destMap = new HashMap<IConfigRep, FlowSet>();

		for (Entry<IConfigRep, FlowSet> entry : entrySet) {
			for (Entry<IConfigRep, FlowSet> otherEntry : otherEntrySet) {
				ILazyConfigRep key = (ILazyConfigRep) entry.getKey();
				ILazyConfigRep otherKey = (ILazyConfigRep) otherEntry.getKey();

				ILazyConfigRep intersection = key.intersection(otherKey);
				if (intersection.size() != 0) {
					FlowSet otherFlowSet = otherEntry.getValue();
					ArraySparseSet destFlowSet = new ArraySparseSet();
					entry.getValue().intersection(otherFlowSet, destFlowSet);
					destMap.put(intersection, destFlowSet);
					
					if (intersection.equals(key)) {
						break;
					}
				}
			}
		}

		dest.map.clear();
		dest.map.putAll(destMap);
		// XXX replacing the two lines above with dest.map = destMap; could be much faster

		// #else
//@		 MapLiftedFlowSet otherLifted = (MapLiftedFlowSet) aOther;
//@		 MapLiftedFlowSet destLifted = (MapLiftedFlowSet) aDest;
//@		
//@		 Set<Entry<IConfigRep, FlowSet>> entrySet = map.entrySet();
//@		 for (Entry<IConfigRep, FlowSet> entry : entrySet) {
//@		 // key
//@		 IConfigRep config = entry.getKey();
//@		 // val
//@		 FlowSet thisNormal = entry.getValue();
//@		
//@		 FlowSet otherNormal = otherLifted.map.get(config);
//@		 if (otherNormal == null) {
//@		 otherNormal = new ArraySparseSet();
//@		 }
//@		
//@		 ArraySparseSet destNewFlowSet = new ArraySparseSet();
//@		 destLifted.map.put(config, destNewFlowSet);
//@		 thisNormal.intersection(otherNormal, destNewFlowSet);
//@		 }
		// #endif
	}*/

	public HashMap<Value,T> add(IConfigRep config, HashMap<Value,T> flow) {
		return map.put(config, flow);
	}

	//Override
	public void add(Object arg0) {
		throw new UnsupportedOperationException();
	}

	//Override
	public boolean contains(Object arg0) {
		throw new UnsupportedOperationException();
	}

	//Override
	public boolean isEmpty() {
		throw new UnsupportedOperationException();
	}

	//Override
	public void remove(Object arg0) {
		throw new UnsupportedOperationException();
	}

	//Override
	public int size() {
		return this.map.size();
	}

	//Override
	public List toList() {
		throw new UnsupportedOperationException();
	}

	//Override
	public String toString() {
		return map.toString();
	}
}
