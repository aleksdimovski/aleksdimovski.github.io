package br.ufal.cideei.soot.analyses.interval;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import soot.IntegerType;
import soot.Local;
import soot.LongType;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.ArithmeticConstant;
import soot.jimple.AssignStmt;
import soot.jimple.BinopExpr;
import soot.jimple.DefinitionStmt;
import soot.jimple.IntConstant;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import soot.util.Chain;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.IFeatureRep;
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.util.Pair;
import br.ufal.cideei.soot.analyses.interval.Interval;

/**
 * This implementation of the Reaching Definitions analysis uses a LiftedFlowSet as a lattice element. The only major
 * change is how its KILL method is implemented. Everything else is quite similar to a 'regular' FlowSet-based analysis.
 */
public class LazyLiftedInterval extends ForwardFlowAnalysis<Unit, MapLifted<Interval>> {

	private UnitGraph g;
	private ILazyConfigRep configurations;
    private final static String TOP = "top";
    //private final static String BOTTOM = "bottom";
    //private final static String STAR = "star";	

	private Integer[] B_arr;
	private int B_size;
	
	private int THRESHOLD=4;
	private HashMap<Stmt,Integer> visited=new HashMap<Stmt,Integer>();    
    
	// #ifdef METRICS
	private long flowThroughTimeAccumulator = 0;

	public long getFlowThroughTime() {
		return this.flowThroughTimeAccumulator;
	}

	protected static long flowThroughCounter = 0;

	public static long getFlowThroughCounter() {
		return flowThroughCounter;
	}

	public static void reset() {
		flowThroughCounter = 0;
	}

	// #endif

	/**
	 * Instantiates a new TestReachingDefinitions.
	 * 
	 * @param graph
	 *            the graph
	 */
	public LazyLiftedInterval(DirectedGraph<Unit> graph, ILazyConfigRep configs) {
		super(graph);
		this.configurations = configs;
		this.g=(UnitGraph)graph;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#copy(java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void copy(MapLifted<Interval> source, MapLifted<Interval> dest) {
		MapLifted<Interval> destLifted = (MapLifted<Interval>) dest;
		destLifted.clear();
		Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet = source.getMapping().entrySet();
		for (Entry<IConfigRep, HashMap<Value,Interval>> entry : entrySet) {
			IConfigRep key = entry.getKey();
			HashMap<Value,Interval> valueIn = (HashMap<Value,Interval>)entry.getValue();
			HashMap<Value,Interval> valueOut = new HashMap<Value,Interval>();
	        valueOut.putAll(valueIn);
			destLifted.set(key, valueOut);
		}
		//dest=destLifted;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#merge(java.lang.Object, java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void merge(MapLifted<Interval> source1, MapLifted<Interval> source2, MapLifted<Interval> dest) {
		 MapLifted<Interval> otherLifted = (MapLifted<Interval>) source2;
		 MapLifted<Interval> destLifted = (MapLifted<Interval>) dest;
		 destLifted.clear(); // added here
		 
		 //System.out.println("merge in ");
		 //System.out.println("source1 ");
		 print(source1.getMapping(),"sizeAV");
		 //System.out.println("source2 ");
		 print(source2.getMapping(),"sizeAV");
		
		 Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet = source1.getMapping().entrySet();
		 for (Entry<IConfigRep, HashMap<Value,Interval>> entry : entrySet) {
		 // key
			ILazyConfigRep config = (ILazyConfigRep)entry.getKey();
		 // val
			HashMap<Value, Interval> inMap1 = (HashMap<Value, Interval>) entry.getValue();		
			
			HashMap<Value, Interval> outMap = new HashMap<Value, Interval>();
			HashMap<Value, Interval> inMap2 = new HashMap<Value, Interval>();
			
			if (otherLifted.getLattice(config)!=null) {
				inMap2 =otherLifted.getLattice(config);	
				Set keys = inMap1.keySet();
				Iterator it = keys.iterator();
				while (it.hasNext()) {
					Value var1 = (Value)it.next();
					Interval inVal1 = (Interval)inMap1.get(var1);
			        //System.out.println(inVal1);
					Interval inVal2 = (Interval)inMap2.get(var1);

				    if (inVal2 == null) {outMap.put(var1, inVal1);}
					else if ((inVal1.isTop) || (inVal2.isTop)) {
						outMap.put(var1, new Interval(TOP));
					} else {
						Interval res=inVal1.join(inVal2);
						outMap.put(var1,res);
					}
				}
				 
				destLifted.set(config, new HashMap<Value, Interval>(outMap));
			}
			else { 
				//Set<IConfigRep> confs= config.getConfigs();
				String configS= config.toString();
				configS=configS.substring(1,configS.length()-1);
				//System.out.println("source1 config: "+configS);
				/*Set<String> configSet=convertToSet(configS.substring(1,configS.length()-1));
				Iterator<String> is=configSet.iterator();
				while (is.hasNext()) {
					System.out.print(is.next()+" ");
				}
				System.out.println();*/
				//for (int k=0;k<config.size();k++) System.out.print(config);
				
				
				Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet2 = otherLifted.getMapping().entrySet();
				for (Entry<IConfigRep, HashMap<Value,Interval>> entry2 : entrySet2) {
					ILazyConfigRep config2 = (ILazyConfigRep)entry2.getKey();
					inMap2 = (HashMap<Value, Interval>) entry2.getValue();
					String config2S= config2.toString();
					config2S=config2S.substring(1,config2S.length()-1);
					//System.out.println("source2 config: "+config2S);
					//Set<IConfigRep> confs2= config2.getConfigs();
					if (subset(configS,config2S)) {
						//System.out.println("source1 is subset");
						Set keys = inMap1.keySet();
						Iterator it = keys.iterator();
						while (it.hasNext()) {
							Value var1 = (Value)it.next();
							Interval inVal1 = (Interval)inMap1.get(var1);
					        //System.out.println(inVal1);
							Interval inVal2 = (Interval)inMap2.get(var1);

						    if (inVal2 == null) {outMap.put(var1, inVal1);}
							else if ((inVal1.isTop) || (inVal2.isTop)) {
								outMap.put(var1, new Interval(TOP));
							} else {
								Interval res=inVal1.join(inVal2);
								outMap.put(var1,res);
							}
						}
						destLifted.set(config, new HashMap<Value, Interval>(outMap));
					} else if (subset(config2S,configS)) {
						//System.out.println("source2 is subset");
						Set keys = inMap1.keySet();
						Iterator it = keys.iterator();
						while (it.hasNext()) {
							Value var1 = (Value)it.next();
							Interval inVal1 = (Interval)inMap1.get(var1);
					        //System.out.println(inVal1);
							Interval inVal2 = (Interval)inMap2.get(var1);

						    if (inVal2 == null) {outMap.put(var1, inVal1);}
							else if ((inVal1.isTop) || (inVal2.isTop)) {
								outMap.put(var1, new Interval(TOP));
							} else {
								Interval res=inVal1.join(inVal2);
								outMap.put(var1,res);
							}
						}
						//System.out.println("config "+config2+" "+outMap);
						destLifted.set(config2, new HashMap<Value, Interval>(outMap));
					}
				}
			}
			

		 } // end for
		 
		 //System.out.println("dest ");
		 print(dest.getMapping(),"sizeAV");
	}


	public void print(HashMap<IConfigRep, HashMap<Value,Interval>> hm,String var) {
		Set<IConfigRep> hm_keys=hm.keySet();
		Iterator<IConfigRep> it_keys=hm_keys.iterator();
		while (it_keys.hasNext()) {
			IConfigRep config=it_keys.next();
			HashMap<Value,Interval> hm_values=hm.get(config);
			Set<Value> hm_val = hm_values.keySet();
			Iterator<Value> it_values=hm_val.iterator();
			while (it_values.hasNext()) {
				Value val=it_values.next();
				if (var.equals(val.toString()));
					//System.out.println("config "+config+" var "+val+" value "+hm_values.get(val));
			}
		}
	}
	
	
	public Set<String> convertToSet(String configs) {
		Set<String> cs= new HashSet<String>();
		while (configs.contains(",")) {
				String found=configs.substring(0,configs.indexOf(","));
				cs.add(found);
				configs=configs.substring(configs.indexOf(",")+2);
		}
		cs.add(configs);
		return cs;
	}
	
	
	public boolean subset(String s2, String s) {
		while (s2.contains(",")) {
			String found=s2.substring(0,s2.indexOf(","));
			s2=s2.substring(s2.indexOf(",")+2);
			if ((s.startsWith(found+", ")) || (s.endsWith(" "+found)) || (s.contains(" "+found+","))) continue;
			else return false;
		}
		if (!(s.startsWith(s2+", ")) && !(s.endsWith(" "+s2)) && !(s.contains(" "+s2+","))) return false;
		return true;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#entryInitialFlow()
	 */
	@Override
	protected MapLifted<Interval> entryInitialFlow() {
		
		HashSet<Integer> set=new HashSet<Integer>();
		set.add(new Integer(0));
		Iterator boxIt = g.getBody().getUseAndDefBoxes().iterator();
        while (boxIt.hasNext()){
            Value val = ((ValueBox)boxIt.next()).getValue();
            if (val instanceof IntConstant) {
				int value = ((IntConstant)val).value;
				set.add(new Integer(value));
            }
        }
        B_size=set.size();
        B_arr=new Integer[B_size];
        B_arr=set.toArray(B_arr);
		java.util.Arrays.sort(B_arr,0,B_size);				
		
		return newInitialFlow();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#newInitialFlow()
	 */
	@Override
	protected MapLifted<Interval> newInitialFlow() {
		
		HashMap<IConfigRep,HashMap<Value, Interval>> map = new HashMap<IConfigRep, HashMap<Value, Interval>>();
		//for (ILazyConfigRep config : configurations) {
		//ILazyConfigRep config = configurations;
		
			HashMap<Value, Interval> initMap = new HashMap<Value, Interval>();
		
			Chain locals = g.getBody().getLocals();
			Iterator it = locals.iterator();
			while (it.hasNext()) {
				Local next = (Local)it.next();
            //System.out.println("next local: "+next);
				if ((next.getType() instanceof IntegerType) || (next.getType() instanceof LongType)){
					initMap.put(next, new Interval(0,0));
				}
			}
    
			map.put(configurations, initMap);
		
		return new MapLifted<Interval>(map);
	}


    private Interval getProperty(HashMap<Value, Interval> in, Value val) {
        //System.out.println("get Parity in: "+in);
        if  (val instanceof SubExpr) {
        	Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
                return new Interval(TOP);
	        }  
	        else {
	            return resVal1.sub(resVal2);
	        }
        }
        else if (val instanceof AddExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.add(resVal2);
	        }
        }
        else if (val instanceof MulExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.mul(resVal2);
	        }
        }		
        else if (val instanceof IntConstant) {
	        int value = ((IntConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
	            return new Interval(value,value);
	        }
        }
        else if (val instanceof LongConstant) {
	        long value = ((LongConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
				int v=(int)value;
	            return new Interval(v,v);
	        }
        }
        else if (in.containsKey(val)) {
      	    return in.get(val);
        }
        else {
            return new Interval(TOP);
        }
     
    }
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.FlowAnalysis#flowThrough(java.lang.Object, java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void flowThrough(MapLifted<Interval> source, Unit unit, MapLifted<Interval> dest) {
		// #ifdef METRICS
		flowThroughCounter++;
		long timeSpentOnFlowThrough = System.nanoTime();
		// #endif

		Stmt s = (Stmt) unit;
		
		int val_int=0;		
		if (visited.containsKey(s)) {
			Integer val = visited.get(s);
			val_int = val.intValue()+1;
			visited.put(s,new Integer(val_int));
		}
		else {
			visited.put(s,new Integer(1));
			val_int=1;
		}

		// get feature instrumentation for this unit
		FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
		IFeatureRep featureRep = tag.getFeatureRep();

		HashMap<IConfigRep, HashMap<Value, Interval>> destMapping = dest.getMapping();
		HashMap<IConfigRep, HashMap<Value, Interval>> sourceMapping = source.getMapping();
		//System.out.println("stm: "+s);
		//System.out.println(" source "+sourceMapping);
		//System.out.println(" dest "+destMapping);
		//System.out.println();
		destMapping.clear();

		// iterate over all entries of the lazy flowset (source)
		
		Iterator<Entry<IConfigRep, HashMap<Value, Interval>>> iterator = sourceMapping.entrySet().iterator();

		
	    if (!(s instanceof DefinitionStmt)) {
	    	//if (configurations.size()==106) System.out.println("stmt "+s);
	    	destMapping.putAll(sourceMapping); return; }
	    else {
	        Value left = ((DefinitionStmt)s).getLeftOp();
	        //System.out.println(left+" "+left.getType());
	        if ((!(left instanceof Local)) || (!(left.getType() instanceof IntegerType) && !(left.getType() instanceof LongType)))
	    	{ //System.out.println("here"); 
	    		destMapping.putAll(sourceMapping); return; }
		}
		
		while (iterator.hasNext()) {
			Entry<IConfigRep, HashMap<Value, Interval>> entry = iterator.next();
			ILazyConfigRep lazyConfig = (ILazyConfigRep) entry.getKey();
			
			//System.out.println("lazyconfig: "+lazyConfig);

			HashMap<Value, Interval> sourceFlowSet = entry.getValue();			
			HashMap<Value, Interval> destFlowSet = new HashMap<Value, Interval>(); 
			
			//if	(dest.getLattice(lazyConfig)!=null) destFlowSet =dest.getLattice(lazyConfig);
			destFlowSet.putAll(sourceFlowSet);

			/*
			 * gets the set of configurations whose lattices should be passed to the transfer function.
			 * 
			 * applyToConfigurations = 0 => copy the lattice to dest
			 * 
			 * applyToConfigurations != 0 && applyToConfigurations == lazyConfig => apply the transfer function
			 * 
			 * applyToConfigurations != 0 && applyToConfigurations != lazyConfig => split and apply the transfer
			 * function (on who?)
			 * 
			 * the 1st case has already been addressed with the pre-copy
			 */
			Pair<ILazyConfigRep, ILazyConfigRep> split = lazyConfig.split(featureRep);
			ILazyConfigRep first = split.getFirst();
			
			//System.out.println("split first: "+first);
			
			if (first.size() != 0) {
				if (first.size() == lazyConfig.size()) {
					//destFlowSet.putAll(sourceFlowSet);
				    if (s instanceof DefinitionStmt) {
				        Value left = ((DefinitionStmt)s).getLeftOp();
				        if (left instanceof Local) {
			                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
			                    //useS = true;
				  	            Value right = ((DefinitionStmt)s).getRightOp();
					            
								Interval newVal = getProperty(destFlowSet, right);
								//WIDEN here
								if (val_int>=THRESHOLD) {
									//System.out.println("WIDEN");
									Interval oldVal = destFlowSet.get(left);
									Interval widenVal = oldVal.widen2(newVal,B_arr,B_size);
									destFlowSet.put(left,widenVal);
									//System.out.println("Visited: "+s+" var: "+left+" old: "+oldVal.toString()+" new: "+newVal.toString()+" widen: "+widenVal.toString());
								}
					            else destFlowSet.put(left,newVal);			
								
					            destMapping.put(lazyConfig, new HashMap<Value, Interval>(destFlowSet)); // check this again?
					            //System.out.println("lazyConfig copy: "+left+" "+destFlowSet);
			                }
				        }
				    }

				} else {
					//destFlowSet.putAll(sourceFlowSet);
					ILazyConfigRep second = split.getSecond();
					//System.out.println("split second: "+second);
					/*
					 * in this case, this lattice doesn't have a copy from the sourceFlowSet
					 */
					HashMap<Value, Interval> destToBeAppliedLattice = new HashMap<Value, Interval>();

					// apply point-wise transfer function
					destToBeAppliedLattice.putAll(sourceFlowSet);
				    if (s instanceof DefinitionStmt) {
				        Value left = ((DefinitionStmt)s).getLeftOp();
				        if (left instanceof Local) {
			                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
			                    //useS = true;
				  	            Value right = ((DefinitionStmt)s).getRightOp();				            
								Interval newVal = getProperty(destToBeAppliedLattice, right);
								//WIDEN here
								if (val_int>=THRESHOLD) {
									Interval oldVal = destToBeAppliedLattice.get(left);
									Interval widenVal = oldVal.widen2(newVal,B_arr,B_size);
									destToBeAppliedLattice.put(left,widenVal);
									//System.out.println("Visited: "+s+" var: "+left+" old: "+oldVal.toString()+" new: "+newVal.toString()+" widen: "+widenVal.toString());
								}
					            else destToBeAppliedLattice.put(left,newVal);	
								
								destMapping.put(second, new HashMap<Value, Interval>(destFlowSet));
								destMapping.put(first, new HashMap<Value, Interval>(destToBeAppliedLattice));
								//System.out.println("lazyConfig split: "+left+" "+destToBeAppliedLattice);
			                }
				        }
				    }

					/*
					 * make sure an empty config rep doesnt get into the lattice, or it will propagate garbage
					 */
					//if (second.size() != 0) {
					//	destMapping.put(second, destFlowSet);
						//mozebi tuka treba da stavam brojac 
					//}

					// add the new lattice
					//destMapping.put(first, destToBeAppliedLattice);

					// remove config rep that has been split
					//destMapping.remove(lazyConfig);
				}
			} else {
				destMapping.put(lazyConfig, new HashMap<Value, Interval>(destFlowSet)); // check this again?
	            //System.out.println("lazyConfig copy: "+destFlowSet);
			}
		}
		print(dest.getMapping(),"sizeAV");
		// #ifdef METRICS
		timeSpentOnFlowThrough = System.nanoTime() - timeSpentOnFlowThrough;
		this.flowThroughTimeAccumulator += timeSpentOnFlowThrough;
		// #endif
	}


	public void execute() {
		this.doAnalysis();
	}

}
