package br.ufal.cideei.soot.analyses.interval;

import java.util.*;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import soot.*;
import soot.util.*;
import soot.jimple.*;
import soot.IntegerType;
import soot.Local;
import soot.LongType;
import soot.Unit;
import soot.Value;
import soot.jimple.AssignStmt;
import soot.toolkits.graph.*;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import br.ufal.cideei.soot.analyses.MapLifted;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.IFeatureRep;
import br.ufal.cideei.soot.analyses.interval.Interval;

/**
 * This implementation of the Reaching Definitions analysis uses a LiftedFlowSet
 * as a lattice element. The only major change is how its KILL method is
 * implemented. Everything else is quite similar to a 'regular' FlowSet-based
 * analysis.
 */
public class LiftedInterval extends ForwardFlowAnalysis<Unit, MapLifted<Interval>> {

	private UnitGraph g;
	private Collection<IConfigRep> configurations;
    private final static String TOP = "top";
    //private final static String BOTTOM = "bottom";
    //private final static String STAR = "star";	

	private Integer[] B_arr;
	private int B_size;
	
	private int THRESHOLD=5;
	private HashMap<Stmt,Integer> visited=new HashMap<Stmt,Integer>();
	
	// #ifdef METRICS
	private long flowThroughTimeAccumulator = 0;

	public long getFlowThroughTime() {
		return this.flowThroughTimeAccumulator;
	}

	protected static long flowThroughCounter = 0;

	public static long getFlowThroughCounter() {
		return flowThroughCounter;
	}

	private long L1flowThroughCounter = 0;

	public long getL1flowThroughCounter() {
		return L1flowThroughCounter;
	}

	public static void reset() {
		flowThroughCounter = 0;
	}

	// #endif

	/**
	 * Instantiates a new TestReachingDefinitions.
	 * 
	 * @param graph
	 *            the graph
	 */
	public LiftedInterval(DirectedGraph<Unit> graph, Collection<IConfigRep> configurations) {
		super(graph);
		this.configurations = configurations;
		this.g=(UnitGraph)graph;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#copy(java.lang.Object,
	 * java.lang.Object)
	 */
	@Override
	protected void copy(MapLifted<Interval> source, MapLifted<Interval> dest) {
		
		//System.out.println("copy ");
		 //System.out.println("source ");
		// print(source.getMapping(),"recoveringTransaction");

		MapLifted<Interval> destLifted = dest;
		dest.clear();
		Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet = source.getMapping().entrySet();
		for (Entry<IConfigRep, HashMap<Value,Interval>> entry : entrySet) {
			IConfigRep key = entry.getKey();
			HashMap<Value,Interval> valueIn = (HashMap<Value,Interval>)entry.getValue();
			HashMap<Value,Interval> valueOut = new HashMap<Value,Interval>();
	        valueOut.putAll(valueIn);
			destLifted.set(key, valueOut);
		}
		//dest=destLifted;
		// System.out.println("dest ");
		 //print(dest.getMapping(),"recoveringTransaction");
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#merge(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void merge(MapLifted<Interval> source1, MapLifted<Interval> source2, MapLifted<Interval> dest) {
		 MapLifted<Interval> otherLifted = (MapLifted<Interval>) source2;
		 MapLifted<Interval> destLifted = (MapLifted<Interval>) dest;
		 destLifted.clear();
		
		 System.out.println("merge ");
		 System.out.println("source1 ");
		 print(source1.getMapping(),"recoveringTransaction");
		 System.out.println("source2 ");
		 print(source2.getMapping(),"recoveringTransaction");
		 
		 
		 Set<Entry<IConfigRep, HashMap<Value,Interval>>> entrySet = source1.getMapping().entrySet();
		 for (Entry<IConfigRep, HashMap<Value,Interval>> entry : entrySet) {
		 // key
			IConfigRep config = entry.getKey();
		 // val
			HashMap<Value, Interval> inMap1 = (HashMap<Value, Interval>) entry.getValue();
		
			HashMap<Value, Interval> inMap2 = (HashMap<Value, Interval>) otherLifted.getLattice(config);
			HashMap<Value, Interval> outMap = new HashMap<Value, Interval>();

			Set keys = inMap1.keySet();
			Iterator it = keys.iterator();
			while (it.hasNext()) {
				Value var1 = (Value)it.next();
				Interval inVal1 = (Interval)inMap1.get(var1);
		        //System.out.println(inVal1);
				Interval inVal2 = (Interval)inMap2.get(var1);

			    if (inVal2 == null) {outMap.put(var1, inVal1);}
				else if ((inVal1.isTop) || (inVal2.isTop)) {
					outMap.put(var1, new Interval(TOP));
				} else {
					Interval res=inVal1.join(inVal2);
					outMap.put(var1,res);
				}
			}
			 
			destLifted.set(config, new HashMap<Value, Interval>(outMap));
		 }
		 
		 System.out.println("dest ");
		 print(dest.getMapping(),"recoveringTransaction");
	}


	public void print(HashMap<IConfigRep, HashMap<Value,Interval>> hm,String var) {
		Set<IConfigRep> hm_keys=hm.keySet();
		Iterator<IConfigRep> it_keys=hm_keys.iterator();
		while (it_keys.hasNext()) {
			IConfigRep config=it_keys.next();
			HashMap<Value,Interval> hm_values=hm.get(config);
			Set<Value> hm_val = hm_values.keySet();
			Iterator<Value> it_values=hm_val.iterator();
			while (it_values.hasNext()) {
				Value val=it_values.next();
				if (var.equals(val.toString()))
					System.out.println("config "+config+" var "+val+" value "+hm_values.get(val));
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#entryInitialFlow()
	 */
	@Override
	protected MapLifted<Interval> entryInitialFlow() {

		HashSet<Integer> set=new HashSet<Integer>();
		set.add(new Integer(0));
		Iterator boxIt = g.getBody().getUseAndDefBoxes().iterator();
        while (boxIt.hasNext()){
            Value val = ((ValueBox)boxIt.next()).getValue();
            if (val instanceof IntConstant) {
				int value = ((IntConstant)val).value;
				set.add(new Integer(value));
				//System.out.println("found value  "+value);
				//if (java.util.Arrays.binarySearch(B_arr,0,B_size,value)<0) { 
				//	B_arr[B_size]=value;
				//	B_size++;
				//}
            }
        }
        B_size=set.size();
        B_arr=new Integer[B_size];
        B_arr=set.toArray(B_arr);
		java.util.Arrays.sort(B_arr,0,B_size);		
		
		/*System.out.println(g.getBody().getMethod().getName()+" size  "+B_size);
		for (int i=0; i<B_size; i++)
			System.out.print(B_arr[i].intValue()+"  ");
		System.out.println();*/
		
		return newInitialFlow();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.AbstractFlowAnalysis#newInitialFlow()
	 */
	@Override
	protected MapLifted<Interval> newInitialFlow() {
		
		HashMap<IConfigRep,HashMap<Value, Interval>> map = new HashMap<IConfigRep, HashMap<Value, Interval>>();
		for (IConfigRep config : configurations) {
			
			HashMap<Value, Interval> initMap = new HashMap<Value, Interval>();
		
			Chain locals = g.getBody().getLocals();
			Iterator it = locals.iterator();
			while (it.hasNext()) {
				Local next = (Local)it.next();
            //System.out.println("next local: "+next);
				if ((next.getType() instanceof IntegerType) || (next.getType() instanceof LongType)){
					initMap.put(next, new Interval(0,0));
				}
			}

			map.put(config, initMap);
		}
		
		return new MapLifted<Interval>(map);
	}

	
    private Interval getProperty(HashMap<Value, Interval> in, Value val) {
        //System.out.println("get Parity in: "+in);
        if  (val instanceof SubExpr) {
        	Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
                return new Interval(TOP);
	        }  
	        else {
	            return resVal1.sub(resVal2);
	        }
        }
        else if (val instanceof AddExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.add(resVal2);
	        }
        }
        else if (val instanceof MulExpr) {
	        Interval resVal1 = getProperty(in, ((BinopExpr)val).getOp1());
	        Interval resVal2 = getProperty(in, ((BinopExpr)val).getOp2());
	        if (resVal1.isTop || resVal2.isTop) {
	            return new Interval(TOP);
	        }
	        else {
	            return resVal1.mul(resVal2);
	        }
        }		
        else if (val instanceof IntConstant) {
	        int value = ((IntConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
	            return new Interval(value,value);
	        }
        }
        else if (val instanceof LongConstant) {
	        long value = ((LongConstant)val).value;
	        if (value>=(Interval.MAX) || value<=-(Interval.MAX)) {
                return new Interval(TOP);
	        }
	        else {
				int v=(int)value;
	            return new Interval(v,v);
	        }
        }
        else if (in.containsKey(val)) {
      	    return in.get(val);
        }
        else {
            return new Interval(TOP);
        }
     
    }
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see soot.toolkits.scalar.FlowAnalysis#flowThrough(java.lang.Object,
	 * java.lang.Object, java.lang.Object)
	 */
	@Override
	protected void flowThrough(MapLifted<Interval> source, Unit unit, MapLifted<Interval> dest) {
		//#ifdef CACHEPURGE
//@		br.Main.waste();
		//#endif

		// #ifdef METRICS
		flowThroughCounter++;
		long timeSpentOnFlowThrough = System.nanoTime();
		// #endif
		
		//System.out.println("flow ");
		//System.out.println("source ");
		//print(source.getMapping(),"recoveringTransaction");
		
		Stmt s = (Stmt) unit;
		
		int val_int=0;		
		if (visited.containsKey(s)) {
			Integer val = visited.get(s);
			val_int = val.intValue()+1;
			visited.put(s,new Integer(val_int));
		}
		else {
			visited.put(s,new Integer(1));
			val_int=1;
		}
		
		dest.clear();
		
		FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
		IFeatureRep featureRep = tag.getFeatureRep();

		Collection<IConfigRep> configs = source.getConfigurations();	
		for (IConfigRep config : configs) {
			HashMap<Value, Interval> in = source.getLattice(config);
			HashMap<Value, Interval> out = new HashMap<Value, Interval>();
		    
			if (config.belongsToConfiguration(featureRep)) {
				L1flowThroughCounter++;
			    out.putAll(in);
		        
			    if (s instanceof DefinitionStmt) {
			        Value left = ((DefinitionStmt)s).getLeftOp();
			        if (left instanceof Local) {
		                if ((left.getType() instanceof IntegerType) || (left.getType() instanceof LongType)){
		                    //useS = true;
		                	out.remove(left);
			  	            Value right = ((DefinitionStmt)s).getRightOp();
				            
							Interval newVal = getProperty(out, right);
							String st="temp$0";
							if (st.equals(left.toString())) System.out.println(left+" = "+newVal+" "+right);
							//WIDEN here
							if (val_int>=THRESHOLD) {
								//System.out.println("WIDEN");
								Interval oldVal = out.get(left);
								Interval widenVal = oldVal.widen2(newVal,B_arr,B_size);
								out.put(left,widenVal);
								//System.out.println("Visited: "+s+" var: "+left+" old: "+oldVal.toString()+" new: "+newVal.toString()+" widen: "+widenVal.toString());
							}
				            else out.put(left,newVal);				            
				            				            
		                } 
			        } 
			    } 

			} else {
				// copy in to out 
			    out.putAll(in);
			}
			dest.add(config,new HashMap<Value, Interval>(out));
		}
		
		//System.out.println("dest ");
		//print(dest.getMapping(),"recoveringTransaction");
		// #ifdef METRICS
		timeSpentOnFlowThrough = System.nanoTime() - timeSpentOnFlowThrough;
		this.flowThroughTimeAccumulator += timeSpentOnFlowThrough;
		// #endif
	}

	/**
	 * Creates a KILL set for the given unit and remove the elements that are in
	 * KILL from the destination FlowSet.
	 * 
	 * @param source
	 * @param unit
	 * @param dest
	 * @param configuration
	 */


	/**
	 * Creates a GEN set for a given Unit and add it to the FlowSet dest. In
	 * this case, our GEN set are all the definitions present in the unit.
	 * 
	 * @param dest
	 *            the dest
	 * @param unit
	 *            the unit
	 * @param configuration
	 */



	public void execute() {
		this.doAnalysis();
	}

}
