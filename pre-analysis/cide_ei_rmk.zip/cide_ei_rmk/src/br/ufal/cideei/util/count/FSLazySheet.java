package br.ufal.cideei.util.count;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class FSLazySheet extends SummarySheet {
	
	private int pre_interval;
	private int interval;
	private int pre67;
	private int int67;
	private int rd_a5;
	private int rd_a4;
	private int uv_a5;
	private int uv_a4;
	private int instrumentation;
	private int color_table;
	private int jimplification;
	private final Workbook workbook;
	private final Benchmark bench;
	
	public FSLazySheet(Benchmark bench) throws InvalidFormatException, IOException {
		if (!bench.lazy())
			throw new IllegalArgumentException(bench.toString() + " must be lazy");
		
		this.bench = bench;
		FileInputStream fileInputStream = new FileInputStream(new File(bench.file()));
		this.workbook = WorkbookFactory.create(fileInputStream);
		fileInputStream.close();
		
		Sheet someSheet = workbook.getSheetAt(0);
		Row firstRow = someSheet.getRow(0);
		int index = 1;
		Cell cell = firstRow.getCell(index);;
		while (cell != null) {
			String stringCellValue = cell.getStringCellValue();
			cell = firstRow.getCell(index);
			if (stringCellValue.equals("pre_interval_LAZY")) {
				this.pre_interval = index - 1;
				this.pre67 = index - 1;
			} else if (stringCellValue.equals("interval_LAZY")) {
				this.interval = index - 1;
				this.int67 = index - 1;
			} else if (stringCellValue.equals("rd (a5)")) {
				this.rd_a5 = index - 1;
			} else if ((stringCellValue.equals("uv (a5)"))) {
				this.uv_a5 = index - 1;
			} else if ((stringCellValue.equals("rd (a3)"))) {
				this.rd_a4 = index - 1;
			} else if ((stringCellValue.equals("uv (a3)"))) {
				this.uv_a4 = index - 1;
			} else if ((stringCellValue.equals("instrumentation"))) {
				this.instrumentation = index - 1;
			} else if ((stringCellValue.equals("color table"))) {
				this.color_table = index - 1;
			} else if ((stringCellValue.equals("jimplification"))) {
				this.jimplification = index - 1;
			}
			index++;
		}
		
	}
	
	public void summary() throws IOException {
		List<List<String>> listOfLists = new ArrayList<List<String>>();
		
		List<String> fs_pre = oneFromEverySheet(workbook, bench.sumFooterRow(), pre_interval);
		fs_pre.add(0, "PreInterval Lazy");
		listOfLists.add(fs_pre);

		List<String> fs_int = oneFromEverySheet(workbook, bench.sumFooterRow(), interval);
		fs_int.add(0, "Interval Lazy");
		listOfLists.add(fs_int);

		//System.out.println("File is: "+bench.file());
		List<String> fs_pre67;
		if (bench.file().contains("graph"))	{
			fs_pre67 = oneFromEverySheet(workbook, 66, pre67); // 62 for berkeleydb
			fs_pre67.add(0, "PreInt method");
			listOfLists.add(fs_pre67);
		}
		else if (bench.file().contains("berkeleydb")) {
			fs_pre67 = oneFromEverySheet(workbook, 62, pre67);
			fs_pre67.add(0, "PreInt method");
			listOfLists.add(fs_pre67);
		}
		//else fs_pre67 = oneFromEverySheet(workbook, bench.sumFooterRow(), pre67);
		

		List<String> fs_int67;
		if (bench.file().contains("graph"))	{
			fs_int67 = oneFromEverySheet(workbook, 66, int67);
			fs_int67.add(0, "Int method");
			listOfLists.add(fs_int67);
		}
		else if (bench.file().contains("berkeleydb")) {
			fs_int67 = oneFromEverySheet(workbook, 62, int67);
			fs_int67.add(0, "Int method");
			listOfLists.add(fs_int67);
		}
		//else fs_int67 = oneFromEverySheet(workbook, bench.sumFooterRow(), int67);
		

		List<String> instrumentation = oneFromEverySheet(workbook, bench.sumFooterRow(), this.instrumentation);
		instrumentation.add(0, "INSTRUMENTATION");
		listOfLists.add(instrumentation);

		List<String> color_table = oneFromEverySheet(workbook, bench.sumFooterRow(), this.color_table);
		color_table.add(0, "COLOR TABLE");
		listOfLists.add(color_table);

		List<String> jimplification = oneFromEverySheet(workbook, bench.sumFooterRow(), this.jimplification);
		jimplification.add(0, "JIMPLIFICATION");
		listOfLists.add(jimplification);
		
		writeTable(workbook, listOfLists);
		writeWorkbookToFile(workbook, bench);
	}
}
