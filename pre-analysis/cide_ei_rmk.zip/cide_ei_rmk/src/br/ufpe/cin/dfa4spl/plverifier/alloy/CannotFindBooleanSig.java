package br.ufpe.cin.dfa4spl.plverifier.alloy;

public class CannotFindBooleanSig extends Exception {

	private static final long serialVersionUID = 1L;

	public CannotFindBooleanSig(String message) {
		super(message);
	}

}