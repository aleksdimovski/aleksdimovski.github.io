package br.ufpe.cin.dfa4spl.plverifier.alloy;

public class CannotFindFunc extends Exception {

	private static final long serialVersionUID = 1L;

	public CannotFindFunc(String message) {
		super(message);
	}

}