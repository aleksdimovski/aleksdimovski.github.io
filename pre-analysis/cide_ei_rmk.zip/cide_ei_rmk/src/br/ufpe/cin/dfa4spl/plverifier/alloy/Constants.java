package br.ufpe.cin.dfa4spl.plverifier.alloy;

public class Constants {

	public static String RUN_COMMAND = "<b>run</b>";

	public static String CHECK_COMMAND = "<b>check</b>";

}