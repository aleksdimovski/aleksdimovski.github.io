/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2002-2006
 *      Sleepycat Software.  All rights reserved.
 *
 * $Id: EnvironmentParams.java,v 1.1 2006/05/06 09:01:30 ckaestne Exp $
 */

package com.sleepycat.je.config;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

/**
 * Javadoc for this public class is generated
 * via the doc templates in the doc_src directory.
 */
public class EnvironmentParams {

    /*
     * The map of supported environment parameters where the key is parameter 
     * name and the data is the configuration parameter object. Put first,
     * before any declarations of ConfigParams.
     */
    public final static Map SUPPORTED_PARAMS = new HashMap();

    /*
     * Environment
     */
    public static final LongConfigParam MAX_MEMORY = null;

    public static final IntConfigParam MAX_MEMORY_PERCENT =null;
     
    public static final BooleanConfigParam ENV_RECOVERY =null;
     
    public static final BooleanConfigParam ENV_RECOVERY_FORCE_CHECKPOINT =null;
     
    public static final BooleanConfigParam ENV_RUN_INCOMPRESSOR =null;
     
    /* @deprecated As of 2.0, eviction is performed in-line. */
    public static final BooleanConfigParam ENV_RUN_EVICTOR =null;
     
    public static final BooleanConfigParam ENV_RUN_CHECKPOINTER =null;

    public static final BooleanConfigParam ENV_RUN_CLEANER =null;

    public static final BooleanConfigParam ENV_CHECK_LEAKS =null;

    public static final BooleanConfigParam ENV_FORCED_YIELD =null;

    public static final BooleanConfigParam ENV_INIT_TXN =null;
    public static final BooleanConfigParam ENV_INIT_LOCKING =null;

    public static final BooleanConfigParam ENV_RDONLY =null;

    public static final BooleanConfigParam ENV_FAIR_LATCHES =null;
    
    /*
     * Database Logs
     */
    /* default: 2k * NUM_LOG_BUFFERS */
    public static final int MIN_LOG_BUFFER_SIZE = 2048;
    private static final int NUM_LOG_BUFFERS_DEFAULT = 3;
    public static final long LOG_MEM_SIZE_MIN =
	NUM_LOG_BUFFERS_DEFAULT * MIN_LOG_BUFFER_SIZE;
    public static final String LOG_MEM_SIZE_MIN_STRING =null;

    public static final LongConfigParam LOG_MEM_SIZE =null;
    public static final IntConfigParam NUM_LOG_BUFFERS =null;

    public static final IntConfigParam LOG_BUFFER_MAX_SIZE =null;

    public static final IntConfigParam LOG_FAULT_READ_SIZE =null;

    public static final IntConfigParam LOG_ITERATOR_READ_SIZE =null;

    public static final IntConfigParam LOG_ITERATOR_MAX_SIZE =null;
     
    public static final LongConfigParam LOG_FILE_MAX =null;
     
    public static final BooleanConfigParam LOG_CHECKSUM_READ =null;
     
    public static final BooleanConfigParam LOG_MEMORY_ONLY =null;

    public static final IntConfigParam LOG_FILE_CACHE_SIZE = null;

    public static final LongConfigParam LOG_FSYNC_TIMEOUT =null;
     



    public static final LongConfigParam LOG_CHUNKED_NIO =null;

    /* 
     * Tree
     */
    public static final IntConfigParam NODE_MAX =null;

    public static final IntConfigParam NODE_MAX_DUPTREE =null;

    public static final IntConfigParam BIN_MAX_DELTAS =null;
     
    public static final IntConfigParam BIN_DELTA_PERCENT =null;

    /*
     * IN Compressor
     */
    public static final LongConfigParam COMPRESSOR_WAKEUP_INTERVAL =null;     
    public static final IntConfigParam COMPRESSOR_RETRY =null;

    public static final LongConfigParam COMPRESSOR_LOCK_TIMEOUT =null;

    public static final BooleanConfigParam COMPRESSOR_PURGE_ROOT =null;
     
    /*
     * Evictor
     */ 
    public static final LongConfigParam EVICTOR_EVICT_BYTES =null;

    /* @deprecated As of 2.0, this is replaced by je.evictor.evictBytes */
    public static final IntConfigParam EVICTOR_USEMEM_FLOOR =null;

    /* @deprecated As of 1.7.2, this is replaced by je.evictor.nodesPerScan */
    public static final IntConfigParam EVICTOR_NODE_SCAN_PERCENTAGE =null;

    /* @deprecated As of 1.7.2, 1 node is chosen per scan. */
    public static final
	IntConfigParam EVICTOR_EVICTION_BATCH_PERCENTAGE =null;
    public static final IntConfigParam EVICTOR_NODES_PER_SCAN =null;

    /* @deprecated As of 2.0, eviction is performed in-line. */
    public static final
	IntConfigParam EVICTOR_CRITICAL_PERCENTAGE =null;

    public static final IntConfigParam EVICTOR_RETRY =null;
      
    public static final BooleanConfigParam EVICTOR_LRU_ONLY =null;
    /*
     * Checkpointer
     */
    public static final LongConfigParam CHECKPOINTER_BYTES_INTERVAL =null;
    public static final LongConfigParam CHECKPOINTER_WAKEUP_INTERVAL =null;

    public static final IntConfigParam CHECKPOINTER_RETRY =null;
    /*
     * Cleaner
     */
    public static final IntConfigParam CLEANER_MIN_UTILIZATION =null;

    public static final IntConfigParam CLEANER_MIN_FILE_UTILIZATION =null;

    public static final LongConfigParam CLEANER_BYTES_INTERVAL =null;

    public static final IntConfigParam CLEANER_DEADLOCK_RETRY =null;

    public static final LongConfigParam CLEANER_LOCK_TIMEOUT =null;
      
    public static final BooleanConfigParam CLEANER_REMOVE =null;

    /* @deprecated As of 1.7.1, no longer used. */
    public static final IntConfigParam CLEANER_MIN_FILES_TO_DELETE =null;

    /* @deprecated As of 2.0, no longer used. */
    public static final IntConfigParam CLEANER_RETRIES =null;

    /* @deprecated As of 2.0, no longer used. */
    public static final IntConfigParam CLEANER_RESTART_RETRIES =null;

    public static final IntConfigParam CLEANER_MIN_AGE =null;
      
    public static final BooleanConfigParam CLEANER_CLUSTER =null;      
    public static final BooleanConfigParam CLEANER_CLUSTER_ALL =null;
      
    public static final IntConfigParam CLEANER_MAX_BATCH_FILES =null;

    public static final IntConfigParam CLEANER_READ_SIZE = null;
      
    public static final BooleanConfigParam CLEANER_TRACK_DETAIL =null;

    public static final IntConfigParam CLEANER_DETAIL_MAX_MEMORY_PERCENTAGE =null;
      
    public static final BooleanConfigParam CLEANER_RMW_FIX =null;
      
    public static final ConfigParam CLEANER_FORCE_CLEAN_FILES =null;

    public static final IntConfigParam CLEANER_THREADS =null;

    public static final IntConfigParam CLEANER_LOOK_AHEAD_CACHE_SIZE = null;

    /*
     * Transactions
     */
	public static final IntConfigParam N_LOCK_TABLES = null; 

    public static final LongConfigParam LOCK_TIMEOUT =null;

    public static final LongConfigParam TXN_TIMEOUT =null;

    public static final BooleanConfigParam TXN_SERIALIZABLE_ISOLATION =null;
    public static final BooleanConfigParam TXN_DEADLOCK_STACK_TRACE =null;
    public static final BooleanConfigParam TXN_DUMPLOCKS =null;

    /*
     * Debug tracing system
     */
    public static final BooleanConfigParam JE_LOGGING_FILE =null;
    public static final BooleanConfigParam JE_LOGGING_CONSOLE =null;

    public static final BooleanConfigParam JE_LOGGING_DBLOG =null;

    public static final IntConfigParam JE_LOGGING_FILE_LIMIT =null;
    public static final IntConfigParam JE_LOGGING_FILE_COUNT =null;

    public static final ConfigParam JE_LOGGING_LEVEL =null;
    public static final ConfigParam JE_LOGGING_LEVEL_LOCKMGR =null;
    public static final ConfigParam JE_LOGGING_LEVEL_RECOVERY =null;
    public static final ConfigParam JE_LOGGING_LEVEL_EVICTOR =null;
    public static final ConfigParam JE_LOGGING_LEVEL_CLEANER =null;
    
    /*
     * Create a sample je.properties file.
     */
    public static void main(String argv[]) throws IOException {
        if (argv.length != 1) {
            throw new IllegalArgumentException("Usage: EnvironmentParams " +
                                               "<samplePropertyFile>");
        }

//        try {
            FileWriter exampleFile = new FileWriter(new File(argv[0]));
            TreeSet paramNames = new TreeSet(SUPPORTED_PARAMS.keySet());
            Iterator iter = paramNames.iterator();
            exampleFile.write
		("####################################################\n" +
		 "# Example Berkeley DB, Java Edition property file\n" +
		 "# Each parameter is set to its default value\n" +
		 "####################################################\n\n");
            
            while (iter.hasNext()) {
                String paramName =(String) iter.next();
                ConfigParam param =
                    (ConfigParam) SUPPORTED_PARAMS.get(paramName);
                exampleFile.write(param.getDescription() + "\n");
                String extraDesc = param.getExtraDescription();
                if (extraDesc != null) {
                    exampleFile.write(extraDesc + "\n");
                }
                exampleFile.write("#" + param.getName() + "=" +
                                  param.getDefault() +
                                  "\n# (mutable at run time: " +
                                  param.isMutable() +
                                  ")\n\n");
            }
            exampleFile.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//            System.exit(-1);
//        }
    }
    
    /*
     * Add a configuration parameter to the set supported by an 
     * environment.
     */
    static void addSupportedParam(ConfigParam param) {
//        SUPPORTED_PARAMS.put(param.getName(), param);
    }
}
