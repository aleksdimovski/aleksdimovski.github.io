package org.prevayler.demos.demo2.business;

public interface AccountListener {

	void accountChanged();
	
}
