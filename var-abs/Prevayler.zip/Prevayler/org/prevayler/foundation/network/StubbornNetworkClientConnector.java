/*
 * StubbornNetworkClientConnector.java
 *
 *
 */
package org.prevayler.foundation.network;

/**
 * Useful class comments should go here
 *
 */
public interface StubbornNetworkClientConnector {

    void disconnect();
}