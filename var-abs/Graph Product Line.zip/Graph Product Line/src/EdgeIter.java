public class EdgeIter {
	// methods whose bodies will be overridden by subsequent layers
	public boolean hasNext() {
		return false;
	}

	public EdgeIfc next() {
		return null;
	}
}