/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.*;

//#ifdef METRICS

//#ifdef OVERSEER
//@import ch.usi.overseer.OverHpc;
//@
//#endif
import profiling.ProfilingTag;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//#endif

import soot.Body;
import soot.BodyTransformer;
import soot.Unit;
import soot.jimple.NopStmt;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.handlers.DoAnalysisOnClassPath;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.MapLiftedFlowSet;
import br.ufal.cideei.soot.analyses.reachingdefs.LiftedJoinReachingDefinitions;
import br.ufal.cideei.soot.analyses.reachingdefs.SimpleReachingDefinitions;

import br.ufal.cideei.soot.instrument.ConfigTag;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitFeatureRep;
import br.ufal.cideei.soot.instrument.bitrep.BitConfigRep;

//TODO: can this class structure could be replaced by an abstract factory? 
public class WholeLineLiftedJoinReachingDefinitions extends BodyTransformer {

	public WholeLineLiftedJoinReachingDefinitions() {
	}

	// #ifdef METRICS
	private static final String RD_LIFTED_FLOWTHROUGH_COUNTER = "RD A3 flowthrough";
	private static final String RD_LIFTED_FLOWSET_MEM = "RD A3 mem";
	private static final String RD_LIFTED_FLOWTHROUGH_TIME = "RD A3 flowthrough time";
	private static final String RD_LIFTED_L1_FLOWTHROUGH_COUNTER = "RD A3 L1 flowthrough counter";
	
	//#ifdef OVERSEER
//@	private static final String RD_LIFTED_CACHE_MISSES = "RD A3 cache misses";
//@	static OverHpc ohpc=OverHpc.getInstance();
//@	
	//#endif
	
	private AbstractMetricsSink sink;

	public WholeLineLiftedJoinReachingDefinitions setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void internalTransform(Body body, String phase, Map options) {
		UnitGraph bodyGraph = new BriefUnitGraph(body);
		ConfigTag configTag = (ConfigTag) body.getTag(ConfigTag.CONFIG_TAG_NAME);

		boolean wentHybrid = false;
		LiftedJoinReachingDefinitions liftedReachingDefinitions = null;

		// #ifdef METRICS
		
		//#ifdef OVERSEER
//@		ohpc.initEvents("PERF_COUNT_HW_CACHE_MISSES");
//@		int threadId = ohpc.getThreadId();
//@		ohpc.bindEventsToThread(threadId);
//@		ohpc.stop();
//@		ohpc.start();
//@		
		//#endif
		
		long startAnalysis = System.nanoTime();

		// #endif

		//generate (extract) configurations we want to analyse (project on) 
		
		//int bitConfigId=0;
		Collection<IConfigRep> configs = configTag.getConfigReps();
		Collection<IConfigRep> project_configs = new HashSet<IConfigRep>(); //write this by looking in BitConfigRep.java
		int project_size=configs.size();
		int size_configs=configs.size();
		
		
		if (configs.size()<=project_size) {
			project_configs=configs;
		}
		else {
			
			Random t = new Random();
			int[] project=new int[project_size];
			int[] pick=new int[project_size];
			
			for (int k=0;k<project_size;k++) {
				project[k]=t.nextInt(size_configs-project_size+k+1);
				size_configs=size_configs-project[k]-1;
			}
			
			pick[0]=project[0];
			for (int k=1;k<project_size;k++) {
				pick[k]=pick[k-1]+project[k]+1;
			}
			int i=0, j=0;
		    for (IConfigRep config : configs) {
			  if (i==pick[j]) {
				project_configs.add(config);
				j++;
				BitConfigRep bitRep = (BitConfigRep) config;
				//System.out.println("Chosen Project Config is: "+bitRep.toString());
				if (j==project_size) break;
				//else j++;
				//random_config = t.nextInt(size_configs-random_config);
				// print info about the chosen random config
				//BitConfigRep bitRep = (BitConfigRep) config;
				//bitConfigId = bitRep.getId();
				
			  }
			 i++;
			}
		}
		//System.out.println("Out of for body "+body.getMethod().getDeclaringClass().getName()+"Orig. conf size "+configs.size()+" new size "+project_configs.size());
		// #ifdef HYBRID
//@		if (configTag.size() == 1) {
//@			wentHybrid = true;
//@			simpleReachingDefinitions = new SimpleReachingDefinitions(bodyGraph);
//@		} else {
			// #endif
			liftedReachingDefinitions = new LiftedJoinReachingDefinitions(bodyGraph, project_configs);
			liftedReachingDefinitions.execute();
			// #ifdef HYBRID
//@		}
//@
		// #endif

			// #ifdef PRINT
//@
//@			try {
//@				FileWriter file = new FileWriter("C:\\Users\\adim\\Results\\test1.txt",true);
//@				PrintWriter pr_file = new PrintWriter(file);
//@				
//@				//pr_file.println();
//@				
//@				//pr_file.println(body.getTag(ConfigTag.CONFIG_TAG_NAME));
//@				//pr_file.println();
//@				//boolean join=true;
//@				//int totalNodes=0, istiNodes=0;
//@				if (body.getMethod().getName().equals("main")) {
//@					pr_file.println(body.getMethod().getName());
//@				//body.
//@			 	  for (Unit unit : body.getUnits()) {
//@			 		//totalNodes++;
//@			 		//pr_file.println(unit + " [[" + unit.getTag(FeatureTag.FEAT_TAG_NAME) + "]]");
//@			 		//boolean isti=true;
//@			 		FlowSet map = liftedReachingDefinitions.getFlowAfter(unit);
//@					//Iterator<? extends Unit> flowIterator = map.toList().iterator();
//@					//while (flowIterator.hasNext()) {
//@					//	Unit nextUnitInFlow = flowIterator.next();
//@					//	pr_file.print(nextUnitInFlow+" ");
//@					//}
//@			 		pr_file.println(map);
//@					//if (map.size()==1) continue;
//@			 		//Set<Entry<IConfigRep, FlowSet>> entrySet = map.getMapping().entrySet();
//@					//int i=0;
//@					//FlowSet value = new ArraySparseSet();
//@					/*for (Entry<IConfigRep, FlowSet> entry : entrySet) {
//@						if (i==0) {
//@							value = entry.getValue();}
//@						else {
//@							FlowSet value2=entry.getValue(); 
//@							if (!value2.equals(value)) isti=false;
//@						}
//@						i++;
//@					}
//@			 		if (isti) 
//@			 			{pr_file.println("Ista vrednost "+value); pr_file.println(map); istiNodes++;}
//@			 		else { pr_file.println("Razlicna vrednost"); join=false;}*/
//@			 		
//@				  }
//@				
//@			 	//if (join) br.ufal.cideei.handlers.DoAnalysisOnClassPath.numberIsti++;
//@				//pr_file.println("Vkupno nodes: "+totalNodes+" isti nodes: "+istiNodes);
//@				}
//@				pr_file.close();
//@			} catch (IOException e) {
//@				System.out.println("Pecatenjeto e stopirano!");
//@			}
//@	/*//@		 if (body.getMethod().getSignature().contains("main(")) {
//@			 FlowSetUtils.pbm(body, lazyReachingDefinitions, System.getProperty("user.home") + File.separator +
//@			 "lazy-pix.pbm");
//@										
//@			 System.out.println(body.getTag(ConfigTag.CONFIG_TAG_NAME));
//@			 for (Unit unit : body.getUnits()) {
//@			 System.out.println(unit + " [[" + unit.getTag(FeatureTag.FEAT_TAG_NAME) + "]]");
//@			 System.out.println(lazyReachingDefinitions.getFlowAfter(unit));
//@			 }
//@			 }*/
			// #endif
			
			
			
			
		// #ifdef METRICS
		long endAnalysis = System.nanoTime();
		
		//#ifdef OVERSEER
//@		long cacheMissesFromThread = ohpc.getEventFromThread(threadId, 0);
//@		ohpc.stop();
//@		
		//#endif
		
		if (!wentHybrid) {
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_TIME, liftedReachingDefinitions.getFlowThroughTime());
			//this.sink.flow(body, RD_LIFTED_FLOWSET_MEM, FlowSetUtils.liftedMemoryUnits(body, liftedReachingDefinitions, false, 1));
			//this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_COUNTER, LiftedReachingDefinitions.getFlowThroughCounter());
			//this.sink.flow(body, RD_LIFTED_L1_FLOWTHROUGH_COUNTER, liftedReachingDefinitions.getL1flowThroughCounter());
			//#ifdef OVERSEER
//@			this.sink.flow(body, RD_LIFTED_CACHE_MISSES, cacheMissesFromThread);
//@			
			//#endif
			
			LiftedJoinReachingDefinitions.reset();
		}

		this.sink.flow(body, "RD_D-Join", endAnalysis - startAnalysis);
		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		//profilingTag.
		profilingTag.setRdAnalysisTime2(endAnalysis - startAnalysis);
		// #endif
	}
}
