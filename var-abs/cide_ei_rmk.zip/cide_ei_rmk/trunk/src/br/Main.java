/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br;

import java.util.Random;


public class Main {

	// #ifdef CACHEPURGE
//@	private static long[] wasteOfSpace = new long[163840]; // 163840*64 bits =
//@															// 10485760 bits =
//@															// 10MB
//@	private static Random rdm = new Random();
//@	private static long acc = 0;
//@
//@	static {
//@		for (int index = 0; index < wasteOfSpace.length; index++) {
//@			wasteOfSpace[index] = rdm.nextLong();
//@		}
//@	}
//@
//@	public static long randomLong() {
//@		return wasteOfSpace[rdm.nextInt(wasteOfSpace.length)];
//@	}
//@
	// #endif

	// #ifdef CACHEPURGE
//@	public static void waste() {
//@		// reads cells from the useless array and do some useless calculations
//@		long acc = 0;
//@		boolean bool = rdm.nextBoolean();
//@		for (int i = 0; i < wasteOfSpace.length; i++) {
//@			if (bool) {
//@				bool = !bool;
//@				acc += wasteOfSpace[i];
//@			} else {
//@				bool = !bool;
//@				acc -= wasteOfSpace[i];
//@			}
//@		}
//@		Main.acc = acc;
//@	}
	// #endif

}
