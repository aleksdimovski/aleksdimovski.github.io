/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.util.Map;
import java.util.Set;


//#ifdef METRICS

//#ifdef OVERSEER
//@import ch.usi.overseer.OverHpc;
//@
//#endif
import br.ufal.cideei.util.count.AbstractMetricsSink;

//#endif

import soot.Body;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.reachingdefs.LiftedReachingDefinitions;

//#ifdef HYBRID
//@import br.ufal.cideei.soot.analyses.reachingdefs.SimpleReachingDefinitions;
//#endif

import br.ufal.cideei.soot.instrument.EagerConfigTag;
import br.ufal.cideei.soot.instrument.IConfigRep;

//TODO: can this class structure could be replaced by an abstract factory? 
public class WholeLineLiftedReachingDefinitions extends FilteredBodyTransformer {

	public WholeLineLiftedReachingDefinitions() {
	}

	// #ifdef METRICS
	private static final String RD_LIFTED_FLOWTHROUGH_COUNTER = "flowthrough count (rd a3)";
	private static final String RD_LIFTED_FLOWSET_MEM = "mem (rd a3)";
	private static final String RD_LIFTED_FLOWTHROUGH_TIME = "flowthrough time (rd a3)";
	private static final String RD_LIFTED_L1_FLOWTHROUGH_COUNTER = "normal lattice flowthrough counter (rd a3)";
	private static final String RD_LIFTED_TIME = "analysis time (rd a3)";
	
	//#ifdef OVERSEER
//@	private static final String RD_LIFTED_CACHE_MISSES = "cache misses (rd a3)";
	//#endif
	
	private AbstractMetricsSink sink;

	public WholeLineLiftedReachingDefinitions setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void filteredInternalTransform(Body body, String phase, Map options) {
		EagerConfigTag configTag = (EagerConfigTag) body.getTag(EagerConfigTag.TAG_NAME);
		if (configTag == null) {
			throw new IllegalStateException("No EagerConfigTag found for body of method " + body.getMethod());
		}
		
		Set<IConfigRep> configReps = configTag.getConfigReps();
		if (configReps.size() < 1) {
			return;
		}
		
		UnitGraph bodyGraph = new BriefUnitGraph(body);

		boolean wentHybrid = false;
		LiftedReachingDefinitions liftedReachingDefinitions = null;
		
		//#ifdef HYBRID
//@		SimpleReachingDefinitions simpleReachingDefinitions = null;
		//#endif

		// #ifdef METRICS
		
		//#ifdef OVERSEER
//@		OverHpc ohpc = OverHpc.getInstance();
//@		ohpc.initEvents("PERF_COUNT_HW_CACHE_MISSES");
//@		int threadId = ohpc.getThreadId();
//@		ohpc.bindEventsToThread(threadId);
//@		ohpc.stop();
//@		ohpc.start();
		//#endif
		
		long startAnalysis = System.nanoTime();

		// #endif

		// #ifdef HYBRID
//@		if (configTag.size() == 1) {
//@			wentHybrid = true;
//@			simpleReachingDefinitions = new SimpleReachingDefinitions(bodyGraph);
//@		} else {
			// #endif
			liftedReachingDefinitions = new LiftedReachingDefinitions(bodyGraph, configReps);
			// #ifdef HYBRID
//@		}
//@
		// #endif

		// #ifdef METRICS
		long analysisTime = System.nanoTime() - startAnalysis;
		
		//#ifdef OVERSEER
//@		long cacheMissesFromThread = ohpc.getEventFromThread(threadId, 0);
//@		ohpc.stop();
//@		OverHpc.shutdown();
		//#endif
		
		this.sink.flow(body, RD_LIFTED_TIME, analysisTime);
		
		if (!wentHybrid) {
			this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_TIME, liftedReachingDefinitions.getFlowThroughTime());
			this.sink.flow(body, RD_LIFTED_FLOWSET_MEM, FlowSetUtils.liftedMemoryUnits(body, liftedReachingDefinitions, false, 1));
			this.sink.flow(body, RD_LIFTED_FLOWTHROUGH_COUNTER, LiftedReachingDefinitions.getFlowThroughCounter());
			this.sink.flow(body, RD_LIFTED_L1_FLOWTHROUGH_COUNTER, liftedReachingDefinitions.getL1flowThroughCounter());
			//#ifdef OVERSEER
//@			this.sink.flow(body, RD_LIFTED_CACHE_MISSES, cacheMissesFromThread);
//@			
			//#endif
			LiftedReachingDefinitions.reset();
		}
		// #endif
	}
}
