/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.toolkits.scalar.FlowSet;
import br.ufal.cideei.soot.instrument.IConfigRep;
import br.ufal.cideei.util.Factory;

public class ReversedMapLiftedFlowSetGeneric implements FlowSet {
	protected Map<FlowSet, IConfigRep> map;
	protected Factory<FlowSet> factory;

	public Map<FlowSet, IConfigRep> getMapping() {
		return map;
	}
	
	public ReversedMapLiftedFlowSetGeneric(IConfigRep seed, Factory<FlowSet> factory) {
		this.factory = factory;
		this.map = new HashMap<FlowSet, IConfigRep>();
		map.put(factory.make(), seed);
	}

	public ReversedMapLiftedFlowSetGeneric(Factory<FlowSet> factory) {
		this.factory = factory;
		map = new HashMap<FlowSet, IConfigRep>();
	}
	
	private ReversedMapLiftedFlowSetGeneric(Map<FlowSet, IConfigRep> map, Factory<FlowSet> factory) {
		this.map = map;
		this.factory = factory;
	}

	@Override
	public ReversedMapLiftedFlowSetGeneric clone() {
		Set<Entry<FlowSet, IConfigRep>> entrySet = map.entrySet();
		Map<FlowSet, IConfigRep> newMap = new HashMap<FlowSet, IConfigRep>();
		for (Entry<FlowSet, IConfigRep> entry : entrySet) {
			newMap.put(entry.getKey().clone(), entry.getValue());
		}
		return new ReversedMapLiftedFlowSetGeneric(newMap, this.factory);
	}

	@Override
	public void copy(FlowSet dest) {
		ReversedMapLiftedFlowSetGeneric destLifted = (ReversedMapLiftedFlowSetGeneric) dest;
		destLifted.clear();
		Set<Entry<FlowSet, IConfigRep>> entrySet = map.entrySet();
		for (Entry<FlowSet, IConfigRep> entry : entrySet) {
			destLifted.map.put(entry.getKey().clone(), entry.getValue());
		}
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (this == o)
			return true;
		if (!(o instanceof ReversedMapLiftedFlowSetGeneric))
			return false;
		ReversedMapLiftedFlowSetGeneric that = (ReversedMapLiftedFlowSetGeneric) o;
		return this.flattenMap().equals(that.flattenMap());
	}

	@Override
	public int hashCode() {
		return 7 + this.map.hashCode();
	}

	@Override
	public void clear() {
		map.clear();
	}

	@Override
	public void union(FlowSet aOther, FlowSet aDest) {
		ReversedMapLiftedFlowSetGeneric other = (ReversedMapLiftedFlowSetGeneric) aOther;
		Set<Entry<FlowSet, IConfigRep>> otherEntrySet = other.map.entrySet();

		ReversedMapLiftedFlowSetGeneric dest = (ReversedMapLiftedFlowSetGeneric) aDest;
		Map<FlowSet, IConfigRep> destMap = new HashMap<FlowSet, IConfigRep>(this.map);
		
		for (Entry<FlowSet, IConfigRep> otherEntry : otherEntrySet) {
			FlowSet key = otherEntry.getKey();
			IConfigRep config = destMap.get(key);
			if (config == null) {
				destMap.put(key, otherEntry.getValue());
			} else {
				destMap.put(key, config.union(otherEntry.getValue()));
			}
		}

		dest.map = destMap;
	}
	
	public FlowSet add(FlowSet flow, IConfigRep config) {
		return (FlowSet) map.put(flow, config);
	}

	@Override
	public void intersection(FlowSet aOther, FlowSet aDest) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void add(Object arg0) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean contains(Object arg0) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isEmpty() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void remove(Object arg0) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int size() {
		return this.map.size();
	}

	@Override
	public String toString() {
		return map.toString();
	}
	
	@Override
	public List toList() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void add(Object arg0, FlowSet arg1) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public void difference(FlowSet arg0) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public void difference(FlowSet arg0, FlowSet arg1) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public Object emptySet() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void intersection(FlowSet arg0) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public Iterator iterator() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void remove(Object arg0, FlowSet arg1) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public void union(FlowSet other) {
		this.union(other, this);
	}
	
	private Map<FlowSet, IConfigRep> flattenMap() {
		HashMap<FlowSet, IConfigRep> newMap = new HashMap<FlowSet, IConfigRep>();
		Set<Entry<FlowSet, IConfigRep>> entrySet = this.map.entrySet();
		for (Entry<FlowSet, IConfigRep> entry : entrySet) {
			FlowSet key = entry.getKey();
			Iterator iterator = key.iterator();
			while (iterator.hasNext()) {
				Object object = (Object) iterator.next();
				FlowSet newKey = factory.make();
				newKey.add(object);
				if (newMap.containsKey(newKey)) {
					newMap.put(newKey, newMap.get(newKey).union(entry.getValue()));
				} else {
					newMap.put(newKey,entry.getValue());
				}
			}
		}
		return newMap;
	}
}
