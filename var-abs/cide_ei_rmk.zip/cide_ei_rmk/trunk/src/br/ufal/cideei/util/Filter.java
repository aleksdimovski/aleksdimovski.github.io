package br.ufal.cideei.util;

public interface Filter<T> {
	boolean accept(T element);
}
