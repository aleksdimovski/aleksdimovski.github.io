package br.ufal.cideei.util;

public interface ColumnFilter <R, C ,V> {
	public C getColumn();
	public boolean apply(R r, V v);
}