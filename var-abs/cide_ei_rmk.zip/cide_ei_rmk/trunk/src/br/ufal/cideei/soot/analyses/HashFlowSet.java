package br.ufal.cideei.soot.analyses;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import soot.toolkits.scalar.FlowSet;

import com.google.common.collect.Sets;

public class HashFlowSet<T> implements FlowSet {
	private HashSet<T> set;
	
	public HashFlowSet() {
		this.set = new HashSet<T>();
	}
	
	private HashFlowSet(HashSet<T> set) {
		this.set = new HashSet<T>(set);
	}

	public FlowSet clone() {
		return new HashFlowSet<T>(set);
	}

	@Override
	public void add(Object element) {
		this.set.add((T) element);
	}

	@Override
	public void add(Object element, FlowSet dest) {
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		if (this.equals(hashDest)) {
			hashDest.remove(element);
		} else {
			hashDest.set.clear();
			hashDest.set.addAll(this.set);
			hashDest.set.add((T) element);
		}
	}

	@Override
	public void clear() {
		this.set.clear();
	}

	@Override
	public boolean contains(Object element) {
		return this.set.contains(element);
	}

	@Override
	public void copy(FlowSet dest) {
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		if (!this.equals(hashDest)) {
			hashDest.set.clear();
			hashDest.set.addAll(this.set);
		}
	}

	@Override
	public void difference(FlowSet other) {
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		if (this.equals(hashOther)) {
			this.set = new HashSet<T>();
		} else {
			HashSet<T> tmp = new HashSet<T>();
			Sets.difference(this.set, hashOther.set).copyInto(tmp);
			this.set = tmp;
		}
	}

	@Override
	public void difference(FlowSet other, FlowSet dest) {
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		if (this.equals(hashOther)) {
			hashDest.set = new HashSet<T>();
		} else {
			HashSet<T> tmp = new HashSet<T>();
			Sets.difference(this.set, hashOther.set).copyInto(tmp);
			hashDest.set = tmp;
		}		
	}

	@Override
	public Object emptySet() {
		return new HashFlowSet<T>();
	}

	@Override
	public void intersection(FlowSet other) {
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		if (!this.equals(hashOther)) {
			HashSet<T> tmp = new HashSet<T>();
			Sets.intersection(this.set, hashOther.set).copyInto(tmp);
			this.set = tmp;
		}
	}

	@Override
	public void intersection(FlowSet other, FlowSet dest) {
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		if (this.equals(hashOther)) {
			hashDest.set = new HashSet<T>(this.set);
		} else {
			HashSet<T> tmp = new HashSet<T>();
			Sets.intersection(this.set, hashOther.set).copyInto(tmp);
			hashDest.set = tmp;
		}
	}

	@Override
	public boolean isEmpty() {
		return this.set.isEmpty();
	}

	@Override
	public Iterator iterator() {
		return this.set.iterator();
	}

	@Override
	public void remove(Object element) {
		this.set.remove(element);
	}

	@Override
	public void remove(Object element, FlowSet dest) {
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		if (this.equals(dest)) {
			hashDest.set.remove(element);
		} else {
			hashDest.set.clear();
			hashDest.set.addAll(this.set);
			hashDest.set.remove(element);
		}
	}

	@Override
	public int size() {
		return this.set.size();
	}

	@Override
	public List toList() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void union(FlowSet other) {
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		if (!this.equals(hashOther)) {
			HashSet<T> tmp = new HashSet<T>();
			Sets.union(this.set, hashOther.set).copyInto(tmp);
			this.set = tmp;
		}
	}

	@Override
	public void union(FlowSet other, FlowSet dest) {
		HashFlowSet<T> hashOther = (HashFlowSet<T>) other;
		HashFlowSet<T> hashDest = (HashFlowSet<T>) dest;
		if (this.equals(hashOther)) {
			hashOther.set.clear();
			hashOther.set.addAll(this.set);
		} else {
			HashSet<T> tmp = new HashSet<T>();
			Sets.union(this.set, hashOther.set).copyInto(tmp);
			hashDest.set = tmp;
		}
	}

	@Override
	public int hashCode() {
		return 31 + ((set == null) ? 0 : set.hashCode());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashFlowSet other = (HashFlowSet) obj;
		if (set == null) {
			if (other.set != null)
				return false;
		} else if (!set.equals(other.set))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return this.set.toString();
	}
	
}
