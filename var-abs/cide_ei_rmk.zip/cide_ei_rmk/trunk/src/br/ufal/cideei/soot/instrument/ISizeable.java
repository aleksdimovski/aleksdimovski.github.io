package br.ufal.cideei.soot.instrument;

public interface ISizeable {
	public long getSize();
}
