package br.ufal.cideei.soot.instrument;

import java.util.Collections;
import java.util.Map;

import org.apache.commons.collections.bidimap.UnmodifiableBidiMap;

import soot.Body;
import soot.PatchingChain;
import soot.Unit;
import br.ufal.cideei.features.FeatureSetChecker;
import br.ufal.cideei.features.IFeatureExtracter;
import br.ufal.cideei.soot.instrument.bitrep.BitConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitVectorConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitVectorFeatureRep;
import br.ufal.cideei.util.Constants;

public class FeatureModelInstrumentor extends BaseFeatureModelInstrumentor {
	
	public FeatureModelInstrumentor(IFeatureExtracter extracter, String classPath, FeatureSetChecker checker) {
		super(extracter, classPath, checker);
	}
	
	@Override
	protected void endBodyInstrumentation(Body body, String phase, Map options, UnmodifiableBidiMap featuresId) {
		Integer highestId;
		if (!featuresId.isEmpty()) {
			highestId = (Integer) Collections.max(featuresId.values()) << 1;
		} else {
			highestId = 1;
		}
		
		PatchingChain<Unit> units = body.getUnits();
		for (Unit unit : units) {
			FeatureTag tag = (FeatureTag) unit.getTag(FeatureTag.FEAT_TAG_NAME);
			BitVectorFeatureRep bitVectorFeatureRep = (BitVectorFeatureRep) tag.getFeatureRep();
			bitVectorFeatureRep.computeBitVector();
		}
		
		BitVectorConfigRep localConfigurations;
		EagerConfigTag eagerConfigTag;
		Boolean useFeatureModel = (Boolean) options.get(Constants.USE_FEATURE_MODEL);
		if (useFeatureModel) {
			localConfigurations = BitVectorConfigRep.localConfigurations(highestId, featuresId, this.fmChecker);
			eagerConfigTag = new EagerConfigTag(BitConfigRep.localConfigurations(highestId, featuresId, this.fmChecker).getConfigs());
		} else {
			eagerConfigTag = new EagerConfigTag(BitConfigRep.localConfigurations(highestId, featuresId).getConfigs());
			localConfigurations = BitVectorConfigRep.localConfigurations(highestId, featuresId);
		}
		LazyConfigTag lazyConfigTag = new LazyConfigTag(localConfigurations);
		body.addTag(lazyConfigTag);
		body.addTag(eagerConfigTag);
	}

}
