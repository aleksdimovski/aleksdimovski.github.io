/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.util.count;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import soot.Body;

import com.google.common.base.Function;

public class MetricsSink extends AbstractMetricsSink {

	private MetricsTable table;
	private boolean terminated = false;
	private String statsFilePattern;

	public MetricsSink(MetricsTable table, String statsFile) {
		this.table = table;
		this.statsFilePattern = statsFile;
	}

	@Override
	protected void handle(Body body, String property, String value) {
		checkTerminated();
		table.setProperty(body.getMethod().getSignature(), property, value);
	}
	
	protected void handle(Body body, String property, double value) {
		checkTerminated();
		table.setProperty(body.getMethod().getSignature(), property, value);
	}
	
	public boolean terminated() {
		return terminated;
	}

	/*
	 * XXX:
	 * SOOT generates unique names for anonymous classes. These names, however,
	 * is not consistent between different runs of SOOt. This method tries to
	 * replace the generated names of the anonymous classes with unique but
	 * consistent names.
	 * 
	 * To do so, it relies on other invariant properties of the methods, that
	 * is, properties that should not change between different runs, like number
	 * of units, assignments, number of features etc. Note that properties like
	 * analysis time should not be used because they are not invariants.
	 */
	// List of properties to be used to generate a unique name for methods
	private static List<String> invariantProperties = Arrays.asList("assignments", "configurations",
			"cyclomatic complexity", "gotos", "locals", "units");
	
	/*
	 *  Tries to generates a unique number based on a set of other numbers. E.g.:
	 */
	private static Function<SortedMap<String, Double>, String> generator = new Function<SortedMap<String, Double>, String>() {
		private MessageDigest digest;
		{
			try {
				digest = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
		}
		
		@Override
		public String apply(SortedMap<String, Double> args) {
			StringBuilder builder = new StringBuilder();
			Set<Entry<String, Double>> entrySet = args.entrySet();
			for (Entry<String, Double> entry : entrySet) {
				Double value = entry.getValue();
				int intValue = value.intValue();
				builder.append(intValue);
			}
			byte[] digested = digest.digest(builder.toString().getBytes());
			return new BigInteger(1, digested).toString(16);
		}
	};
	
	private void handleAnonymousClassSootIssue() {
		// Pattern used to identify the anonymous class naming used by Soot
		Pattern anonymousClassMethodPattern = Pattern.compile("\\$\\d+Anonymous\\d+:");
		
		// The data set in which we are working on
		MultiValueMap map = table.getMap();
		
		MultiValueMap newMap = new MultiValueMap();
		newMap.putAll(map);
		
		/*
		 * Stores mappings from the list of properties of an anonymous class method to a unique number,
		 * created by a function (hash) of its properties. 
		 */
		Set entrySet = map.entrySet();
		for (Object entryAsObject : entrySet) {
			Entry<String, Collection<KeyValue>> entry = (Entry<String, Collection<KeyValue>>) entryAsObject;
			String methodName = entry.getKey();
			Matcher matcher = anonymousClassMethodPattern.matcher(methodName);
			if (matcher.find()) {
				Collection<KeyValue> pairs = entry.getValue();
				SortedMap<String, Double> invariantPropertyValues = getInvariantPropertyValues(pairs, invariantProperties);
				String salt = generator.apply(invariantPropertyValues);
				newMap.remove(methodName);
				String uniqueName = matcher.replaceFirst("\\$Anonymous" + salt + ":");
				if (newMap.getCollection(uniqueName) != null) {
					throw new IllegalStateException(uniqueName + "is already present in the the new map: " + newMap.getCollection(uniqueName) + "\nProperty map: " + invariantPropertyValues);
				} else {
					newMap.putAll(uniqueName, pairs);
				}
			}
		}
		table.setMap(newMap);
	}
	
	SortedMap<String, Double> getInvariantPropertyValues(Collection<KeyValue> pairs, List<String> invariantProperties) {
		int numberOfInvariantProperties = invariantProperties.size();
		TreeMap<String, Double> propertyMap = new TreeMap<String, Double>();
		
		for (KeyValue keyValue : pairs) {
			Object key = keyValue.getKey();
			if (invariantProperties.contains(key)) {
				propertyMap.put((String) key, (Double) keyValue.getValue());
			}
		}
		if (propertyMap.size() == numberOfInvariantProperties) {
			return propertyMap;
		} else {
			throw new IllegalStateException();
		}
	}
	/*
	 * End anonymous class issue handler implementation
	 */
	
	public void terminate() {
		checkTerminated();
		handleAnonymousClassSootIssue();
		try {
			createStatisticalTestsFile();
			table.dumpEntriesAndClose();
			terminated = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createSummaryFile() {
		try {
			table.createSummary();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createStatisticalTestsFile() throws IOException {
		RFile.make(table, statsFilePattern);
	}
	
	private void checkTerminated() throws IllegalStateException {
		if (terminated)
			throw new IllegalStateException("Sink already terminated");
	}
}