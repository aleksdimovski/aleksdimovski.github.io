package br.ufal.cideei.util;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import br.ufal.cideei.util.ColumnFilter;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class Tables2 {
	public static <R, C, V> Table<R, C, V> filterRows(Table<R, C, V> table, ColumnFilter <R, C, V> pred) {
		HashBasedTable<R, C, V> newTable = HashBasedTable.create(table);
		Map<R, V> items = table.column(pred.getColumn());
		Set<Entry<R, V>> entrySet = items.entrySet();
		for (Entry<R, V> entry : entrySet) {
			if (!pred.apply(entry.getKey(), entry.getValue())) {
				newTable.rowKeySet().remove(entry.getKey());
			}
		}
		return newTable;
	}
}