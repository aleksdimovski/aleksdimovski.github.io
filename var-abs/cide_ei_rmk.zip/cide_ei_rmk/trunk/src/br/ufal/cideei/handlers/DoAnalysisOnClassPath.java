/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.handlers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.handlers.HandlerUtil;

import soot.G;
import soot.PackManager;
import soot.Scene;
import soot.Transform;
import br.ufal.cideei.features.AlloyConfigurationCheck;
import br.ufal.cideei.features.CIDEFeatureExtracterFactory;
import br.ufal.cideei.features.FeatureSetChecker;
import br.ufal.cideei.features.IFeatureExtracter;
import br.ufal.cideei.soot.SootManager;
import br.ufal.cideei.soot.TransformExtendedOptions;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineLazyReachingDefinitions;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineLazyUninitializedVariables;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineLiftedReachingDefinitions;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineLiftedUninitializedVariableAnalysis;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineObliviousReachingDefinitionsAnalysis;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineObliviousUninitializedVariablesAnalysis;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineReversedLazyReachingDefinitions;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineReversedLazyUninitializedVariables;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineRunnerReachingDefinitions;
import br.ufal.cideei.soot.analyses.wholeline.WholeLineRunnerUninitializedVariable;
import br.ufal.cideei.soot.count.AssignmentsCounter;
import br.ufal.cideei.soot.count.LocalCounter;
import br.ufal.cideei.soot.count.MiscellaneousInfoCollector;
import br.ufal.cideei.soot.instrument.FeatureModelInstrumentor;
import br.ufal.cideei.soot.instrument.LazyConfigTag;
import br.ufal.cideei.util.Constants;
import br.ufal.cideei.util.count.MetricsSink;
import br.ufal.cideei.util.count.MetricsTable;
import br.ufpe.cin.dfa4spl.plverifier.alloy.io.CannotReadAlloyFileException;

/**
 * Invokes feature-sensitive analyses on a Java project.
 * 
 * @author Társis
 */
public class DoAnalysisOnClassPath extends AbstractHandler {
	// #ifdef METRICS
	private static MetricsSink sink;
	// #endif
	
	Map<Object, Object> options = new HashMap<Object, Object>();
	{
		options.put(Constants.INSTRUMENTATION_TAG_PROPERTY, LazyConfigTag.TAG_NAME);
		options.put(Constants.USE_FEATURE_MODEL, true);
		options.put(Constants.NUMBER_OF_ITERATIONS, 50);
		options.put(Constants.RESTRICT_METHODS, false);
		options.put(Constants.IGNORE_FEATURELESS_METHODS, false);
		options.put(Constants.IGNORE_METHODS, false);
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		//#ifdef CACHEPURGE
//@		br.Main.randomLong();
		//#endif
		
		try {
			IStructuredSelection selection = (IStructuredSelection) HandlerUtil.getActiveMenuSelection(event);
			Object firstElement = selection.getFirstElement();
			
			if (!(firstElement instanceof IJavaProject)) {
				throw new UnsupportedOperationException("Selected resource is not a Java project");
			}
			
			IJavaProject javaProject = (IJavaProject) firstElement;
			
			IClasspathEntry[] classPathEntries = null;
			try {
				classPathEntries = javaProject.getResolvedClasspath(true);
			} catch (JavaModelException e) {
				e.printStackTrace();
				throw new ExecutionException("No source classpath identified");
			}
			
			/*
			 * To build the path string variable that will represent Soot's classpath we will first iterate
			 * through all libs (.jars) files, then through all source classpaths.
			 * 
			 * FIXME: WARNING: A bug was found on Soot, in which the FileSourceTag would contain incorrect
			 * information regarding the absolute location of the source file. In this workaround, the classpath
			 * must be injected into the FeatureModelInstrumentorTransformer class (done through its
			 * constructor).
			 * 
			 * As a consequence, we CANNOT build an string with all classpaths that contains source code for the
			 * project and thus one only source code classpath can be analysed at a given time.
			 * 
			 * This seriously restricts the range of projects that can be analysed with this tool.
			 */
			List<IClasspathEntry> sourceClasspathEntries = new ArrayList<IClasspathEntry>();
			StringBuilder libsPaths = new StringBuilder();
			for (IClasspathEntry entry : classPathEntries) {
				if (entry.getEntryKind() == IClasspathEntry.CPE_LIBRARY) {
					File file = entry.getPath().makeAbsolute().toFile();
					if (file.isAbsolute()) {
						libsPaths.append(file.getAbsolutePath() + File.pathSeparator);
					} else {
						libsPaths.append(ResourcesPlugin.getWorkspace().getRoot().getFile(entry.getPath()).getLocation().toOSString() + File.pathSeparator);
					}
				}  else if (entry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
					sourceClasspathEntries.add(entry);
				}
			}
			
			if (sourceClasspathEntries.size() != 1) {
				throw new UnsupportedOperationException("Project must have exactly one source classpath entry");
			}
			
			IClasspathEntry entry = sourceClasspathEntries.get(0);
			
			final int times = (Integer) options.get(Constants.NUMBER_OF_ITERATIONS);
			for (int i = 0; i < times; i++) {
				// #ifdef METRICS
				String sinkFile = System.getProperty("user.home") + File.separator + javaProject.getElementName().trim().toLowerCase().replace(' ', '-') + "-fs";
				if ((Boolean) options.get(Constants.USE_FEATURE_MODEL)) {
					sinkFile += "-fm";
				}
				String statsFilePattern = System.getProperty("user.home") + File.separator + javaProject.getElementName().trim().toLowerCase().replace(' ', '-') + "-fs-stats";
				sink = new MetricsSink(new MetricsTable(new File(sinkFile + ".xls")), statsFilePattern);
				// #endif
				
				this.addPacks(javaProject, entry, libsPaths.toString());
				SootManager.reset();
				// #ifdef METRICS
				sink.terminate();
				// #endif
				System.out.println("=============" + (i + 1) + "/" + times + "=============");
			}
			sink.createSummaryFile();
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			SootManager.reset();
			// #ifdef METRICS
			if (sink != null && !sink.terminated()) {
				sink.terminate();
			}
			// #endif
		}

		return null;
	}

	/**
	 * Configures the classpath, sets up the transformers, load (jimplify) classes and run the packs.
	 * 
	 * @param javaProject
	 * @param entry
	 * @param libs
	 */
	private void addPacks(IJavaProject javaProject, IClasspathEntry entry, String libs) {
		/*
		 * if the classpath entry is "", then JDT will complain about it.
		 */
		String classPath;
		if (entry.getPath().toOSString().equals(File.separator + javaProject.getElementName())) {
			classPath = javaProject.getResource().getLocation().toFile().getAbsolutePath();
		} else {
			classPath = ResourcesPlugin.getWorkspace().getRoot().getFolder(entry.getPath()).getLocation().toOSString();
		}

		SootManager.configure(classPath + File.pathSeparator + libs);
		
		IFeatureExtracter extracter = CIDEFeatureExtracterFactory.getInstance().getExtracter();
		IPackageFragmentRoot[] packageFragmentRoots = javaProject.findPackageFragmentRoots(entry);
		for (IPackageFragmentRoot packageFragmentRoot : packageFragmentRoots) {
			IJavaElement[] children = null;
			try {
				children = packageFragmentRoot.getChildren();
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (IJavaElement child : children) {
				IPackageFragment packageFragment = (IPackageFragment) child;
				ICompilationUnit[] compilationUnits = null;
				try {
					compilationUnits = packageFragment.getCompilationUnits();
				} catch (JavaModelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				for (ICompilationUnit compilationUnit : compilationUnits) {
					String fragmentName = packageFragment.getElementName();
					String compilationName = compilationUnit.getElementName();
					StringBuilder qualifiedNameStrBuilder = new StringBuilder(fragmentName);
					// If it's the default package:
					if (qualifiedNameStrBuilder.length() == 0) {
						// Remove ".java" suffix
						qualifiedNameStrBuilder.append(compilationName.substring(0, compilationName.length() - 5));
					} else {
						// Remove ".java" suffix
						qualifiedNameStrBuilder.append(".").append(compilationName.substring(0, compilationName.length() - 5));
					}

					// This goes into Soot loadAndSupport
					SootManager.loadAndSupport(qualifiedNameStrBuilder.toString());
				}
			}
		}

		Scene.v().loadNecessaryClasses();
		
		AlloyConfigurationCheck alloyConfigurationCheck = null;
		if ((Boolean) options.get(Constants.USE_FEATURE_MODEL)) {
			String absolutePath = javaProject.getResource().getLocation().toFile().getAbsolutePath();
			try {
				alloyConfigurationCheck = new AlloyConfigurationCheck(absolutePath + File.separator + "fm.als");
			} catch (CannotReadAlloyFileException e) {
				e.printStackTrace();
				G.reset();
				return;
			}
		}
		
		if ((Boolean) options.get(Constants.RESTRICT_METHODS)) {
			restrictMethods(javaProject);
		}

		addPacks(classPath, extracter, alloyConfigurationCheck, options);

		SootManager.runPacks(extracter);
	}

	/**
	 * Sets the Constants.RESTRICT_METHODS option in the options map if a file
	 * called Constants.PROFILE_FILE_NAME exists in the project's folder and the
	 * property Constants.RESTRICTED_METHODS exists in that file. Otherwise,
	 * sets the Constants.RESTRICT_METHODS option to false;
	 * 
	 * @param javaProject
	 */
	private void restrictMethods(IJavaProject javaProject) {
		String absolutePath = javaProject.getResource().getLocation().toFile().getAbsolutePath();
		
		File restrictMethodsFile = new File(absolutePath + File.separator + Constants.PROFILE_FILE_NAME);
		if (restrictMethodsFile.exists()) {
			FileReader fileReader;
			try {
				fileReader = new FileReader(restrictMethodsFile);
			} catch (FileNotFoundException e) {
				G.reset();
				e.printStackTrace();
				return;
			}
			Properties properties = new Properties();
			try {
				properties.load(fileReader);
			} catch (IOException e) {
				G.reset();
				e.printStackTrace();
				return;
			}
			String restrictedMethodsProperty = properties.getProperty(Constants.RESTRICTED_METHODS);
			if (restrictedMethodsProperty == null) {
				options.put(Constants.RESTRICT_METHODS, false);
			} else {
				String[] split = restrictedMethodsProperty.split("@");
				if (split.length == 0) {
					options.put(Constants.RESTRICT_METHODS, false);
				} else {
					options.put(Constants.RESTRICTED_METHODS, new HashSet<String>(Arrays.asList(split)));
				}
			}
			String ignoredMethodsProperty = properties.getProperty(Constants.IGNORED_METHODS);
			if (ignoredMethodsProperty == null) {
				options.put(Constants.IGNORE_METHODS, false);
			} else {
				String[] split = ignoredMethodsProperty.split("@");
				if (split.length == 0) {
					options.put(Constants.IGNORE_METHODS, false);
				} else {
					options.put(Constants.IGNORED_METHODS, new HashSet<String>(Arrays.asList(split)));
				}
			}
		} else {
			options.put(Constants.RESTRICT_METHODS, false);
		}
	}

	private void addPacks(String classPath, IFeatureExtracter extracter, FeatureSetChecker checker, Map<Object, Object> extraOptions) {
		FeatureModelInstrumentor fmInstrumentor = (FeatureModelInstrumentor) new FeatureModelInstrumentor(extracter, classPath, checker)
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		;
		
		Transform instrumentation = new TransformExtendedOptions("jap.fminst", extraOptions, fmInstrumentor);
		PackManager.v().getPack("jap").add(instrumentation);
		
		Transform miscInformation = new TransformExtendedOptions("jap.misc", extraOptions, MiscellaneousInfoCollector.v()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(miscInformation);

		Transform reachingDefLazy = new TransformExtendedOptions("jap.lazy.rd",	extraOptions, WholeLineLazyReachingDefinitions.v()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(reachingDefLazy);
		
		Transform reachingDefReversedLazy = new TransformExtendedOptions("jap.revlazy.rd", extraOptions, WholeLineReversedLazyReachingDefinitions.v()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(reachingDefReversedLazy);
		
//		Transform uninitVarsLazy = new TransformExtendedOptions("jap.lazy.uv", extraOptions, WholeLineLazyUninitializedVariables.v()
		// #ifdef METRICS
//				.setMetricsSink(sink)
		// #endif
//		);
//		PackManager.v().getPack("jap").add(uninitVarsLazy);

//		Transform uninitVarsReversedLazy = new TransformExtendedOptions("jap.revlazy.uv", extraOptions, WholeLineReversedLazyUninitializedVariables.v()
		// #ifdef METRICS
//				.setMetricsSink(sink)
		// #endif
//		);
//		PackManager.v().getPack("jap").add(uninitVarsReversedLazy);
		 
		Transform reachingDefRunner = new TransformExtendedOptions("jap.eager.consecutive.rd", extraOptions, WholeLineRunnerReachingDefinitions.v()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(reachingDefRunner);

		Transform reachingDefLifted = new TransformExtendedOptions("jap.eager.simultaneous", extraOptions, new WholeLineLiftedReachingDefinitions()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(reachingDefLifted);

//		Transform uninitVarsLifted = new TransformExtendedOptions("jap.eager.simultaneous.uv", extraOptions, new WholeLineLiftedUninitializedVariableAnalysis()
		// #ifdef METRICS
//				.setMetricsSink(sink)
		// #endif
//		);
//		PackManager.v().getPack("jap").add(uninitVarsLifted);

//		Transform uninitVarsRunner = new TransformExtendedOptions("jap.eager.consecutive.uv", extraOptions, WholeLineRunnerUninitializedVariable.v()
		// #ifdef METRICS
//				.setMetricsSink(sink)
		// #endif
//		);
//		PackManager.v().getPack("jap").add(uninitVarsRunner);

		// #ifdef METRICS
		Transform assignmentsCounter = new TransformExtendedOptions("jap.counter.assgnmt", extraOptions, new AssignmentsCounter(sink, false));
		PackManager.v().getPack("jap").add(assignmentsCounter);

		Transform localCounter = new TransformExtendedOptions("jap.counter.local", extraOptions, new LocalCounter(sink, true));
		PackManager.v().getPack("jap").add(localCounter);
		// #endif
		
		Transform reachingDef = new TransformExtendedOptions("jap.simple.rd", extraOptions, WholeLineObliviousReachingDefinitionsAnalysis.v()
		// #ifdef METRICS
				.setMetricsSink(sink)
		// #endif
		);
		PackManager.v().getPack("jap").add(reachingDef);

//		Transform uninitVars = new TransformExtendedOptions("jap.simple.uv", extraOptions, WholeLineObliviousUninitializedVariablesAnalysis.v()
		// #ifdef METRICS
//				.setMetricsSink(sink)
		// #endif
//		);
//		PackManager.v().getPack("jap").add(uninitVars);
		
//		Transform testTransformer = new TransformExtendedOptions("jap.test", extraOptions, new LatticeEquivalenceTester());
//		PackManager.v().getPack("jap").add(testTransformer);
	}
}
