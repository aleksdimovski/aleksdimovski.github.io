package br.ufal.cideei.soot.instrument;

import java.io.File;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;
import org.apache.commons.collections.bidimap.UnmodifiableBidiMap;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.dom.CompilationUnit;

import soot.Body;
import soot.SootClass;
import soot.Unit;
import soot.tagkit.SourceFileTag;
import soot.tagkit.SourceLnPosTag;
import soot.tagkit.Tag;
import br.ufal.cideei.features.FeatureSetChecker;
import br.ufal.cideei.features.IFeatureExtracter;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.instrument.bitrep.BitVectorConfigRep;
import br.ufal.cideei.soot.instrument.bitrep.BitVectorFeatureRep;
import br.ufal.cideei.util.CachedICompilationUnitParser;
import br.ufal.cideei.util.Constants;
import br.ufal.cideei.util.count.AbstractMetricsSink;

public class BaseFeatureModelInstrumentor extends FilteredBodyTransformer {
	
	/** Feature extracter. */
	private static IFeatureExtracter extracter;
	/** Current compilation unit the transformation is working on */
	private IFile file;
	
	/**
	 * XXX: Workaround for the preTransform method. See comments on FeatureModelInstrumentorTransformer#preTransform()
	 * method.
	 */
	private static String classPath;
	private CachedICompilationUnitParser cachedParser = new CachedICompilationUnitParser();
	private CachedLineNumberMapper cachedLineColorMapper = new CachedLineNumberMapper();
	private Map<Integer, Set<String>> currentColorMap;
	private DualHashBidiMap emptyVectorFeatureMap;
	
	protected FeatureSetChecker fmChecker;
	// #ifdef METRICS
	protected static long colorLookupTableBuildingTime = 0;
	private AbstractMetricsSink sink;
	private long currentParsingDelta;
	private long currentColorLookUpTableDelta;
	protected static final String COLOR_LOOKUP = "color table";
	protected static final String PARSING = "parsing";
	protected static final String INSTRUMENTATION = "instrumentation";
	// #endif
	
	// TODO: implement reset method for the singleton instance.
	
	/*
	 * TODO: maybe injecting the sink depency in a different way could make this functionality less intrusive.
	 */
	public BaseFeatureModelInstrumentor(IFeatureExtracter extracter, String classPath, FeatureSetChecker checker) {
		BaseFeatureModelInstrumentor.classPath = classPath;
		BaseFeatureModelInstrumentor.extracter = extracter;
		this.fmChecker = checker;
	}

	// #ifdef METRICS
	public BaseFeatureModelInstrumentor setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif
	
	/**
	 * A (constant) IFeatureRep representing the absence of features.
	 * 
	 * @return
	 */
	protected IFeatureRep emptyFeatureRep() {
		this.emptyVectorFeatureMap = new DualHashBidiMap();
		return new BitVectorFeatureRep(Collections.<String>emptySet(), emptyVectorFeatureMap);
	}
	
	/**
	 * Return an IFeatureRep that represents the set {@code features}.
	 * enabled in the {@code context}
	 * 
	 * @param features enabled features
	 * @param context context that containst the features
	 * @return the IFeatureRep
	 */
	protected IFeatureRep featureRep(Set<String> features, BidiMap context) {
		return new BitVectorFeatureRep(features, context);
	}

	/**
	 * Called(back) at the end of the instrumentation process.
	 * 
	 * @param featuresId a String -> Integer mapping
	 * @param body 
	 */
	protected void endBodyInstrumentation(Body body, String phase, Map options, UnmodifiableBidiMap featuresId) {
	}

	@Override
	/**
	 * Iterate over all units, look up for their colors and add a new FeatureTag to each of them, and also compute
	 * all the colors found in the whole body. Units with no colors receive an empty FeatureTag.
	 */
	protected void filteredInternalTransform(Body body, String phase, Map options) {
		preTransform(body);
		IFeatureRep emptyFeatureRep = emptyFeatureRep();
		FeatureTag emptyFeatureTag = new FeatureTag(emptyFeatureRep);

		// #ifdef METRICS
		long startTransform = System.nanoTime();
		// #endif
		
		Iterator<Unit> unitIt = body.getUnits().iterator();

		// XXX will break when there are more than 32 in a method. use a bitvector?
		// String->Integer
		BidiMap allFeaturesSoFar = new DualHashBidiMap();

		int idGen = 1;
		while (unitIt.hasNext()) {
			Unit nextUnit = unitIt.next();
			SourceLnPosTag lineTag = (SourceLnPosTag) nextUnit.getTag("SourceLnPosTag");
			if (lineTag == null) {
				nextUnit.addTag(emptyFeatureTag);
			} else {
				int unitLine = lineTag.startLn();
				Set<String> nextUnitFeatures = currentColorMap.get(unitLine);
				if (nextUnitFeatures != null) {
					for (String featureName : nextUnitFeatures) {
						if (!allFeaturesSoFar.containsKey(featureName)) {
							allFeaturesSoFar.put(featureName, idGen);
							idGen = idGen << 1;
						}
					}

					IFeatureRep featureRep = featureRep(nextUnitFeatures, allFeaturesSoFar);
					nextUnit.addTag(new FeatureTag(featureRep));
				} else {
					nextUnit.addTag(emptyFeatureTag);
				}
			}
		}
		
		long transformationDelta = System.nanoTime() - startTransform;
		
		UnmodifiableBidiMap unmodAllPresentFeaturesId = (UnmodifiableBidiMap) UnmodifiableBidiMap.decorate(allFeaturesSoFar);
		
		emptyVectorFeatureMap.putAll(allFeaturesSoFar);
		if (emptyFeatureRep instanceof BitVectorFeatureRep) {
			((BitVectorFeatureRep) emptyFeatureRep).computeBitVector();
		}
		
		endBodyInstrumentation(body, phase, options, unmodAllPresentFeaturesId);
		
		// #ifdef METRICS
		if (sink != null) {
			Object ignoreFeaturelessMethods = options.get(Constants.IGNORE_FEATURELESS_METHODS);
			if (ignoreFeaturelessMethods != null && ignoreFeaturelessMethods instanceof Boolean) {
				boolean ignoreFeatureless =  (Boolean) ignoreFeaturelessMethods;
				Tag tag = body.getTag((String) options.get(Constants.INSTRUMENTATION_TAG_PROPERTY));
				if (tag == null) {
					throw new IllegalStateException();
				}
				if (ignoreFeatureless) {
					if (tag instanceof ISizeable) {
						if (((ISizeable) tag).getSize() > 1 && ignoreFeatureless) {
							sink.flow(body, BaseFeatureModelInstrumentor.COLOR_LOOKUP, this.currentColorLookUpTableDelta);
							sink.flow(body, BaseFeatureModelInstrumentor.PARSING, this.currentParsingDelta);
							sink.flow(body, BaseFeatureModelInstrumentor.INSTRUMENTATION, transformationDelta);
						} else {
							// time was wasted...
						}
					} else {
						throw new IllegalStateException();
					}
				} else {
					sink.flow(body, BaseFeatureModelInstrumentor.COLOR_LOOKUP, this.currentColorLookUpTableDelta);
					sink.flow(body, BaseFeatureModelInstrumentor.PARSING, this.currentParsingDelta);
					sink.flow(body, BaseFeatureModelInstrumentor.INSTRUMENTATION, transformationDelta);
				}
			}
		}
		// #endif
	}

	private void preTransform(Body body) {
		SootClass sootClass = body.getMethod().getDeclaringClass();
		if (!sootClass.hasTag("SourceFileTag")) {
			throw new IllegalArgumentException("the body cannot be traced to its source file");
		}
		/*
		 * XXX: WARNING! tag.getAbsolutePath() returns an INCORRECT value for the absolute path AFTER the first body
		 * transformation. In this workaround, since this method depends on the classpath , it is injected on this class
		 * constructor. We will use tag.getSourceFile() in order to resolve the file name.
		 * 
		 * Yes, this is ugly.
		 */
		SourceFileTag sourceFileTag = (SourceFileTag) body.getMethod().getDeclaringClass().getTag("SourceFileTag");

		/*
		 * The String absolutePath will be transformed to the absolute path to the Class which body belongs to. See the
		 * XXX above for the explanation.
		 */
		String absolutePath = sootClass.getName();
		int lastIndexOf = absolutePath.lastIndexOf(".");
		if (lastIndexOf != -1) {
			absolutePath = absolutePath.substring(0, lastIndexOf);
		} else {
			absolutePath = "";
		}

		/*
		 * XXX String#replaceAll does not work properly when replacing "special" chars like File.separator. The Matcher
		 * and Pattern composes a workaround for that.
		 */
		absolutePath = absolutePath.replaceAll(Pattern.quote("."), Matcher.quoteReplacement(File.separator));
		absolutePath = classPath + File.separator + absolutePath + File.separator + sourceFileTag.getSourceFile();
		sourceFileTag.setAbsolutePath(absolutePath);

		IPath path = new Path(sourceFileTag.getAbsolutePath());
		this.file = org.eclipse.core.resources.ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(path);

		// #ifdef METRICS
		long startCompilationUnitParser = System.nanoTime();
		// #endif
		CompilationUnit compilationUnit = cachedParser.parse(file);
		// #ifdef METRICS
		long parsingDelta = System.nanoTime() - startCompilationUnitParser;
		this.currentParsingDelta = parsingDelta;

		long startBuilderColorLookUpTable = System.nanoTime();
		// #endif
		this.currentColorMap = cachedLineColorMapper.makeAccept(compilationUnit, file, extracter, compilationUnit);
		// #ifdef METRICS
		long builderColorLookUpTableDelta = System.nanoTime() - startBuilderColorLookUpTable;
		this.currentColorLookUpTableDelta = builderColorLookUpTableDelta;
		BaseFeatureModelInstrumentor.colorLookupTableBuildingTime += builderColorLookUpTableDelta;
		// #endif
	}

}
