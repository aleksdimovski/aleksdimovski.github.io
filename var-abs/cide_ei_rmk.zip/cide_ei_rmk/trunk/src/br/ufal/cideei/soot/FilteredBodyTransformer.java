package br.ufal.cideei.soot;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import br.ufal.cideei.soot.instrument.ISizeable;
import br.ufal.cideei.util.Constants;
import br.ufal.cideei.util.Filter;

import soot.Body;
import soot.BodyTransformer;
import soot.tagkit.Tag;

/**
 * Conditions the execution of the transformation to a set of globally defined
 * filters.
 * 
 * @author Társis Tolêdo
 * 
 */
public abstract class FilteredBodyTransformer extends BodyTransformer {
	
	private static final int TIMEOUT = 600;
	private static Set<Filter<Object[]>> filters = new HashSet<Filter<Object[]>>();
	static {
		
		filters.add(new Filter<Object[]>() {
			@Override
			public boolean accept(Object[] element) {
				Body body = (Body) element[0];
				Map options = (Map) element[2];
				if ((Boolean) options.get(Constants.IGNORE_METHODS)) {
					Collection<String> methods = (Collection<String>) options.get(Constants.IGNORED_METHODS);
					return !methods.contains(body.getMethod().getSignature());
				} else {
					return true;
				}
			}
		});
		
		filters.add(new Filter<Object[]>() {
			@Override
			public boolean accept(Object[] element) {
				Body body = (Body) element[0];
				Map options = (Map) element[2];
				if ((Boolean) options.get(Constants.RESTRICT_METHODS)) {
					Collection<String> methods = (Collection<String>) options.get(Constants.RESTRICTED_METHODS);
					return !methods.contains(body.getMethod().getSignature());
				} else {
					return true;
				}
			}
		});
		
		filters.add(new Filter<Object[]>() {
			@Override
			public boolean accept(Object[] element) {
				String phaseName = (String) element[1];
				if (phaseName.equals("jap.fminst")) {
					return true;
				}
				Map options = (Map) element[2];
				Object ignoreFeaturelessMethods = options.get(Constants.IGNORE_FEATURELESS_METHODS);
				if (ignoreFeaturelessMethods instanceof Boolean && (Boolean) ignoreFeaturelessMethods) {
					Body body = (Body) element[0];
					Tag tag = body.getTag((String) options.get(Constants.INSTRUMENTATION_TAG_PROPERTY));
					if (tag != null && tag instanceof ISizeable) {
						return ((ISizeable) tag).getSize() > 1;
					} else {
						return false;
					}
				} else {
					return true;
				}
			}
		});
		
		
	}

	@Override
	protected final void internalTransform(final Body body, final String phaseName, final Map options) {
		for (Filter<Object[]> filter : FilteredBodyTransformer.filters) {
			if (!filter.accept(new Object[] {body, phaseName, options})) {
				return;
			}
		}
		
		 ExecutorService executor = Executors.newSingleThreadExecutor();
	     Future<Void> future = executor.submit(new Callable<Void>() {
			@Override
			public Void call() throws Exception {
				filteredInternalTransform(body, phaseName, options);
				return null;
			}
	     });

        try {
			future.get(FilteredBodyTransformer.TIMEOUT, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            System.err.println("Transformer " + this + " did not finish within " + 
            		FilteredBodyTransformer.TIMEOUT + "s for method " + 
            		body.getMethod().getSignature());
        } catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			executor.shutdownNow();
		}
	}
	
	protected abstract void filteredInternalTransform(Body body, String phaseName, Map options);
}
