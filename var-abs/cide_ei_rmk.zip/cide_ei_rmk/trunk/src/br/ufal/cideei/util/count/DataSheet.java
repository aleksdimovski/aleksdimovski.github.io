package br.ufal.cideei.util.count;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class DataSheet extends SummarySheet {
	
	private Benchmark bench;
	private Workbook workbook;
	private TreeMap<String, Integer> headerIndexMapping = new TreeMap<String, Integer>();
	private Sheet someSheet;
	private Row firstRow;
	
	interface Acceptor<T> {
		public boolean accept(T element);
	}
	
	private Acceptor<String> acceptor = new Acceptor<String>() {

		@Override
		public boolean accept(String element) {
			return element.contains("analysis time")
					|| element.contains("instrumentation")
					|| element.contains("color table")
					|| element.contains("jimplification");
		}
		
	};

	public DataSheet(Benchmark bench) throws InvalidFormatException, IOException {
		this.bench = bench;
		FileInputStream fileInputStream = new FileInputStream(new File(bench.file()));
		this.workbook = WorkbookFactory.create(fileInputStream);
		fileInputStream.close();
		
		this.someSheet = workbook.getSheetAt(0);
		this.firstRow = someSheet.getRow(0);
		int index = 1;
		Cell cell = firstRow.getCell(index);;
		while (cell != null) {
			String stringCellValue = cell.getStringCellValue();
			if (acceptor.accept(stringCellValue)) {
				headerIndexMapping.put(stringCellValue, index - 1);
			}
			cell = firstRow.getCell(index);
			index++;
		}
		
	}

	@Override
	public void summary() throws IOException {
		List<List<String>> listOfLists = new ArrayList<List<String>>();
		
		for (Entry<String, Integer> entry : headerIndexMapping.entrySet()) {
			Integer index = entry.getValue();
			String header = entry.getKey();
			List<String> oneFromEverySheet = oneFromEverySheet(workbook, bench.sumFooterRow(), index);
			oneFromEverySheet.add(0, header);
			listOfLists.add(oneFromEverySheet);
		}
		
		writeTable(workbook, listOfLists);
		writeWorkbookToFile(workbook, bench);
	}

}
