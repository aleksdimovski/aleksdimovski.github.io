package br.ufal.cideei.soot.instrument;

public enum InstrumentationType {
	LAZY, EAGER;
}
