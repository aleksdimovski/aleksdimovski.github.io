/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.util.Map;

import soot.Body;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.uninitvars.LazyLiftedUninitializedVariableAnalysis;
//#ifdef HYBRID
//@import br.ufal.cideei.soot.analyses.uninitvars.SimpleUninitializedVariableAnalysis;
//#endif
import br.ufal.cideei.soot.instrument.ILazyConfigRep;
import br.ufal.cideei.soot.instrument.LazyConfigTag;
import br.ufal.cideei.util.count.AbstractMetricsSink;

//TODO: can this class structure could be replaced by an abstract factory?
public class WholeLineLazyUninitializedVariables extends FilteredBodyTransformer {

	private static WholeLineLazyUninitializedVariables instance = new WholeLineLazyUninitializedVariables();

	private WholeLineLazyUninitializedVariables() {
	}

	public static WholeLineLazyUninitializedVariables v() {
		return instance;
	}

	// #ifdef METRICS
	private static final String UV_LAZY_FLOWTHROUGH_COUNTER = "flowthrough count (uv a4)";
	private static final String UV_LAZY_SHARING_DEGREE = "sharing degree (uv a4)";
	private static final String UV_LAZY_MEM = "mem (uv a4)";
	private static final String UV_LAZY_FLOWTHROUGH_TIME = "flowthrough time (uv a4)";
	private static final String UV_LAZY_TIME = "analysis time (uv a4)";
	private AbstractMetricsSink sink;

	public WholeLineLazyUninitializedVariables setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void filteredInternalTransform(Body body, String phase, Map options) {
		LazyConfigTag configTag = (LazyConfigTag) body.getTag(LazyConfigTag.TAG_NAME);
		if (configTag == null) {
			throw new IllegalStateException("No LazyConfigTag found for body of method " + body.getMethod());
		}
		
		ILazyConfigRep lazyConfig = configTag.getLazyConfig();
		if (lazyConfig.size() < 1) {
			return;
		}
		
		UnitGraph bodyGraph = new BriefUnitGraph(body);
//		int size = configTag.getLazyConfig().size();

		LazyLiftedUninitializedVariableAnalysis lazyUninitializedVariables = null;
		boolean wentHybrid = false;

		// #ifdef METRICS
		long startAnalysis = System.nanoTime();
		// #endif

		// #ifdef HYBRID
//@		if (size == 1) {
//@			SimpleUninitializedVariableAnalysis uninitializedVariables = new SimpleUninitializedVariableAnalysis(bodyGraph);
//@			wentHybrid = true;
//@		} else {
			// #endif
			lazyUninitializedVariables = new LazyLiftedUninitializedVariableAnalysis(bodyGraph, lazyConfig);
			// #ifdef HYBRID
//@		}
		// #endif

		// #ifdef METRICS
			
		long analysisTime = System.nanoTime() - startAnalysis;
		
		this.sink.flow(body, UV_LAZY_TIME, analysisTime);

		if (!wentHybrid) {
			this.sink.flow(body, UV_LAZY_FLOWTHROUGH_TIME, lazyUninitializedVariables.getFlowThroughTime());
			this.sink.flow(body, UV_LAZY_MEM, FlowSetUtils.lazyMemoryUnits(body, lazyUninitializedVariables, 1));
			this.sink.flow(body, UV_LAZY_SHARING_DEGREE, FlowSetUtils.averageSharingDegree(body, lazyUninitializedVariables));
			this.sink.flow(body, UV_LAZY_FLOWTHROUGH_COUNTER, LazyLiftedUninitializedVariableAnalysis.getFlowThroughCounter());
			LazyLiftedUninitializedVariableAnalysis.reset();
		} 		
		// #endif
	}
}

