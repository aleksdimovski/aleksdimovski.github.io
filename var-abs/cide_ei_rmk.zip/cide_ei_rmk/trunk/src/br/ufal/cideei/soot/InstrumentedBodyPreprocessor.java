package br.ufal.cideei.soot;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import br.ufal.cideei.soot.instrument.EagerConfigTag;
import br.ufal.cideei.soot.instrument.FeatureTag;
import br.ufal.cideei.soot.instrument.IConfigRep;
import soot.Body;
import soot.PatchingChain;
import soot.Unit;
import soot.jimple.Jimple;
import soot.jimple.JimpleBody;

public class InstrumentedBodyPreprocessor {
	
	private static Map<Body, WeakReference<Body>> cache = new WeakHashMap<Body, WeakReference<Body>>();
	
	public static Body preprocess(Body body, IConfigRep config) {
		WeakReference<Body> weakReference = cache.get(body);
		if (weakReference != null) {
			Body mayBeCached = weakReference.get();
			if (mayBeCached != null) {
				return mayBeCached;
			}
		}
		
		JimpleBody newBody = Jimple.v().newBody(body.getMethod());
		newBody.importBodyContentsFrom(body);

		PatchingChain<Unit> newBodyUnits = newBody.getUnits();
		Iterator<Unit> snapshotIterator = newBodyUnits.snapshotIterator();

		while (snapshotIterator.hasNext()) {
			Unit unit = (Unit) snapshotIterator.next();
			FeatureTag unitFeatureTag = (FeatureTag) unit.getTag("FeatureTag");
			if (!unitFeatureTag.getFeatureRep().belongsToConfiguration(config)) {
				newBodyUnits.remove(unit);
			}
		}
		
		cache.put(body, new WeakReference<Body>(newBody));
		return newBody;
	}
	
	public static final class MinimalAndMaximalBody {
		private final Body minimal;
		private final Body maximal;

		protected MinimalAndMaximalBody(Body minimal, Body maximal) {
			if (minimal.getUnits().size() < maximal.getUnits().size()) {
				throw new IllegalArgumentException();
			}
			this.minimal = minimal;
			this.maximal = maximal;
		}

		public Body getMinimal() {
			return minimal;
		}

		public Body getMaximal() {
			return maximal;
		}
	}
	
	public static MinimalAndMaximalBody minimalAndMaximalBody(Body body) {
		int maximalBodySize = body.getUnits().size();
		Body maximalBody = body;
		int minimalBodySize = 0;
		Body minimalBody = null;
		
		EagerConfigTag configTag = (EagerConfigTag) body.getTag(EagerConfigTag.TAG_NAME);
		
		Set<IConfigRep> configs = configTag.getConfigReps();
		for (IConfigRep config : configs) {
			Body newBody = InstrumentedBodyPreprocessor.preprocess(body, config);
			PatchingChain<Unit> newBodyUnits = newBody.getUnits();

			/*
			 * If the body size is 0, then cannot continue. Store maximum and minimal size.
			 */
			int newBodySize = newBodyUnits.size();

			if (newBodySize > maximalBodySize) {
				maximalBodySize = newBodySize;
				maximalBody = newBody;
			}
			if (newBodySize < minimalBodySize && newBodySize > 0) {
				minimalBodySize = newBodySize;
				minimalBody = newBody;
			}
		}
		
		if (minimalBody == null) {
			minimalBody = body;
			minimalBodySize = body.getUnits().size();
		}
		
		return new MinimalAndMaximalBody(minimalBody, maximalBody);
	}
}
