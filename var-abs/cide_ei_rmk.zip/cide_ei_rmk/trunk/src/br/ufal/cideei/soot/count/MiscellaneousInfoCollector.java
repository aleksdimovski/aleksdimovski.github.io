/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.count;

import java.util.Map;

import profiling.ProfilingTag;

import soot.Body;
import soot.Transformer;
import soot.Unit;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIfStmt;
import soot.tagkit.Tag;
import soot.toolkits.graph.BriefUnitGraph;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.InstrumentedBodyPreprocessor;
import br.ufal.cideei.soot.InstrumentedBodyPreprocessor.MinimalAndMaximalBody;
import br.ufal.cideei.soot.instrument.ISizeable;
import br.ufal.cideei.util.Constants;
import br.ufal.cideei.util.count.MetricsSink;

public class MiscellaneousInfoCollector extends FilteredBodyTransformer {

	private static final String CONFIGURATIONS_SIZE = "configurations";
	private static final String NUMBER_OF_UNITS = "units";
	private static final String JIMPLIFICATION = "jimplification";
	private static final String CYCLOMATIC_COMPLEXITY = "cyclomatic complexity";
	private static final String GOTO_COUNTER = "gotos";
	private static final String ESTIMATED_COMPILATION = "estimated compilation";
	private static MiscellaneousInfoCollector instance = new MiscellaneousInfoCollector();
	private MetricsSink sink;

	private MiscellaneousInfoCollector() {
	}

	public static MiscellaneousInfoCollector v() {
		return instance;
	}
	
	public Transformer setMetricsSink(MetricsSink sink) {
		this.sink = sink;
		return this;
	}

	@Override
	protected void filteredInternalTransform(Body body, String phase, Map opt) {
		long noOfConfigurations;
		Tag configTag = body.getTag((String) opt.get(Constants.INSTRUMENTATION_TAG_PROPERTY));
		if (configTag instanceof ISizeable) {
			noOfConfigurations = ((ISizeable) configTag).getSize();
		} else {
			throw new IllegalStateException("No (Sizeable) configuration tag found or tag is null");
		}
		
		BriefUnitGraph unitGraph = new BriefUnitGraph(body);
		
		sink.flow(body, CYCLOMATIC_COMPLEXITY, calculateCyclomaticComplexity(unitGraph));
		sink.flow(body, GOTO_COUNTER, countGotos(unitGraph));
		sink.flow(body, CONFIGURATIONS_SIZE, noOfConfigurations);
		sink.flow(body, NUMBER_OF_UNITS, body.getUnits().size());

		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		long jimplificationTime = profilingTag.getJimplificationTime();
		sink.flow(body, JIMPLIFICATION, jimplificationTime);
		
		MinimalAndMaximalBody bodies = InstrumentedBodyPreprocessor.minimalAndMaximalBody(body);
		Body minimalBody = bodies.getMinimal();
		Body maximalBody = bodies.getMaximal();

		int minimalBodySize = minimalBody.getUnits().size();
		int maximalBodySize = maximalBody.getUnits().size();
		
		double minimalProportionalJimplificationTime = (minimalBodySize * jimplificationTime) / maximalBodySize;
		double averageEstimatedCompilation = (jimplificationTime + minimalProportionalJimplificationTime) / 2;
		double totalEstimatedCompilation = averageEstimatedCompilation * noOfConfigurations;
		
		sink.flow(body, ESTIMATED_COMPILATION, totalEstimatedCompilation);
	}

	private int countGotos(BriefUnitGraph unitGraph) {
		int gotoCounter = 0;
		for (Unit unit : unitGraph) {
			if (unit instanceof JGotoStmt) {
				gotoCounter++;
			}
		}
		return gotoCounter;
	}

	private int calculateCyclomaticComplexity(BriefUnitGraph unitGraph) {
		int cyclomaticComplexity = 1;
		for (Unit unit : unitGraph) {
			if (unit instanceof JIfStmt) {
				cyclomaticComplexity++;
			}
		}
		return cyclomaticComplexity;
	}

}
