/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;


//#ifdef METRICS

//#ifdef OVERSEER
//@import ch.usi.overseer.OverHpc;
//@
//#endif

import br.ufal.cideei.util.count.AbstractMetricsSink;
//import profiling.ProfilingTag;

//#endif

import soot.Body;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.analyses.FlowSetUtils;
import br.ufal.cideei.soot.analyses.reachingdefs.UnliftedReachingDefinitions;
import br.ufal.cideei.soot.instrument.EagerConfigTag;
import br.ufal.cideei.soot.instrument.IConfigRep;

public class WholeLineRunnerReachingDefinitions extends FilteredBodyTransformer {

	private static WholeLineRunnerReachingDefinitions instance = new WholeLineRunnerReachingDefinitions();

	private WholeLineRunnerReachingDefinitions() {
	}

	public static WholeLineRunnerReachingDefinitions v() {
		return instance;
	}

	// #ifdef METRICS
	private static final String RD_RUNNER_FLOWTHROUGH_COUNTER = "flowthrough count (rd a2)";
	private static final String RD_RUNNER_FLOWSET_MEM = "mem (rd a2)";
	private static final String RD_RUNNER_FLOWTHROUGH_TIME = "flowthrough time (rd a2)";
	private static final String RD_RUNNER_L1_FLOWTHROUGH_COUNTER = "normal flowthrough count (rd a2)";
	private static final String RD_RUNNER_TIME = "analysis time (rd a2)";
	
	
	//#ifdef OVERSEER
//@	private static final String RD_RUNNER_CACHE_MISSES = "cache misses (rd a2)";
	//#endif
	
	private AbstractMetricsSink sink;

	public WholeLineRunnerReachingDefinitions setMetricsSink(AbstractMetricsSink sink) {
		this.sink = sink;
		return this;
	}

	// #endif

	@Override
	protected void filteredInternalTransform(Body body, String phase, Map options) {
		EagerConfigTag configTag = (EagerConfigTag) body.getTag(EagerConfigTag.TAG_NAME);
		
		if (configTag == null) {
			throw new IllegalStateException("No EagerConfigTag found for body of method " + body.getMethod());
		}
		
		Set<IConfigRep> configReps = configTag.getConfigReps();
		if (configReps.size() < 1) {
			return;
		}
		
		UnitGraph bodyGraph = new BriefUnitGraph(body);
		List<Long> memUnits = new ArrayList<Long>();

		// #ifdef METRICS
		
		//#ifdef OVERSEER
//@		OverHpc ohpc = OverHpc.getInstance();
//@		ohpc.initEvents("PERF_COUNT_HW_CACHE_MISSES");
//@		int threadId = ohpc.getThreadId();
//@		ohpc.bindEventsToThread(threadId);
//@		ohpc.stop();
//@		ohpc.start();
		//#endif
		
		long startAnalysis = System.nanoTime();
		long flowThroughTime = 0;
		// #endif

		for (IConfigRep config : configReps) {
			UnliftedReachingDefinitions unliftedReachingDefinitions = new UnliftedReachingDefinitions(bodyGraph, config);

			// #ifdef METRICS
			memUnits.add(FlowSetUtils.unliftedMemoryUnits(body, unliftedReachingDefinitions, 1));
			flowThroughTime += unliftedReachingDefinitions.getFlowThroughTime();

			// #endif
		}

		// #ifdef METRICS
		long analysisTime = System.nanoTime() - startAnalysis;

		//#ifdef OVERSEER
//@		long cacheMissesFromThread = ohpc.getEventFromThread(threadId, 0);
//@		ohpc.stop();
//@		OverHpc.shutdown();
		//#endif
		
		this.sink.flow(body, RD_RUNNER_TIME, analysisTime);
		this.sink.flow(body, RD_RUNNER_FLOWTHROUGH_TIME, flowThroughTime);
		Long max = Collections.max(memUnits);
		this.sink.flow(body, RD_RUNNER_FLOWSET_MEM, max);
		this.sink.flow(body, RD_RUNNER_FLOWTHROUGH_COUNTER, UnliftedReachingDefinitions.getFlowThroughCounter());
		this.sink.flow(body, RD_RUNNER_L1_FLOWTHROUGH_COUNTER, UnliftedReachingDefinitions.getL1flowThroughCounter());
		
		//#ifdef OVERSEER
//@		this.sink.flow(body, RD_RUNNER_CACHE_MISSES, cacheMissesFromThread);
//@		
		//#endif
		UnliftedReachingDefinitions.reset();
		// #endif
	}
}
