package br.ufal.cideei.util.count;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.collections.map.AbstractMapDecorator;
import org.apache.commons.collections.map.MultiValueMap;

import br.ufal.cideei.util.ColumnFilter;
import br.ufal.cideei.util.Tables2;

import com.google.common.collect.Table;
import com.google.common.collect.TreeBasedTable;

public class RFile {

	private static Map<String, String> groupMap = new HashMap<String, String>();
	
	public static void make(MetricsTable metrics, String statsFilePattern) throws IOException {
		TreeBasedTable<String, String, Double> table = toTable(metrics);
		
//		ColumnFilter<String, String, Double> oneConfigsFilter = exactConfigFilter(1);
		ColumnFilter<String, String, Double> moreThanOneConfigFilter = greaterThanConfigFilter(1);
		ColumnFilter<String, String, Double> twoConfigsFilter = exactConfigFilter(2);
//		ColumnFilter<String, String, Double> threeConfigsFilter = exactConfigFilter(3);
		ColumnFilter<String, String, Double> fourConfigsFilter = exactConfigFilter(4);
		ColumnFilter<String, String, Double> moreThanFourConfigsFilter = greaterThanConfigFilter(4);
		
		List<ColumnFilter<String, String, Double>> filters = 
			Arrays.asList(
				moreThanOneConfigFilter, 
				twoConfigsFilter, 
//				threeConfigsFilter, 
				fourConfigsFilter, 
				moreThanFourConfigsFilter);
		
		int salt = 0;
		File statsFile = new File(statsFilePattern + salt + ".R");
		while (statsFile.exists()) {
			salt++;
			statsFile = new File(statsFilePattern + salt + ".R");
		}
		String xmlFileOutput = statsFilePattern + salt + ".xml";
		
		FileWriter writer = new FileWriter(statsFile);
		
		writeHeader(writer);
		
		for (ColumnFilter<String, String, Double> filter : filters) {
			Table<String, String, Double> filteredTable = Tables2.filterRows(table, filter);
			
			Collection<Double> a2Values = filteredTable.column("analysis time (rd a2)").values();
			Collection<Double> a3Values = filteredTable.column("analysis time (rd a3)").values();
			Collection<Double> a4Values = filteredTable.column("analysis time (rd a4)").values();
			Collection<Double> a5Values = filteredTable.column("analysis time (rd a5)").values();
			
			writer.write("\n");
			writer.write('#' + filter.toString());
			writer.write("\n");
			
			writer.write("group = newXMLNode(\"group\")\n" +
					     "addChildren(root, group)\n" +
					     "addAttributes(group, desc = \"" + filter.toString() + "\")\n");
			
			Collection<Double> a2a3Ratios = ratios(a2Values, a3Values);
			writeCodeFor(writer, a2a3Ratios, "A2", "A3");
			Collection<Double> a2a4Ratios = ratios(a2Values, a4Values);
			writeCodeFor(writer, a2a4Ratios, "A2", "A4");
			Collection<Double> a2a5Ratios = ratios(a2Values, a5Values);
			writeCodeFor(writer, a2a5Ratios, "A2", "A5");
			Collection<Double> a3a4Ratios = ratios(a3Values, a4Values);
			writeCodeFor(writer, a3a4Ratios, "A3", "A4");
			Collection<Double> a3a5Ratios = ratios(a3Values, a5Values);
			writeCodeFor(writer, a3a5Ratios, "A3", "A5");
			Collection<Double> a4a5Ratios = ratios(a4Values, a5Values);
			writeCodeFor(writer, a4a5Ratios, "A4", "A5");
			
			writer.write("saveXML(root, \"" + xmlFileOutput + "\")\n");
			groupMap.clear();
		}
		
		writer.close();
	}

	private static void writeHeader(FileWriter writer) throws IOException {
		writer.write(function("library", Collections.singleton("gdata")));
		writer.write("\n");
		writer.write(function("library", Collections.singleton("utils")));
		writer.write("\n");
		writer.write(function("library", Collections.singleton("XML")));
		writer.write("\n");
		writer.write(assignment("root", "newXMLNode(\"iterations\")"));
		writer.write("\n");
		writer.write("\n");
	}

	private static String quote(String string) {
		return "\"" + string + "\"";
	}

	private static void writeCodeFor(Writer writer, Collection<Double> ratios, String type1, String type2) throws IOException {
		if (ratios.size() > 0) {
			writer.write(generateCode(ratios, type1, type2));
		}
	}

	private static TreeBasedTable<String, String, Double> toTable(
			MetricsTable metrics) {
		MultiValueMap tableMap = metrics.getMap();
		TreeBasedTable<String, String, Double> table = TreeBasedTable.create();
		Set keySet = tableMap.keySet();
		for (Object keyObject : keySet) {
			String key = (String) keyObject;
			Collection collection = tableMap.getCollection(key);
			for (Object pairObject : collection) {
				KeyValue pair = (KeyValue) pairObject;
				table.put(key, (String) pair.getKey(), (Double) pair.getValue());
			}
		}
		return table;
	}

	private static String generateCode(Collection<Double> ratios, String type1, String type2) {
		StringBuilder builder = new StringBuilder();
		
		String groupName = groupMap.get(type1);
		if (groupName == null) {
			groupName = "group" + type1;
			groupMap.put(type1, groupName);
			builder.append(assignment(groupName, "newXMLNode(\"" + type1 + "\")\n"));
			builder.append("addChildren(group, " + groupName + ")\n");
		}
		
		builder.append("\n");
		String varName = "ratio" + type1 + type2;
		builder.append(assignment(varName, function("c", ratios)));
		builder.append("\n");
		builder.append(assignment("wilcoxResult", function("wilcox.test",Arrays.asList("as.numeric(" + varName + ")","mu=1"))));
		builder.append("\n");
		builder.append(assignment(groupName + type2, "newXMLNode(\"" + type2 + "\", wilcoxResult$p.value)\n"));
		builder.append("addChildren(" + groupName + ", " + groupName + type2 + ")\n");
		
		return builder.toString();
	}

	private static Collection<Double> ratios(Collection<Double> values1, Collection<Double> values2) {
		List<Double> list1 = new ArrayList<Double>(values1);
		int size = list1.size();
		List<Double> list2 = new ArrayList<Double>(values2);
		ArrayList<Double> result = new ArrayList<Double>();
		for (int index = 0; index < size; index++) {
			result.add(list1.get(index) / list2.get(index));
		}
		return result;
	}
	
	private static <L, R> String assignment(L lhs, R rhs) {
		StringBuilder builder = new StringBuilder();
		builder.append(lhs);
		builder.append(" = ");
		builder.append(rhs);
		return builder.toString();
	}
	
	private static <T, F> String function(F functionName, Collection<T> arguments) {
		StringBuilder builder = new StringBuilder(functionName.toString());
		builder.append('(');
		for (T t : arguments) {
			builder.append(t);
			builder.append(',');
		}
		if (arguments.size() > 0) {
			return builder.substring(0, builder.length() - 1) + ')';
		} else {
			builder.append(')');
			return builder.toString();
		}
	}
	
	private static ColumnFilter<String, String, Double> exactConfigFilter(final int n) {
		if (n < 1) throw new IllegalArgumentException();
		return new ColumnFilter<String, String, Double>()  {
			@Override
			public boolean apply(String r, Double v) { return v == n; }

			@Override
			public String getColumn() { return "configurations"; }
			
			@Override
			public String toString() {
				if (n == 1)
					return "1 configuration";
				else 
					return n + " configurations";
			}
		};
	}
	
	private static ColumnFilter<String, String, Double> greaterThanConfigFilter(final int n) {
		if (n < 1) throw new IllegalArgumentException();
		return new ColumnFilter<String, String, Double>() {			
			@Override
			public boolean apply(String r, Double v) { return v > n;	}

			@Override
			public String getColumn() { return "configurations"; }
			
			@Override
			public String toString() {
				if (n == 1)
					return "> 1 configuration";
				else {
					return "> " + n + " configurations";
				}
			}
		};
	}
		
}
