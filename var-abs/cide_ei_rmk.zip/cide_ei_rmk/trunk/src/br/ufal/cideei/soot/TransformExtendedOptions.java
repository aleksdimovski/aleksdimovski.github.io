package br.ufal.cideei.soot;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.PhaseOptions;
import soot.Transform;
import soot.Transformer;
import soot.options.Options;

/**
 * A Transformer that allows arbitrary options to be passed to the Transformer
 * via a Map. This is done by merging these extra options with the ones passed
 * in by Soot. You can also define which of the options, the original ones
 * passed in by Soot or yours, have precedence.
 * 
 * @author Társis Tolêdo
 * 
 */
public class TransformExtendedOptions extends Transform {

	protected Map<Object, Object> extraOptions;
	protected final Transformer transformer;
	protected final String phaseName;
	protected final boolean overwrite;

	public TransformExtendedOptions(String phaseName, Map<Object, Object> opt, Transformer t) {
		this(phaseName, opt, false, t);
	}
	
	public TransformExtendedOptions(String phaseName, Map<Object, Object> opt, boolean overwrite, Transformer t) {
		super(phaseName, t);
		this.phaseName = phaseName;
		this.extraOptions = opt;
		this.overwrite = overwrite;
		this.transformer = t;
	}

	public void apply(Body b) {
		Map options = PhaseOptions.v().getPhaseOptions(phaseName);
		Map<Object, Object> mergedOptions;
		if (this.overwrite) {
			mergedOptions = new HashMap<Object, Object>(options);
			mergedOptions.putAll(this.extraOptions);
		} else {
			mergedOptions = new HashMap<Object, Object>(this.extraOptions);
			mergedOptions.putAll(options);
		}

		if (PhaseOptions.getBoolean(options, "enabled")) {
			if (Options.v().verbose()) {
				G.v().out.println("Applying phase " + phaseName + " to " + b.getMethod() + ".");
			}
		}

		((BodyTransformer) this.transformer).transform(b, phaseName, mergedOptions);
	}

}
