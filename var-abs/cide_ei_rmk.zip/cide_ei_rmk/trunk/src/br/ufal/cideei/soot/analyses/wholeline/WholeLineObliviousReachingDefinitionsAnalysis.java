/*
 * This is a prototype implementation of the concept of Feature-Sen
 * sitive Dataflow Analysis. More details in the AOSD'12 paper:
 * Dataflow Analysis for Software Product Lines
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package br.ufal.cideei.soot.analyses.wholeline;

import java.util.Map;

import profiling.ProfilingTag;

//#ifdef METRICS
import br.ufal.cideei.util.count.MetricsSink;

//#endif

import soot.Body;
import soot.Transformer;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import br.ufal.cideei.soot.FilteredBodyTransformer;
import br.ufal.cideei.soot.InstrumentedBodyPreprocessor;
import br.ufal.cideei.soot.InstrumentedBodyPreprocessor.MinimalAndMaximalBody;
import br.ufal.cideei.soot.analyses.reachingdefs.SimpleReachingDefinitions;
import br.ufal.cideei.soot.instrument.EagerConfigTag;

public class WholeLineObliviousReachingDefinitionsAnalysis extends FilteredBodyTransformer {

	private static WholeLineObliviousReachingDefinitionsAnalysis instance = new WholeLineObliviousReachingDefinitionsAnalysis();
	private MetricsSink sink;

	private WholeLineObliviousReachingDefinitionsAnalysis() {
	}

	public static WholeLineObliviousReachingDefinitionsAnalysis v() {
		return instance;
	}
	
	private static final String RD_SIMPLE_FLOWTHROUGH_TIME = "flowthrough time (rd a1)";
	private static final String RD_SIMPLE_FLOWTHROUGH_COUNT = "flowthrough count (rd a1)";
	private static final String RD_SIMPLE_TIME = "analysis time (rd a1)";

	@Override
	protected void filteredInternalTransform(Body body, String phase, Map options) {
		EagerConfigTag configTag = (EagerConfigTag) body.getTag(EagerConfigTag.TAG_NAME);
		
		if (configTag == null) {
			throw new IllegalStateException("No EagerConfigTag found for body of method " + body.getMethod());
		}

		ProfilingTag profilingTag = (ProfilingTag) body.getTag("ProfilingTag");
		profilingTag.setPreprocessingTime(0);

		long totalAnalysis = 0;

		if (configTag.size() > 1) {
			MinimalAndMaximalBody bodies = InstrumentedBodyPreprocessor.minimalAndMaximalBody(body);
			Body minimalBody = bodies.getMinimal();
			Body maximalBody = bodies.getMaximal();
			
			// #ifdef METRICS
			long maximumAnalysis;
			{
				UnitGraph maximumBodyGraph = new BriefUnitGraph(maximalBody);
				long startAnalysis = System.nanoTime();
				new SimpleReachingDefinitions(maximumBodyGraph);
				long endAnalysis = System.nanoTime();
				maximumAnalysis = (endAnalysis - startAnalysis);
			}
			
			long minimumAnalysis;
			{
				UnitGraph minimalBodyGraph = new BriefUnitGraph(minimalBody);
				long startAnalysis = System.nanoTime();
				new SimpleReachingDefinitions(minimalBodyGraph);
				long endAnalysis = System.nanoTime();
				minimumAnalysis = (endAnalysis - startAnalysis);
			}
			
			totalAnalysis = (maximumAnalysis + minimumAnalysis) / 2;
			// #endif
		} else {
			UnitGraph bodyGraph = new BriefUnitGraph(body);
			// #ifdef METRICS
			long startAnalysis = System.nanoTime();
			// #endif
			SimpleReachingDefinitions simpleReachingDefinitions = new SimpleReachingDefinitions(bodyGraph);
			// #ifdef METRICS
			long endAnalysis = System.nanoTime();
			totalAnalysis = endAnalysis - startAnalysis;
			this.sink.flow(body, RD_SIMPLE_FLOWTHROUGH_TIME, simpleReachingDefinitions.getFlowThroughTime());
			this.sink.flow(body, RD_SIMPLE_FLOWTHROUGH_COUNT, simpleReachingDefinitions.getFlowThroughCounter());
			// #endif
		}
		this.sink.flow(body, RD_SIMPLE_TIME, totalAnalysis * configTag.size());
	}

	public Transformer setMetricsSink(MetricsSink sink) {
		this.sink = sink;
		return this;
	}
}
