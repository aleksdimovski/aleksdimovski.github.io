package br.ufal.cideei.util;

public interface Factory<T> {
	public T make();
}
