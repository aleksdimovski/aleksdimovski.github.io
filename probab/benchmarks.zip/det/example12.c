/*

this is also nice example to explain, but there is a lot of information loss 


*/

int main() {
  int x=[-100,99]; input:
	
  int y=x;
  if (y <= 0) y = -y; 
	
  assert (y <= 69); 
  return 0;
}