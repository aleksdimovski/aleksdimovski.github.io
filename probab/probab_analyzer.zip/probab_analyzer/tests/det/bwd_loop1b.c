// simple loop

// backward = forward


void main()
{
  int i = [0,10]; input:
	
  while (i < 100) {
    i++;
  }
	
  assert(i>101);
}
