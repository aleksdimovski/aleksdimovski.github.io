

int main() {
  int x=[0,199]; input:
	
  while (x <= 100) 
    x = x + 1;
	
  assert(x>=110);
  return 0;
}