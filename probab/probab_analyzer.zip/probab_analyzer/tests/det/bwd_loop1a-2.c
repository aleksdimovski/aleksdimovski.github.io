// simple loop

// backward = forward


void main()
{
  int i = [0,999]; input:
	
  while (i < 100) {
    i++;
  }
	
  assert(i<=101);
}
