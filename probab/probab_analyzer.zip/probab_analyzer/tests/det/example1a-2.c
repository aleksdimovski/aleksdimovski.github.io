

int main() {
  int x=[0,999]; input:
	
  while (x <= 100) 
    x = x + 1;
	
  assert(x>=101);
}