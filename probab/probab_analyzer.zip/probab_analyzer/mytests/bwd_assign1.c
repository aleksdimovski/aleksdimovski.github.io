// invertible assignment



void main()
{
  int j = [1,2], i = [10,19]; input:
  i = i + j;
  assert(i>=15);
}