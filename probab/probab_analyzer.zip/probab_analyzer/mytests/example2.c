

int main() {
  int y=[0,9]; input:
  int x=1;

  while (x<5) {
    x = x + 1;
	y = y + 1;
  }
	
  assert(y>=5);
  return 0;
}