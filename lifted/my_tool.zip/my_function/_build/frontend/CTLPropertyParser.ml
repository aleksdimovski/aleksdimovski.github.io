
module MenhirBasics = struct
  
  exception Error
  
  type token = 
    | RIGHT_BRACE
    | OR
    | NOT
    | LEFT_BRACE
    | LABEL of (
# 9 "frontend/CTLPropertyParser.mly"
       (string)
# 15 "frontend/CTLPropertyParser.ml"
  )
    | EX
    | EU
    | EG
    | EF
    | AX
    | AU
    | ATOMIC of (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 26 "frontend/CTLPropertyParser.ml"
  )
    | AND
    | AG
    | AF
  
end

include MenhirBasics

let _eRR =
  MenhirBasics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState116
  | MenhirState112
  | MenhirState108
  | MenhirState105
  | MenhirState100
  | MenhirState97
  | MenhirState93
  | MenhirState89
  | MenhirState85
  | MenhirState81
  | MenhirState78
  | MenhirState74
  | MenhirState68
  | MenhirState64
  | MenhirState59
  | MenhirState50
  | MenhirState39
  | MenhirState34
  | MenhirState27
  | MenhirState25
  | MenhirState23
  | MenhirState20
  | MenhirState18
  | MenhirState16
  | MenhirState14
  | MenhirState12
  | MenhirState10
  | MenhirState6
  | MenhirState4
  | MenhirState2
  | MenhirState0

# 1 "frontend/CTLPropertyParser.mly"
  
open CTLProperty

let label_name l = String.sub l 0 (String.length l - 1)


# 86 "frontend/CTLPropertyParser.ml"

let rec _menhir_reduce12 : _menhir_env -> ((((('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 91 "frontend/CTLPropertyParser.ml"
)))) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 95 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s), _, (e1 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 101 "frontend/CTLPropertyParser.ml"
    ))), _, (e2 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 105 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 115 "frontend/CTLPropertyParser.ml"
    ) = 
# 39 "frontend/CTLPropertyParser.mly"
                                                                                ( OR (e1, e2) )
# 119 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce13 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 126 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 132 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 140 "frontend/CTLPropertyParser.ml"
    ) = 
# 40 "frontend/CTLPropertyParser.mly"
                                            ( NOT e)
# 144 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce7 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 151 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 157 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 165 "frontend/CTLPropertyParser.ml"
    ) = 
# 34 "frontend/CTLPropertyParser.mly"
                                          (EX e)
# 169 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce10 : _menhir_env -> ((((('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 176 "frontend/CTLPropertyParser.ml"
)))) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 180 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s), _, (e1 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 186 "frontend/CTLPropertyParser.ml"
    ))), _, (e2 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 190 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 200 "frontend/CTLPropertyParser.ml"
    ) = 
# 37 "frontend/CTLPropertyParser.mly"
                                                                                ( EU (e1, e2) )
# 204 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce9 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 211 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 217 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 225 "frontend/CTLPropertyParser.ml"
    ) = 
# 36 "frontend/CTLPropertyParser.mly"
                                          (EG e)
# 229 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce8 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 236 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 242 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 250 "frontend/CTLPropertyParser.ml"
    ) = 
# 35 "frontend/CTLPropertyParser.mly"
                                          (EF e)
# 254 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce3 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 261 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 267 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 275 "frontend/CTLPropertyParser.ml"
    ) = 
# 30 "frontend/CTLPropertyParser.mly"
                                          (AX e)
# 279 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce6 : _menhir_env -> ((((('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 286 "frontend/CTLPropertyParser.ml"
)))) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 290 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s), _, (e1 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 296 "frontend/CTLPropertyParser.ml"
    ))), _, (e2 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 300 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 310 "frontend/CTLPropertyParser.ml"
    ) = 
# 33 "frontend/CTLPropertyParser.mly"
                                                                                ( AU (e1, e2) )
# 314 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce11 : _menhir_env -> ((((('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 321 "frontend/CTLPropertyParser.ml"
)))) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 325 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (((_menhir_stack, _menhir_s), _, (e1 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 331 "frontend/CTLPropertyParser.ml"
    ))), _, (e2 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 335 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 345 "frontend/CTLPropertyParser.ml"
    ) = 
# 38 "frontend/CTLPropertyParser.mly"
                                                                                 ( AND (e1, e2) )
# 349 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce5 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 356 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 362 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 370 "frontend/CTLPropertyParser.ml"
    ) = 
# 32 "frontend/CTLPropertyParser.mly"
                                          (AG e)
# 374 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce4 : _menhir_env -> (('ttv_tail * _menhir_state)) * _menhir_state * (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 381 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let ((_menhir_stack, _menhir_s), _, (e : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 387 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _4 = () in
    let _2 = () in
    let _1 = () in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 395 "frontend/CTLPropertyParser.ml"
    ) = 
# 31 "frontend/CTLPropertyParser.mly"
                                          (AF e)
# 399 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_prog : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 406 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState27 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState25 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState34
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState34)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState34 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce11 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState20 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState39
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState39)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce6 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState18 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState16 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce8 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState14 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce9 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState12 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState50
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState50)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce10 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState10 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce7 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState6 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce13 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState4 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState59 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState59 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState59
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState59)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState59 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce12 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState2 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState64 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState64 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState64
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState64)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState64 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce12 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState68 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce13 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState74 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce7 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState78 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState81 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState81 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState81
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState81)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState81 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce10 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState85 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce9 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState89 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce8 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState93 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce3 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState97 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState100
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState100)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState100 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce6 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState105 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | LEFT_BRACE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | AF ->
                    _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | AG ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | AND ->
                    _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | ATOMIC _v ->
                    _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _v
                | AU ->
                    _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | AX ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | EF ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | EG ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | EU ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | EX ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | LABEL _v ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _v
                | NOT ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | OR ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState108
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState108)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState108 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce11 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState112 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce5 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState116 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RIGHT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce4 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, (_1 : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 1192 "frontend/CTLPropertyParser.ml"
        ))) = _menhir_stack in
        Obj.magic _1

and _menhir_reduce2 : _menhir_env -> 'ttv_tail * _menhir_state * (
# 9 "frontend/CTLPropertyParser.mly"
       (string)
# 1199 "frontend/CTLPropertyParser.ml"
) -> (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 1203 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack (e : (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 1208 "frontend/CTLPropertyParser.ml"
  )) ->
    let (_menhir_stack, _menhir_s, (l : (
# 9 "frontend/CTLPropertyParser.mly"
       (string)
# 1213 "frontend/CTLPropertyParser.ml"
    ))) = _menhir_stack in
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 1218 "frontend/CTLPropertyParser.ml"
    ) = 
# 29 "frontend/CTLPropertyParser.mly"
                          ( Atomic (e, Some (label_name l)) )
# 1222 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce1 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 1229 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s (e : (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 1234 "frontend/CTLPropertyParser.ml"
  )) ->
    let _v : (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 1239 "frontend/CTLPropertyParser.ml"
    ) = 
# 28 "frontend/CTLPropertyParser.mly"
               ( Atomic (e, None) )
# 1243 "frontend/CTLPropertyParser.ml"
     in
    _menhir_goto_prog _menhir_env _menhir_stack _menhir_s _v

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState116 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState112 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState108 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState105 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState100 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState97 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState93 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState89 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState85 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState81 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState78 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState74 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState68 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState64 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState59 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState34 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState27 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState25 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState20 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState18 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState16 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState14 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState12 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState10 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState6 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState4 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState2 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState4 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState4 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState4
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState4)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run5 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState6 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState6 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState6
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState6)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 9 "frontend/CTLPropertyParser.mly"
       (string)
# 1473 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ATOMIC _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run9 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState10
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState10)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState12
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState12)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run13 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState14
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState14)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState16 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState16 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState16
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState16)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run17 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState18 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState18 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState18
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState18)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run19 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState20
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState20)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run21 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 8 "frontend/CTLPropertyParser.mly"
       (string)
# 1782 "frontend/CTLPropertyParser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v

and _menhir_run22 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState23
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState23)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run24 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState25 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState25 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState25
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState25)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run26 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LEFT_BRACE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AF ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | AG ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | AND ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | ATOMIC _v ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
        | AU ->
            _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | AX ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | EF ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | EG ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | EU ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | EX ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | LABEL _v ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState27 _v
        | NOT ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | OR ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState27
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState27)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and prog : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 24 "frontend/CTLPropertyParser.mly"
       (string CTLProperty.generic_property)
# 1947 "frontend/CTLPropertyParser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = let _tok = Obj.magic () in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    } in
    Obj.magic (let _menhir_stack = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AF ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState116 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState116 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState116
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState116)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | AG ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState112 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState112 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState112
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState112)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | AND ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState105
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState105)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | ATOMIC _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        _menhir_reduce1 _menhir_env (Obj.magic _menhir_stack) _menhir_s _v
    | AU ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState97 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState97 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState97
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState97)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | AX ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState93
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState93)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | EF ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState89 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState89 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState89
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState89)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | EG ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState85 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState85 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState85
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState85)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | EU ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState78
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState78)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | EX ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState74 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState74 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState74
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState74)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | LABEL _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATOMIC _v ->
            let _menhir_stack = Obj.magic _menhir_stack in
            _menhir_reduce2 _menhir_env (Obj.magic _menhir_stack) _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | NOT ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState68
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState68)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | OR ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState0 in
        let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | LEFT_BRACE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | AF ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | AG ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | AND ->
                _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | ATOMIC _v ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState2 _v
            | AU ->
                _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | AX ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | EF ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | EG ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | EU ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | EX ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | LABEL _v ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState2 _v
            | NOT ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | OR ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState2
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState2)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0)

# 219 "/usr/share/menhir/standard.mly"
  


# 2518 "frontend/CTLPropertyParser.ml"
