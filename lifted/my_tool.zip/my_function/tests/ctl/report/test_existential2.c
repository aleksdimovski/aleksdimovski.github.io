// -ctl "EF{r == 1}"
// -domain polyhedra
int main() {
    int x;
    int y;
    int r = 0;
    while (?) { 
        x = x + 1;
        if (x == 200) {
            r = 1;
        }
    }
}

