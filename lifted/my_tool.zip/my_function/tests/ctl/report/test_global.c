// FuncTion arguments:
// -ctl "AF{AG{y > 0}}" 
int main() {
    int x;
    int y = 0;

    while (true) {
        x = x + 1;
        while (x==10) {
            y = y + 1;
        }
    }
}
