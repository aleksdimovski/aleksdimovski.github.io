// -ctl_str "EF{r == 1}"
// -domain polyhedra
int main() {
    int i;
    int temp = 0;
    int r;
    i = [0,1];
    if (temp + i > 0) {
        r = 1;
    }     

}

