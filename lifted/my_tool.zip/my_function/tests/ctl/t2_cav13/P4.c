// OK
// -precondition "varN > 0"
// -ctl_cfg "EF{AND{varA == 1}{AG{varR != 1}}"

void main() {

    int varN;
    int varA = 0;
    int varR = 0;

    while(true) {
        varA = 1;
        varA = 0;
        while(varN > 0) {}  
        varR = 1;
        varR = 0;
    }


}
