// -ctl_str "EF{r == 1}"
// -precondition "2*x <= y+3"
int main() {
    int r = 0;
    int x;
    int y;
    if (2*x <= y+3) {
        if (? == 1) {
            r = 1;
        } 
    }
}

