
int main() {
    int x;
    int y;
    int result;

    if (x >= 0 && y >= 1) {
        if (x <= 10 && y <= 8) {
            if (x == y) {
                result = 1;
            }
        }
    }

}
