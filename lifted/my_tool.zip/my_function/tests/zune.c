/* http://techcrunch.com/2008/12/31/zune-bug-explained-in-detail/

*/

int main() {
  int days, year = 1980;
  while (days > 365) {
    if ( isLeapYear(year) ) {
      if (days > 366) {
        days -= 366;
        year += 1;
      }
    } else {
      days -= 365;
      year += 1;
    }
  }
  return 0;
}